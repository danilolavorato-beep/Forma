// Test del motore del programma: node --test tests/
import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  defaultState, phaseForWeek, buildSession, flatten, evaluate, applyEvaluation,
  completeSession, availableIndex, resolveSlot, isTestDue, recordTests, LADDERS, implFor,
} from '../www/js/engine.js';
import { EX, EQUIP } from '../www/js/data/exercises.js';
import { ANIMS } from '../www/js/data/anims.js';
import { PHASES } from '../www/js/data/program.js';

const ready = () => {
  const s = defaultState(0);
  s.tests.push({ at: 0, squat: 20, bridgeR: 10, bridgeL: 10, push: 10, pushVariant: 'pu_knee', plank: 40 });
  return s;
};

test('ogni esercizio ha un’animazione esistente e dati coerenti', () => {
  for (const [id, ex] of Object.entries(EX)) {
    assert.ok(ANIMS[ex.anim], `animazione mancante per ${id}: ${ex.anim}`);
    assert.ok(ex.range[0] < ex.range[1], `fascia non valida per ${id}`);
    assert.ok(['reps', 'time'].includes(ex.type), id);
    assert.ok(Array.isArray(ex.cues) && ex.cues.length, `cue mancanti per ${id}`);
  }
});

test('ogni scala punta a esercizi esistenti', () => {
  for (const [k, L] of Object.entries(LADDERS)) for (const id of L.list) assert.ok(EX[id], `${k}: ${id}`);
});

test('fasi e settimane leggere', () => {
  assert.equal(phaseForWeek(1).phase.id, 'f1');
  assert.equal(phaseForWeek(4).phase.id, 'f1');
  assert.equal(phaseForWeek(5).phase.id, 'f2');
  assert.equal(phaseForWeek(10).light, true);
  assert.equal(phaseForWeek(11).phase.id, 'f3');
  assert.equal(phaseForWeek(16).light, true);
  const w17 = phaseForWeek(17);
  assert.equal(w17.phase.id, 'f4');
  assert.equal(w17.cycle.id, 'carico');
  assert.equal(phaseForWeek(22).light, true);
  assert.equal(phaseForWeek(23).cycle.id, 'volume');
  assert.equal(phaseForWeek(29).cycle.id, 'densita');
  assert.equal(phaseForWeek(35).cycle.id, 'carico');
});

test('il primo accesso propone il test, salvo rinuncia', () => {
  const s = defaultState(0);
  assert.equal(isTestDue(s), true);
  assert.equal(buildSession(s).kind, 'test');
  s.progress.testSkipped = true;
  assert.equal(isTestDue(s), false);
  assert.equal(buildSession(s).kind, 'workout');
});

test('le varianti che richiedono attrezzi vengono saltate', () => {
  const s = ready();
  const band = LADDERS.ABD.list.indexOf('side_abd_band'); // richiede la mini band
  assert.equal(LADDERS.ABD.list[availableIndex('ABD', band, s.settings.eq)], 'side_abd_pause');
  s.settings.eq.miniband = true;
  assert.equal(availableIndex('ABD', band, s.settings.eq), band);
  s.settings.eq.gradino = false;
  assert.equal(resolveSlot('STEP_OR_SPLIT', s).ladder, 'SPLIT');
  s.settings.eq.gradino = true;
  assert.equal(resolveSlot('STEP_OR_SPLIT', s).ladder, 'STEP');
  s.levels.PUSH = 2;
  assert.equal(resolveSlot('PIKE_OR_PUSH', s).ladder, 'PUSH');
  s.levels.PUSH = 4;
  assert.equal(resolveSlot('PIKE_OR_PUSH', s).ladder, 'PIKE');
  // con la sbarra la tirata verticale diventa una trazione
  assert.equal(resolveSlot('VPULL', s).ladder, 'PULLV');
  s.settings.eq.sbarra = true;
  assert.equal(resolveSlot('VPULL', s).ex, 'scap_pull');
});

test('attrezzi: piano dedicato e progressione del peso', () => {
  const s = ready();
  s.progress.week = 12; s.progress.testWeek = 12;
  // senza cavigliere né elastici niente slanci; con le cavigliere compaiono
  const has = (sess, id) => sess.blocks.some((b) => b.items.some((it) => it.ladder === id));
  assert.equal(has(buildSession(s, { key: 'B', test: false }), 'KICK'), false);
  s.settings.eq.cavigliere = true;
  assert.equal(has(buildSession(s, { key: 'B', test: false }), 'KICK'), true);
  // carico: si parte dal peso adatto e si sale quando la fascia è completata
  s.settings.eq.kb = true; s.settings.weights.kb = [8, 12, 16];
  s.levels.SQ = LADDERS.SQ.list.indexOf('sq_goblet');
  const it = buildSession(s, { key: 'B', test: false }).blocks[0].items[0];
  assert.equal(it.ex, 'sq_goblet');
  assert.deepEqual([it.load.impl, it.load.kg], ['kb', 12]);
  const ev = evaluate(s, { ladder: 'SQ', ex: 'sq_goblet', sets: [{ v: 15 }, { v: 15 }, { v: 16 }], rir: 2, load: it.load }, 2);
  assert.equal(ev.decision, 'heavier');
  applyEvaluation(s, ev);
  assert.equal(buildSession(s, { key: 'B', test: false }).blocks[0].items[0].load.kg, 16);
  assert.equal(s.levels.SQ, LADDERS.SQ.list.indexOf('sq_goblet'));
  // al peso massimo si passa alla variante successiva
  const ev2 = evaluate(s, { ladder: 'SQ', ex: 'sq_goblet', sets: [{ v: 15 }, { v: 15 }, { v: 15 }], rir: 2 }, 2);
  assert.equal(ev2.decision, 'up');
  // con i manubri il rematore usa i manubri
  s.settings.eq.manubri = true; s.settings.weights.manubri = [4, 6];
  assert.equal(implFor(s, 'bp_row'), 'manubri');
});

test('durata delle sessioni nei limiti (standard ≤ 45 min, rapida ≤ 25)', () => {
  // tutte le settimane delle prime tre fasi e i primi tre cicli (carico, volume, densità)
  const weeks = Array.from({ length: 34 }, (_, k) => k + 1);
  for (const days of [2, 3, 4]) {
    for (const ph of PHASES) {
      for (const week of weeks.filter((w) => w >= ph.from && (ph.to == null || w <= ph.to))) {
        const s = ready();
        s.settings.days = days;
        s.settings.noJumps = false;
        s.settings.eq = Object.fromEntries(Object.keys(EQUIP).map((k) => [k, true]));
        s.progress.week = week;
        s.progress.testWeek = week;
        for (const key of ['A', 'B', 'C', 'D'].slice(0, days)) {
          const std = buildSession(s, { key, test: false });
          const quick = buildSession(s, { key, test: false, quick: true });
          assert.ok(std.est >= 15 && std.est <= 45, `${ph.id} sett.${week} ${days}gg ${key}: ${std.est} min`);
          assert.ok(quick.est <= 25, `${ph.id} sett.${week} ${days}gg ${key} rapida: ${quick.est} min`);
          assert.ok(quick.est < std.est, 'la versione rapida deve essere più corta');
        }
      }
    }
  }
});

test('flatten: pause tra esercizi, recuperi tra giri e anteprima del successivo', () => {
  const s = ready();
  s.progress.week = 5;
  const sess = buildSession(s, { key: 'A', test: false });
  const steps = flatten(sess);
  const sets = steps.filter((x) => x.t === 'set');
  const expected = sess.blocks.reduce((a, b) => a + b.items.reduce((c, it) => c + it.sets, 0), 0);
  assert.equal(sets.length, expected);
  for (const g of steps.filter((x) => x.t === 'gap')) assert.ok(g.next, 'ogni pausa ha un passo successivo');
  assert.ok(steps.some((x) => x.t === 'gap' && x.kind === 'rest'));
});

test('progressione: fascia completata → livello successivo', () => {
  const s = ready();
  s.levels.BRIDGE = 0;
  const ev = evaluate(s, { ladder: 'BRIDGE', ex: 'bridge', sets: [{ v: 20 }, { v: 20 }, { v: 21 }], rir: 2 }, 2);
  assert.equal(ev.decision, 'up');
  applyEvaluation(s, ev);
  assert.equal(s.levels.BRIDGE, 1);
  assert.equal(s.perf.bridge_pause.target, EX.bridge_pause.range[0] + 1);
});

test('progressione: due sessioni sotto la fascia → livello precedente', () => {
  const s = ready();
  s.levels.SPLIT = 4;
  const log = { ladder: 'SPLIT', ex: 'bss', sets: [{ v: 6, vL: 5 }, { v: 5, vL: 5 }], rir: 0 };
  const e1 = evaluate(s, log, 2);
  assert.equal(e1.decision, 'hold');
  applyEvaluation(s, e1);
  const e2 = evaluate(s, log, 2);
  assert.equal(e2.decision, 'down');
  applyEvaluation(s, e2);
  assert.equal(s.levels.SPLIT, 3);
});

test('dolore: livello fermo la prima volta, variante più facile se si ripete', () => {
  const s = ready();
  s.levels.SPLIT = 4;
  const log = { ladder: 'SPLIT', ex: 'bss', sets: [{ v: 10, vL: 10 }, { v: 10, vL: 10 }], rir: 2, pain: true };
  const e1 = evaluate(s, log, 2);
  assert.equal(e1.decision, 'pain');
  applyEvaluation(s, e1);
  assert.equal(s.levels.SPLIT, 4);
  const e2 = evaluate(s, log, 2);
  assert.equal(e2.decision, 'painDown');
  applyEvaluation(s, e2);
  assert.equal(s.levels.SPLIT, 3);
  // una sessione senza dolore azzera il conteggio
  const s2 = ready();
  s2.levels.SPLIT = 4;
  applyEvaluation(s2, evaluate(s2, log, 2));
  applyEvaluation(s2, evaluate(s2, { ...log, pain: false }, 2));
  assert.equal(evaluate(s2, log, 2).decision, 'pain');
});

test('progressione: obiettivo +1 solo se lo sforzo è nel bersaglio', () => {
  const s = ready();
  const easy = evaluate(s, { ladder: 'SQ', ex: 'sq_bw', sets: [{ v: 12 }, { v: 12 }], rir: 3 }, 2);
  assert.equal(easy.perf.target, 13);
  const hard = evaluate(s, { ladder: 'SQ', ex: 'sq_bw', sets: [{ v: 12 }, { v: 11 }], rir: 0 }, 2);
  assert.equal(hard.perf.target, 12);
});

test('per gli esercizi monolaterali conta il lato più debole', () => {
  const s = ready();
  const ev = evaluate(s, { ladder: 'SPLIT', ex: 'split_squat', sets: [{ v: 15, vL: 13 }, { v: 15, vL: 15 }], rir: 1 }, 2);
  assert.equal(ev.decision, 'hold');
});

test('calendario: settimana e rotazione avanzano', () => {
  const s = ready();
  s.settings.days = 3;
  for (let k = 0; k < 3; k++) {
    const sess = buildSession(s, { test: false });
    assert.equal(sess.key, ['A', 'B', 'C'][k]);
    completeSession(s, sess, { items: {}, dur: 1800 }, 1000 + k);
  }
  assert.equal(s.progress.week, 2);
  assert.equal(s.progress.inWeek, 0);
  assert.equal(s.history.length, 3);
});

test('il test iniziale fissa i livelli e non consuma una sessione della settimana', () => {
  const s = defaultState(0);
  const sess = buildSession(s);
  assert.equal(sess.kind, 'test');
  completeSession(s, sess, { items: {}, tests: { squat: 32, bridgeR: 22, bridgeL: 20, push: 9, pushVariant: 'pushup', plank: 65 } }, 5);
  const ex = (k) => LADDERS[k].list[s.levels[k]];
  assert.equal(ex('SQ'), 'sq_tempo');
  assert.equal(ex('BRIDGE'), 'sl_bridge');
  assert.equal(ex('PUSH'), 'pushup');
  assert.equal(ex('ANTIEXT'), 'plank');
  assert.equal(s.progress.inWeek, 0);
  assert.equal(buildSession(s).kind, 'workout');
});

test('settimana leggera: test alla prima sessione e una serie in meno', () => {
  const s = ready();
  s.progress.week = 10;
  assert.equal(isTestDue(s), true);
  const t = buildSession(s);
  assert.equal(t.kind, 'test');
  completeSession(s, t, { items: {}, tests: { squat: 40, bridgeR: 20, bridgeL: 20, push: 12, pushVariant: 'pushup', plank: 70 } }, 10);
  const w = buildSession(s);
  assert.equal(w.kind, 'workout');
  assert.equal(w.light, true);
  assert.ok(w.blocks.every((b) => b.items.every((it) => it.sets <= 2)));
  assert.equal(recordTests(s, { squat: 1 }, 11), false, 'i test successivi non cambiano i livelli');
});

test('fase 3: ultima serie degli esercizi principali al cedimento tecnico', () => {
  const s = ready();
  s.progress.week = 12;
  const sess = buildSession(s, { key: 'A', test: false });
  const pushSets = flatten(sess).filter((x) => x.t === 'set' && x.push);
  assert.ok(pushSets.length >= 2);
  assert.ok(pushSets.every((x) => x.last));
});

test('mantenimento: due sessioni con 2 serie', () => {
  const s = ready();
  s.settings.mode = 'mant';
  const a = buildSession(s, { test: false });
  assert.ok(['A', 'B'].includes(a.key));
  assert.ok(a.blocks.every((b) => b.items.every((it) => it.sets === 2)));
});

test('rientro dopo una pausa lunga: sessione alleggerita', () => {
  const s = ready();
  s.progress.week = 6;
  s.progress.lastAt = 0;
  const sess = buildSession(s, { test: false, now: 15 * 86400000 });
  assert.equal(sess.comeback, true);
  assert.equal(sess.light, true);
});
