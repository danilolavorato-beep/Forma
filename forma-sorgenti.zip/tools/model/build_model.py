"""Forma — genera www/model/atleta.glb dal corpo MakeHuman (asset CC0).

Uso:
  python3 tools/model/build_model.py <cartella makehuman/data> www/model/atleta.glb

Il risultato contiene: mesh del corpo con texture procedurale (pelle, top e leggings sportivi,
scarpe, sopracciglia, labbra), occhi, ciglia e capelli raccolti come primitive separate,
uno scheletro semplificato di 19 ossa con pesi di skinning, e un attributo per vertice con
il gruppo muscolare (usato dall'app per evidenziare i muscoli che lavorano).
"""
import json, os, sys, math, struct, io
import numpy as np
import cv2
from PIL import Image

sys.path.insert(0, os.path.dirname(__file__))
import mh  # noqa: E402

DATA = sys.argv[1]
OUT = sys.argv[2] if len(sys.argv) > 2 else 'www/model/atleta.glb'
mh.DATA = DATA
TEX = 1024  # lato della texture finale
SS = 2      # sovracampionamento per l'antialiasing

# ------------------------------------------------------------------ corpo
V, VT, faces, fuv, groups = mh.load_obj(os.path.join(DATA, '3dobjs', 'base.obj'))
mh.build_body(V, mh.PARAMS)
skel = json.load(open(os.path.join(DATA, 'rigs', 'default.mhskel')))
JP = {k: V[v].mean(axis=0) for k, v in skel['joints'].items()}
jh = lambda b: JP[skel['bones'][b]['head']]
jt = lambda b: JP[skel['bones'][b]['tail']]

# ------------------------------------------------------------------ scheletro semplificato
def mid(a, b):
    return (a + b) / 2

BONES = []  # (nome, genitore, testa, coda)
hipC = mid(jh('upperleg01.L'), jh('upperleg01.R'))
shC = mid(jh('upperarm01.L'), jh('upperarm01.R'))
BONES.append(('torso', None, hipC, shC))
BONES.append(('neck', 'torso', jh('neck01'), jh('head')))
BONES.append(('head', 'neck', jh('head'), jt('head')))
for s in 'LR':
    BONES.append((f'clav.{s}', 'torso', jh(f'clavicle.{s}'), jh(f'upperarm01.{s}')))
    BONES.append((f'uarm.{s}', f'clav.{s}', jh(f'upperarm01.{s}'), jh(f'lowerarm01.{s}')))
    BONES.append((f'farm.{s}', f'uarm.{s}', jh(f'lowerarm01.{s}'), jh(f'wrist.{s}')))
    BONES.append((f'hand.{s}', f'farm.{s}', jh(f'wrist.{s}'), jh(f'finger3-1.{s}')))
    BONES.append((f'thigh.{s}', 'torso', jh(f'upperleg01.{s}'), jh(f'lowerleg01.{s}')))
    BONES.append((f'shin.{s}', f'thigh.{s}', jh(f'lowerleg01.{s}'), jh(f'foot.{s}')))
    BONES.append((f'foot.{s}', f'shin.{s}', jh(f'foot.{s}'), jh(f'toe3-1.{s}')))
    toeBase = np.mean([jh(f'toe{i}-1.{s}') for i in range(1, 6)], axis=0)
    BONES.append((f'toes.{s}', f'foot.{s}', toeBase, jt(f'toe3-3.{s}')))
BI = {b[0]: i for i, b in enumerate(BONES)}


def my_bone(mhname):
    """Osso semplificato a cui va un osso MakeHuman (risalendo i genitori)."""
    b = mhname
    while b is not None:
        side = b[-1] if b[-2:] in ('.L', '.R') else None
        n = b.split('.')[0]
        if n in ('root', 'spine01', 'spine02', 'spine03', 'spine04', 'spine05', 'breast') or n.startswith('pelvis'):
            return 'torso'
        if n.startswith('neck'):
            return 'neck'
        if n == 'head':
            return 'head'
        if side:
            if n in ('clavicle', 'shoulder01'): return f'clav.{side}'
            if n.startswith('upperarm'): return f'uarm.{side}'
            if n.startswith('lowerarm'): return f'farm.{side}'
            if n == 'wrist': return f'hand.{side}'
            if n.startswith('upperleg'): return f'thigh.{side}'
            if n.startswith('lowerleg'): return f'shin.{side}'
            if n == 'foot': return f'foot.{side}'
            if n.startswith('toe'): return f'toes.{side}'
        b = skel['bones'][b]['parent']
    return 'torso'


# ------------------------------------------------------------------ mani rilassate (dita leggermente flesse)
MHW = json.load(open(os.path.join(DATA, 'rigs', 'default_weights.mhw')))['weights']


def relax_hands():
    def rot(axis, ang):
        a = axis / np.linalg.norm(axis); c, s_ = math.cos(ang), math.sin(ang); C = 1 - c
        x, y, z = a
        return np.array([[c + x * x * C, x * y * C - z * s_, x * z * C + y * s_], [y * x * C + z * s_, c + y * y * C, y * z * C - x * s_], [z * x * C - y * s_, z * y * C + x * s_, c + z * z * C]])
    V0 = V.copy()
    acc = np.zeros_like(V); wsum = np.zeros(len(V))
    for s in 'LR':
        w_ = jh(f'wrist.{s}'); m_ = jh(f'finger3-1.{s}'); i_ = jh(f'finger2-1.{s}'); p_ = jh(f'finger5-1.{s}')
        d_ = (m_ - w_) / np.linalg.norm(m_ - w_); a_ = (p_ - i_) / np.linalg.norm(p_ - i_)
        n_ = np.cross(d_, a_); n_ /= np.linalg.norm(n_)
        palm = -n_ if s == 'L' else n_
        for f in range(1, 6):
            angs = [0.12, 0.2, 0.12] if f == 1 else [0.2, 0.38, 0.22]
            M = np.eye(4)
            for k in (1, 2, 3):
                b = f'finger{f}-{k}.{s}'
                h_ = jh(b); dd = jt(b) - h_; dd /= np.linalg.norm(dd)
                ax = np.cross(dd, palm)
                R_ = rot(ax, angs[k - 1])
                L_ = np.eye(4); L_[:3, :3] = R_; L_[:3, 3] = h_ - R_ @ h_
                M = M @ L_
                lst = MHW.get(b, [])
                if not lst:
                    continue
                idx = np.array([q[0] for q in lst]); ww = np.array([q[1] for q in lst])
                P4 = np.c_[V0[idx], np.ones(len(idx))] @ M.T
                acc[idx] += P4[:, :3] * ww[:, None]; wsum[idx] += ww
    tot = np.zeros(len(V))
    for b, lst in MHW.items():
        for i, w in lst:
            tot[i] += w
    m = wsum > 0
    frac = wsum[m] / np.maximum(tot[m], 1e-9)
    V[m] = V0[m] * (1 - frac)[:, None] + acc[m] / tot[m][:, None]


relax_hands()

W = np.zeros((len(V), len(BONES)))
for b, lst in MHW.items():
    k = BI[my_bone(b)]
    for i, w in lst:
        W[i, k] += w
W /= np.maximum(W.sum(1, keepdims=True), 1e-9)
DOM = W.argmax(1)

# ------------------------------------------------------------------ geometria per gruppo
def faces_of(g):
    return [(f, t) for f, t, gg in zip(faces, fuv, groups) if gg == g]


def triangulate(fl):
    tris, tuv = [], []
    for f, t in fl:
        for k in range(1, len(f) - 1):
            tris.append([f[0], f[k], f[k + 1]]); tuv.append([t[0], t[k], t[k + 1]])
    return np.array(tris), np.array(tuv)


def vertex_normals(P, tris):
    N = np.zeros_like(P)
    a, b, c = P[tris[:, 0]], P[tris[:, 1]], P[tris[:, 2]]
    fn = np.cross(b - a, c - a)
    for k in range(3):
        np.add.at(N, tris[:, k], fn)
    return N / np.maximum(np.linalg.norm(N, axis=1, keepdims=True), 1e-12)


body_tris, body_tuv = triangulate(faces_of('body'))
N_all = vertex_normals(V, body_tris)


def shape_shoes():
    """Trasforma il piede nudo in una scarpa: dita levigate, volume e suola."""
    fset = np.isin(DOM, [BI['foot.L'], BI['foot.R'], BI['toes.L'], BI['toes.R']])
    yA = jh('foot.L')[1]
    low = np.zeros(len(V), bool); low[np.unique(body_tris)] = True
    low &= (V[:, 1] < yA + 0.45) & (np.isin(DOM, [BI['shin.L'], BI['shin.R']]) | fset)
    adj = [[] for _ in range(len(V))]
    for t in body_tris:
        for i in range(3):
            adj[t[i]].append(t[(i + 1) % 3]); adj[t[(i + 1) % 3]].append(t[i])
    idx = np.where(low)[0]
    nb = [np.unique(adj[i]) for i in idx]
    toe = np.isin(DOM[idx], [BI['toes.L'], BI['toes.R']]) | (V[idx, 2] > np.array([jh('toe3-1.L')[2]]) - 0.15)
    for it in range(14):
        Vn = V.copy()
        for k, i in enumerate(idx):
            lam = 0.75 if toe[k] else 0.3
            Vn[i] = V[i] * (1 - lam) + V[nb[k]].mean(0) * lam
        V[idx] = Vn[idx]
    Nn = vertex_normals(V, body_tris)
    ymin = V[idx, 1].min()
    for i in idx:
        h = V[i, 1]
        k = 0.11 * np.clip((yA + 0.45 - h) / 0.35, 0, 1)
        V[i] += Nn[i] * k
    # suola piatta
    sole = idx[V[idx, 1] < ymin + 0.12]
    V[sole, 1] = np.minimum(V[sole, 1], ymin + 0.02) - 0.08


shape_shoes()
N_all = vertex_normals(V, body_tris)

# ------------------------------------------------------------------ riferimenti anatomici
Y_HIP = hipC[1]
Y_SOLE = V[np.unique(body_tris)][:, 1].min()
Y_ANKLE = jh('foot.L')[1]
Y_KNEE = jh('lowerleg01.L')[1]
Y_SH = shC[1]
Y_NECK = jh('neck01')[1]
EYE = {s: V[sorted({i for f, _ in faces_of(f'helper-{s.lower()}-eye') for i in f})].mean(0) for s in 'LR'}
LIPS = np.mean([JP['oris01____head'], JP['oris05____head'], JP['oris06____head'], JP['oris02____head']], axis=0)
HEADC = np.array([0.0, 7.72, 0.45])
print('quote: suola %.2f caviglia %.2f ginocchio %.2f anca %.2f spalle %.2f collo %.2f' % (Y_SOLE, Y_ANKLE, Y_KNEE, Y_HIP, Y_SH, Y_NECK))


def smooth(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0, 1)
    return t * t * (3 - 2 * t)


# ------------------------------------------------------------------ gruppi muscolari (id per vertice)
MUSCLES = ['none', 'glutes', 'glutemed', 'quads', 'hamstrings', 'adductors', 'calves', 'core', 'lowback', 'chest', 'upperback', 'delts', 'biceps', 'triceps']
MID = {m: i for i, m in enumerate(MUSCLES)}


def muscle_of(P, N, dom):
    """Classifica i vertici (posizioni P in posa di riposo) nei gruppi muscolari."""
    out = np.zeros(len(P), dtype=np.int32)
    x, y, z = P[:, 0], P[:, 1], P[:, 2]
    ax = np.abs(x)
    name = np.array([BONES[d][0] for d in dom])
    part = np.array([n.split('.')[0] for n in name])
    # coordinate locali di coscia e gamba
    for s, sgn in (('L', 1), ('R', -1)):
        for bn in ('thigh', 'shin', 'uarm'):
            h, t = BONES[BI[f'{bn}.{s}']][2], BONES[BI[f'{bn}.{s}']][3]
            L = np.linalg.norm(t - h); a = (t - h) / L
            m = name == f'{bn}.{s}'
            d = P[m] - h
            tt = d @ a / L
            r = d - np.outer(d @ a, a)
            r /= np.maximum(np.linalg.norm(r, axis=1, keepdims=True), 1e-9)
            fwd, lat = r[:, 2], r[:, 0] * sgn
            ids = np.zeros(m.sum(), dtype=np.int32)
            if bn == 'thigh':
                ids[(fwd > 0.25) & (tt > 0.12) & (tt < 0.93)] = MID['quads']
                ids[(fwd < -0.35) & (tt > 0.18) & (tt < 0.9)] = MID['hamstrings']
                ids[(lat < -0.55) & (tt > 0.05) & (tt < 0.62) & (fwd > -0.35)] = MID['adductors']
            elif bn == 'shin':
                ids[(fwd < -0.15) & (tt > 0.04) & (tt < 0.62)] = MID['calves']
            else:
                ids[(fwd > 0.3) & (tt > 0.3) & (tt < 0.95)] = MID['biceps']
                ids[(fwd < -0.3) & (tt > 0.25) & (tt < 0.95)] = MID['triceps']
                ids[tt < 0.3] = MID['delts']
            out[np.where(m)[0]] = ids
    # glutei e gluteo medio (bacino posteriore e laterale)
    pelv = np.isin(part, ['torso', 'thigh'])
    gl = pelv & (z < hipC[2] - 0.15) & (y > Y_HIP - 1.15) & (y < Y_HIP + 1.25) & (ax < 1.75) & (ax > 0.08)
    out[gl] = MID['glutes']
    gm = pelv & (ax > 1.05) & (y > Y_HIP + 0.05) & (y < Y_HIP + 1.35) & (z > hipC[2] - 0.75) & (z < hipC[2] + 0.55)
    out[gm] = MID['glutemed']
    tor = part == 'torso'
    zc = 0.25
    core = tor & (y > Y_HIP + 0.9) & (y < Y_SH - 1.45) & (z > zc - 0.1) & (ax < 1.45)
    out[core] = MID['core']
    lb = tor & (y > Y_HIP + 0.9) & (y < Y_SH - 2.0) & (z < zc - 0.25) & (ax < 1.0)
    out[lb] = MID['lowback']
    ch = tor & (y > Y_SH - 1.45) & (y < Y_SH - 0.05) & (z > zc + 0.15) & (ax > 0.12) & (ax < 1.45)
    out[ch] = MID['chest']
    ub = tor & (y > Y_SH - 2.0) & (y < Y_SH + 0.6) & (z < zc - 0.2) & (ax < 1.5)
    out[ub] = MID['upperback']
    cl = np.char.startswith(name, 'clav') & (ax > 1.1)
    out[cl] = MID['delts']
    return out


MUS = muscle_of(V, N_all, DOM)

# ------------------------------------------------------------------ texture procedurale
SKIN = np.array([212, 160, 128]) / 255.0
SKIN_SH = np.array([186, 128, 100]) / 255.0
TOP = np.array([35, 70, 200]) / 255.0        # blu dell'app
TOP_TRIM = np.array([235, 238, 245]) / 255.0
LEGGINGS = np.array([62, 72, 84]) / 255.0
LEG_STRIPE = np.array([96, 110, 126]) / 255.0
SHOE = np.array([238, 240, 242]) / 255.0
SOLE = np.array([150, 156, 162]) / 255.0
BROW = np.array([58, 38, 28]) / 255.0
LIP = np.array([176, 96, 92]) / 255.0


HAIR = np.array([56, 34, 22]) / 255.0


def hairline(P):
    d = P - HEADC
    a = np.abs(np.degrees(np.arctan2(d[:, 0], d[:, 2])))     # 0 davanti, 180 dietro
    return np.interp(a, [0, 15, 32, 50, 68, 86, 104, 122, 145, 165, 180], [8.03, 8.01, 7.95, 7.86, 7.74, 7.6, 7.52, 7.3, 7.06, 6.97, 6.95])


def hair_region(P, part):
    """0..1: quanto un punto è capelli (bordo sfumato di ~3 mm)."""
    yl = hairline(P)
    ear = (np.abs(P[:, 0]) > 0.76) & (P[:, 1] < 7.72) & (P[:, 2] > -0.05) & (P[:, 2] < 0.7)
    m = np.clip((P[:, 1] - yl) / 0.04 + 0.5, 0, 1)
    m[~np.isin(part, ['head', 'neck']) | ear] = 0
    return m


def paint(P, N, Wt):
    """Colore (n,3) per punti P della superficie in posa di riposo; Wt = pesi interpolati (n,nb)."""
    n = len(P)
    x, y, z = P[:, 0], P[:, 1], P[:, 2]
    ax = np.abs(x)
    dom = Wt.argmax(1)
    part = np.array([BONES[d][0].split('.')[0] for d in dom])
    col = np.tile(SKIN, (n, 1))
    # leggera variazione della pelle: più calda su guance e articolazioni, più chiara in alto
    rng = np.random.default_rng(3)
    col *= (1 + 0.02 * np.sin(x * 2.1 + 0.5) * np.cos(y * 1.3) + 0.015 * np.cos(z * 3.1))[:, None]
    # ----- leggings: dalla vita alla caviglia
    legpart = np.isin(part, ['torso', 'thigh', 'shin', 'foot', 'toes'])
    waist = Y_HIP + 1.05 + 0.06 * np.cos(np.arctan2(x, z - 0.2))  # vita alta, leggermente curva
    cuff = Y_ANKLE + 0.42
    leg = legpart & (y < waist) & (y > cuff)
    col[leg] = LEGGINGS
    # banda in vita e riga laterale
    band = leg & (y > waist - 0.22)
    col[band] = LEGGINGS * 0.82
    stripe = leg & np.isin(part, ['thigh', 'shin']) & (np.abs(np.abs(x) - (np.interp(y, [Y_ANKLE, Y_KNEE, Y_HIP], [1.75, 1.62, 1.55]) + 0.0)) < 0.07) & (np.abs(z - np.interp(y, [Y_ANKLE, Y_KNEE, Y_HIP], [0.25, 0.42, 0.25])) < 0.9)
    # ----- scarpe
    shoe = np.isin(part, ['foot', 'toes', 'shin']) & (y <= cuff) & (y < Y_ANKLE + 0.42)
    col[shoe] = SHOE
    col[shoe & (y < Y_SOLE + 0.22)] = SOLE
    lace = shoe & (y > Y_SOLE + 0.45) & (z > 0.75) & (np.abs(np.abs(x) - np.interp(z, [0.7, 1.6], [1.55, 1.62])) < 0.18) & (np.sin(z * 38) > 0.4)
    col[lace] = SOLE * 1.15
    # ----- top sportivo con schiena a vogatore
    torsoish = np.isin(part, ['torso', 'clav', 'neck'])
    yb = Y_SH - 1.62                       # fascia sotto il seno
    zmid = 0.18 + 0.1 * np.clip((y - yb) / 1.6, 0, 1)
    front = z > zmid
    sideish = ax > 1.0
    # davanti: scollo morbido + spalline che salgono verso la base del collo
    neck_y = yb + 1.02 + 0.42 * np.clip(ax / 0.72, 0, 1) ** 2
    sc = 0.80 - 0.2 * np.clip((y - (Y_SH - 0.75)) / 1.0, 0, 1)      # centro spallina
    strap_f = front & (np.abs(ax - sc) < 0.17) & (y < Y_SH + 0.62)
    panel_f = front & (y < neck_y) & (ax < 1.02)
    # fianchi: fino a poco sotto l'ascella
    side = sideish & (y < Y_SH - 0.88)
    # dietro: fascia più alta e vogatore che si stringe verso le scapole e poi va alle spalle
    tb = np.clip((y - (yb + 0.5)) / (Y_SH - 0.45 - (yb + 0.5)), 0, 1)
    racer_w = 0.98 - 0.72 * tb
    back_low = (~front) & (y < yb + 0.5)
    racer = (~front) & (ax < racer_w) & (y < Y_SH - 0.4)
    sb = 0.26 + 0.42 * np.clip((y - (Y_SH - 0.45)) / 0.9, 0, 1)        # spalline dietro verso le spalle
    strap_b = (~front) & (np.abs(ax - sb) < 0.16) & (y >= Y_SH - 0.5) & (y < Y_SH + 0.62)
    top = torsoish & (y > yb) & (panel_f | strap_f | side | back_low | racer | strap_b)
    col[top] = TOP
    trim = top & (y < yb + 0.12)
    col[trim] = TOP * 0.72
    edge = top & front & panel_f & (y > neck_y - 0.05) & ~strap_f
    col[edge] = TOP * 0.85
    # ----- capelli dipinti sul cranio (attaccatura morbida; la calotta in rilievo sta all'interno)
    hairmask = hair_region(P, part)
    hc = HAIR * (1 + 0.10 * np.sin(np.arctan2(x, z - 0.4) * 60 + y * 7))[:, None]
    col[hairmask > 0] = (col[hairmask > 0] * (1 - hairmask[hairmask > 0, None]) + hc[hairmask > 0] * hairmask[hairmask > 0, None])
    # ----- viso: sopracciglia e labbra
    for s, sx in (('L', 1), ('R', -1)):
        e = EYE[s]
        dx = (x - e[0]) * sx
        u = np.clip((dx + 0.16) / 0.5, 0, 1)                      # 0 interno, 1 coda
        arc = e[1] + 0.245 + 0.075 * np.sin(np.pi * np.clip(u / 0.72, 0, 1) * 0.5) * (u < 0.72) + (u >= 0.72) * (0.075 - 0.16 * (u - 0.72))
        thick = 0.026 * (1.15 - 0.75 * u)
        brow = (part == 'head') & (np.abs(y - arc) < thick) & (dx > -0.16) & (dx < 0.34) & (z > e[2] - 0.2)
        col[brow] = col[brow] * 0.45 + BROW * 0.55
    lip = (part == 'head') & (np.abs(x) < 0.215 * np.sqrt(np.clip(1 - ((y - LIPS[1]) / 0.11) ** 2, 0, 1))) & (np.abs(y - LIPS[1]) < 0.1) & (z > LIPS[2] - 0.15)
    col[lip] = col[lip] * 0.5 + LIP * 0.5
    # guance leggermente rosate
    for sx in (1, -1):
        d2 = ((x - 0.42 * sx) ** 2 + (y - 7.12) ** 2) / 0.09
        cheek = (part == 'head') & (z > 0.9)
        col[cheek] = col[cheek] * (1 - 0.06 * np.exp(-d2[cheek]))[:, None] + LIP * (0.06 * np.exp(-d2[cheek]))[:, None]
    return np.clip(col, 0, 1)


def bake_texture():
    S = TEX * SS
    uv = VT[body_tuv]                      # (t,3,2)
    pix = np.empty_like(uv)
    pix[..., 0] = uv[..., 0] * S
    pix[..., 1] = (1 - uv[..., 1]) * S
    tid = np.full((S, S), -1, dtype=np.int32)
    for k in range(len(pix)):
        cv2.fillConvexPoly(tid, np.round(pix[k] * 16).astype(np.int32), int(k), lineType=cv2.LINE_8, shift=4)
    ys, xs = np.nonzero(tid >= 0)
    t = tid[ys, xs]
    p = np.stack([xs + 0.5, ys + 0.5], 1)
    a, b, c = pix[t, 0], pix[t, 1], pix[t, 2]
    v0, v1, v2 = b - a, c - a, p - a
    d00 = (v0 * v0).sum(1); d01 = (v0 * v1).sum(1); d11 = (v1 * v1).sum(1)
    d20 = (v2 * v0).sum(1); d21 = (v2 * v1).sum(1)
    den = d00 * d11 - d01 * d01
    den[np.abs(den) < 1e-12] = 1e-12
    w1 = (d11 * d20 - d01 * d21) / den
    w2 = (d00 * d21 - d01 * d20) / den
    w0 = 1 - w1 - w2
    bc = np.clip(np.stack([w0, w1, w2], 1), 0, 1)
    bc /= bc.sum(1, keepdims=True)
    tri = body_tris[t]
    P = (V[tri] * bc[:, :, None]).sum(1)
    Nn = (N_all[tri] * bc[:, :, None]).sum(1)
    Wt = (W[tri] * bc[:, :, None]).sum(1)
    col = paint(P, Nn, Wt)
    img = np.zeros((S, S, 3), dtype=np.float32)
    img[ys, xs] = col
    mask = (tid >= 0).astype(np.uint8)
    # riempi i bordi delle isole UV per evitare cuciture
    img8 = (img * 255).astype(np.uint8)
    for _ in range(12):
        dil = cv2.dilate(img8, np.ones((3, 3), np.uint8))
        mdil = cv2.dilate(mask, np.ones((3, 3), np.uint8))
        grow = (mdil > 0) & (mask == 0)
        img8[grow] = dil[grow]
        mask = mdil
    img8 = cv2.resize(img8, (TEX, TEX), interpolation=cv2.INTER_AREA)
    # grana leggera del tessuto e della pelle
    noise = np.random.default_rng(7).normal(0, 2.2, img8.shape)
    img8 = np.clip(img8.astype(np.float32) + noise, 0, 255).astype(np.uint8)
    return img8


# ------------------------------------------------------------------ capelli
def build_hair():
    """Calotta che segue il cranio (offset lungo le normali) + chignon. Ritorna (P, N, C, tris, W)."""
    bverts = np.unique(body_tris)
    P = V; Nn = N_all
    c = HEADC
    head_part = np.isin(DOM, [BI['head'], BI['neck']])
    yl = hairline(P)
    sel = np.zeros(len(P), bool)
    sel[bverts] = True
    sel &= head_part & (P[:, 1] > yl + 0.02)
    ear = (np.abs(P[:, 0]) > 0.7) & (P[:, 1] < 7.85) & (P[:, 2] > -0.15) & (P[:, 2] < 0.8)
    sel &= ~ear
    tri = body_tris[np.all(sel[body_tris], axis=1)]
    used = np.unique(tri)
    # distanza (in passi) dal bordo per assottigliare la calotta all'attaccatura
    edge_count = {}
    for t in tri:
        for i in range(3):
            e = tuple(sorted((t[i], t[(i + 1) % 3])))
            edge_count[e] = edge_count.get(e, 0) + 1
    border = {v for e, k in edge_count.items() if k == 1 for v in e}
    adj = {v: set() for v in used}
    for t in tri:
        for i in range(3):
            adj[t[i]].add(t[(i + 1) % 3]); adj[t[(i + 1) % 3]].add(t[i])
    import heapq
    dist = {v: 0.0 for v in border}
    pq = [(0.0, v) for v in border]
    while pq:
        d0, v = heapq.heappop(pq)
        if d0 > dist.get(v, 1e9):
            continue
        for u in adj[v]:
            nd = d0 + float(np.linalg.norm(P[u] - P[v]))
            if nd < dist.get(u, 1e9):
                dist[u] = nd; heapq.heappush(pq, (nd, u))
    remap = {v: i for i, v in enumerate(used)}
    HP = np.zeros((len(used), 3)); HN = np.zeros((len(used), 3)); HW = np.zeros((len(used), len(BONES)))
    for v, i in remap.items():
        k = dist.get(v, 1.0)
        th = 0.003 + 0.065 * smooth(0.0, 0.45, k)
        top = max(0.0, (P[v, 1] - 7.9)) * 0.05
        HP[i] = P[v] + Nn[v] * (th + top)
        HN[i] = Nn[v]
        HW[i] = W[v]
    HT = np.vectorize(remap.get)(tri)
    # chignon: ellissoide in alto dietro
    bc = c + np.array([0.0, 0.62, -0.72])
    rad = np.array([0.5, 0.42, 0.46])
    nu, nv = 18, 12
    bp, bn, bt = [], [], []
    for i in range(nv + 1):
        th = math.pi * i / nv
        for j in range(nu):
            ph = 2 * math.pi * j / nu
            nrm = np.array([math.sin(th) * math.cos(ph), math.cos(th), math.sin(th) * math.sin(ph)])
            bp.append(bc + nrm * rad * (1 + 0.04 * math.sin(5 * ph + 3 * th)))
            g = nrm / rad; bn.append(g / np.linalg.norm(g))
    for i in range(nv):
        for j in range(nu):
            a0 = i * nu + j; a1 = i * nu + (j + 1) % nu; b0 = (i + 1) * nu + j; b1 = (i + 1) * nu + (j + 1) % nu
            bt += [[a0, b0, a1], [a1, b0, b1]]
    bp, bn, bt = np.array(bp), np.array(bn), np.array(bt) + len(HP)
    bw = np.zeros((len(bp), len(BONES))); bw[:, BI['head']] = 1
    P2 = np.vstack([HP, bp]); N2 = np.vstack([HN, bn]); T2 = np.vstack([HT, bt]); W2 = np.vstack([HW, bw])
    rng = np.random.default_rng(11)
    dd = P2 - HEADC
    streak = 1 + 0.10 * np.sin(np.arctan2(dd[:, 0], dd[:, 2] - 0.4) * 60 + P2[:, 1] * 7)
    C2 = np.clip(HAIR * streak[:, None] * (1 + rng.normal(0, 0.03, (len(P2), 1))), 0, 1)
    # elastico del chignon
    tie = np.linalg.norm((P2 - bc) / rad, axis=1)
    return P2, N2, C2, T2, W2


def build_eyes():
    out = []
    for s in 'LR':
        fl = faces_of(f'helper-{s.lower()}-eye')
        tri, _ = triangulate(fl)
        used = np.unique(tri)
        remap = {v: i for i, v in enumerate(used)}
        P = V[used]; c = P.mean(0)
        Nn = (P - c) / np.linalg.norm(P - c, axis=1, keepdims=True)
        fwd = np.array([0.03 if s == 'L' else -0.03, 0.0, 1.0]); fwd /= np.linalg.norm(fwd)
        cosang = Nn @ fwd
        C = np.tile(np.array([0.93, 0.92, 0.9]), (len(P), 1))
        C[cosang > 0.80] = np.array([0.36, 0.23, 0.14])
        C[cosang > 0.94] = np.array([0.05, 0.04, 0.04])
        T = np.vectorize(remap.get)(tri)
        Wt = np.zeros((len(P), len(BONES))); Wt[:, BI['head']] = 1
        out.append((P, Nn, C, T, Wt))
    lashes = []
    for s in 'lr':
        for k in (1, 2):
            fl = faces_of(f'helper-{s}-eyelashes-{k}')
            tri, _ = triangulate(fl)
            used = np.unique(tri); remap = {v: i for i, v in enumerate(used)}
            P = V[used]; Nn = N_all[used] if len(N_all) > used.max() else np.tile([0, 0, 1.0], (len(used), 1))
            Nn = np.tile([0, 0.3, 1.0], (len(used), 1)); Nn /= np.linalg.norm(Nn, axis=1, keepdims=True)
            C = np.tile(np.array([0.08, 0.06, 0.05]), (len(P), 1))
            T = np.vectorize(remap.get)(tri)
            Wt = np.zeros((len(P), len(BONES))); Wt[:, BI['head']] = 1
            lashes.append((P, Nn, C, T, Wt))
    return out + lashes


def merge(parts):
    P = np.vstack([p[0] for p in parts]); N = np.vstack([p[1] for p in parts]); C = np.vstack([p[2] for p in parts])
    T, off = [], 0
    for p in parts:
        T.append(p[3] + off); off += len(p[0])
    W2 = np.vstack([p[4] for p in parts])
    return P, N, C, np.vstack(T), W2


# ------------------------------------------------------------------ mesh del corpo con cuciture UV
def body_mesh():
    key = {}
    pos, nor, uv, wts, mus, idx = [], [], [], [], [], []
    for tri, tuv in zip(body_tris, body_tuv):
        for v, t in zip(tri, tuv):
            k = (v, t)
            if k not in key:
                key[k] = len(pos)
                pos.append(V[v]); nor.append(N_all[v]); uv.append(VT[t]); wts.append(W[v]); mus.append(MUS[v])
            idx.append(key[k])
    return np.array(pos), np.array(nor), np.array(uv), np.array(wts), np.array(mus), np.array(idx).reshape(-1, 3)


def top4(Wm):
    j = np.argsort(-Wm, axis=1)[:, :4]
    w = np.take_along_axis(Wm, j, 1)
    w /= np.maximum(w.sum(1, keepdims=True), 1e-9)
    return j.astype(np.uint8), w.astype(np.float32)


# ------------------------------------------------------------------ GLB
class GLB:
    def __init__(self):
        self.bin = bytearray(); self.views = []; self.acc = []

    def add(self, arr, target=None, comp=None, typ=None, minmax=False):
        arr = np.ascontiguousarray(arr)
        while len(self.bin) % 4:
            self.bin += b'\0'
        off = len(self.bin); data = arr.tobytes(); self.bin += data
        view = {'buffer': 0, 'byteOffset': off, 'byteLength': len(data)}
        if target: view['target'] = target
        self.views.append(view)
        if comp is None:
            return len(self.views) - 1
        a = {'bufferView': len(self.views) - 1, 'componentType': comp, 'count': int(arr.shape[0]), 'type': typ}
        if minmax:
            a['min'] = arr.min(0).tolist(); a['max'] = arr.max(0).tolist()
        self.acc.append(a)
        return len(self.acc) - 1


def main():
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    tex = bake_texture()
    Image.fromarray(tex).save(os.path.join(os.path.dirname(__file__), 'texture-preview.png'))
    buf = io.BytesIO(); Image.fromarray(tex).save(buf, 'JPEG', quality=88, optimize=True)
    g = GLB()
    # corpo
    bp, bn, buv, bw, bm, bi = body_mesh()
    j, w = top4(bw)
    prims = []
    attrs = {
        'POSITION': g.add(bp.astype(np.float32), 34962, 5126, 'VEC3', True),
        'NORMAL': g.add(bn.astype(np.float32), 34962, 5126, 'VEC3'),
        'TEXCOORD_0': g.add(np.stack([buv[:, 0], 1 - buv[:, 1]], 1).astype(np.float32), 34962, 5126, 'VEC2'),
        'JOINTS_0': g.add(j, 34962, 5121, 'VEC4'),
        'WEIGHTS_0': g.add(w, 34962, 5126, 'VEC4'),
        '_MUSCLE': g.add(bm.astype(np.float32), 34962, 5126, 'SCALAR'),
    }
    prims.append({'attributes': attrs, 'indices': g.add(bi.astype(np.uint16).reshape(-1), 34963, 5123, 'SCALAR'), 'material': 0})
    # occhi, ciglia, capelli
    hp, hn, hc, ht, hw = build_hair()
    ep, en, ec, et, ew = merge(build_eyes())
    for (P, Nn, C, T, Wm), mat in (((ep, en, ec, et, ew), 1), ((hp, hn, hc, ht, hw), 2)):
        jj, ww = top4(Wm)
        a2 = {
            'POSITION': g.add(P.astype(np.float32), 34962, 5126, 'VEC3', True),
            'NORMAL': g.add(Nn.astype(np.float32), 34962, 5126, 'VEC3'),
            'COLOR_0': g.add(C.astype(np.float32), 34962, 5126, 'VEC3'),
            'JOINTS_0': g.add(jj, 34962, 5121, 'VEC4'),
            'WEIGHTS_0': g.add(ww, 34962, 5126, 'VEC4'),
        }
        prims.append({'attributes': a2, 'indices': g.add(T.astype(np.uint16).reshape(-1), 34963, 5123, 'SCALAR'), 'material': mat})
    img_view = g.add(np.frombuffer(buf.getvalue(), dtype=np.uint8))
    # scheletro: nodi con sola traslazione, bind = riposo
    nodes = []
    for i, (name, par, h, t) in enumerate(BONES):
        ph = BONES[BI[par]][2] if par else np.zeros(3)
        nodes.append({'name': name, 'translation': (h - ph).tolist(), 'children': [k for k, b in enumerate(BONES) if b[1] == name],
                      'extras': {'tail': t.tolist(), 'head': h.tolist()}})
    ibm = np.zeros((len(BONES), 16), dtype=np.float32)
    for i, (_, _, h, _) in enumerate(BONES):
        m = np.eye(4, dtype=np.float32); m[:3, 3] = -h
        ibm[i] = m.T.reshape(-1)
    ibm_acc = g.add(ibm, None, 5126, 'MAT4')
    mesh_node = len(nodes)
    nodes.append({'name': 'atleta', 'mesh': 0, 'skin': 0})
    gltf = {
        'asset': {'version': '2.0', 'generator': 'Forma build_model.py (MakeHuman CC0)', 'copyright': 'Corpo da MakeHuman, CC0 1.0'},
        'scene': 0, 'scenes': [{'nodes': [0, mesh_node]}],
        'nodes': nodes,
        'skins': [{'joints': list(range(len(BONES))), 'inverseBindMatrices': ibm_acc, 'skeleton': 0}],
        'meshes': [{'name': 'atleta', 'primitives': prims}],
        'materials': [
            {'name': 'pelle-abiti', 'pbrMetallicRoughness': {'baseColorTexture': {'index': 0}, 'metallicFactor': 0, 'roughnessFactor': 0.7}},
            {'name': 'occhi', 'pbrMetallicRoughness': {'metallicFactor': 0, 'roughnessFactor': 0.2}},
            {'name': 'capelli', 'pbrMetallicRoughness': {'metallicFactor': 0, 'roughnessFactor': 0.5}},
        ],
        'textures': [{'source': 0}],
        'images': [{'bufferView': img_view, 'mimeType': 'image/jpeg'}],
        'accessors': g.acc, 'bufferViews': g.views,
        'buffers': [{'byteLength': len(g.bin)}],
        'extras': {'muscles': MUSCLES, 'units': 'dm', 'ground': float(Y_SOLE)},
    }
    js = json.dumps(gltf, separators=(',', ':')).encode()
    while len(js) % 4:
        js += b' '
    while len(g.bin) % 4:
        g.bin += b'\0'
    total = 12 + 8 + len(js) + 8 + len(g.bin)
    with open(OUT, 'wb') as f:
        f.write(struct.pack('<III', 0x46546C67, 2, total))
        f.write(struct.pack('<II', len(js), 0x4E4F534A)); f.write(js)
        f.write(struct.pack('<II', len(g.bin), 0x004E4942)); f.write(bytes(g.bin))
    print('scritto', OUT, round(total / 1024), 'KB; vertici corpo', len(bp), 'tri', len(bi), '; capelli', len(hp), '; ossa', len(BONES))
    print('muscoli', {m: int((MUS == i).sum()) for i, m in enumerate(MUSCLES)})


if __name__ == '__main__':
    main()
