"""Forma — costruzione del modello 3D femminile a partire dalla mesh base di MakeHuman (CC0).

Uso: python3 tools/model/mh.py <cartella data di makehuman> <uscita.glb>

Passi: carica base.obj, applica i target (donna giovane, tonica), calcola lo scheletro e i pesi,
crea capelli raccolti e una texture procedurale con abbigliamento sportivo, esporta un GLB con skinning.
"""
import json, os, sys, math, struct
import numpy as np

DATA = sys.argv[1] if len(sys.argv) > 1 else 'makehuman/data'


# ---------------------------------------------------------------- mesh base
def load_obj(path):
    V, VT, faces, fuv, groups = [], [], [], [], []
    g = None
    with open(path) as f:
        for line in f:
            if line.startswith('v '):
                V.append([float(x) for x in line.split()[1:4]])
            elif line.startswith('vt '):
                VT.append([float(x) for x in line.split()[1:3]])
            elif line.startswith('g '):
                g = line.split()[1]
            elif line.startswith('f '):
                parts = line.split()[1:]
                vi = [int(p.split('/')[0]) - 1 for p in parts]
                ti = [int(p.split('/')[1]) - 1 if '/' in p and p.split('/')[1] else -1 for p in parts]
                faces.append(vi); fuv.append(ti); groups.append(g)
    return np.array(V, dtype=np.float64), np.array(VT, dtype=np.float64), faces, fuv, groups


def load_target(path):
    idx, d = [], []
    with open(path) as f:
        for line in f:
            if not line.strip() or line.startswith('#'):
                continue
            p = line.split()
            idx.append(int(p[0])); d.append([float(p[1]), float(p[2]), float(p[3])])
    return np.array(idx, dtype=np.int64), np.array(d, dtype=np.float64)


def apply_target(V, name, w):
    if abs(w) < 1e-6:
        return
    path = os.path.join(DATA, 'targets', name)
    idx, d = load_target(path)
    if len(idx):
        V[idx] += d * w


def tri_weights(v, names):
    """Valore 0..1 → pesi per (min, average, max) come in MakeHuman."""
    lo, mid, hi = names
    if v < 0.5:
        return {lo: (0.5 - v) * 2, mid: v * 2}
    return {mid: (1 - v) * 2, hi: (v - 0.5) * 2}


def build_body(V, P):
    gender = 'female'
    age = 'young'
    muscle = tri_weights(P['muscle'], ('minmuscle', 'averagemuscle', 'maxmuscle'))
    weight = tri_weights(P['weight'], ('minweight', 'averageweight', 'maxweight'))
    # etnia
    for race, w in P['race'].items():
        apply_target(V, f'macrodetails/{race}-{gender}-{age}.target', w)
    for m, wm in muscle.items():
        for wt, ww in weight.items():
            base = f'{gender}-{age}-{m}-{wt}'
            apply_target(V, f'macrodetails/universal-{base}.target', wm * ww)
            h = P['height']
            if h > 0.5:
                apply_target(V, f'macrodetails/height/{base}-maxheight.target', wm * ww * (h - 0.5) * 2)
            elif h < 0.5:
                apply_target(V, f'macrodetails/height/{base}-minheight.target', wm * ww * (0.5 - h) * 2)
            pr = P['proportions']
            if pr > 0.5:
                apply_target(V, f'macrodetails/proportions/{base}-idealproportions.target', wm * ww * (pr - 0.5) * 2)
            # seno: dimensione e tonicità
            cup = tri_weights(P['cup'], ('mincup', 'averagecup', 'maxcup'))
            firm = tri_weights(P['firm'], ('minfirmness', 'averagefirmness', 'maxfirmness'))
            for c, wc in cup.items():
                for fm, wf in firm.items():
                    if c == 'averagecup' and fm == 'averagefirmness':
                        continue
                    fn = f'breast/{base}-{c}-{fm}.target'
                    if os.path.exists(os.path.join(DATA, 'targets', fn)):
                        apply_target(V, fn, wm * ww * wc * wf)
    for name, w in P.get('extra', {}).items():
        apply_target(V, name, w)


PARAMS = {
    'race': {'caucasian': 0.7, 'african': 0.15, 'asian': 0.15},
    'muscle': 0.62, 'weight': 0.46, 'height': 0.55, 'proportions': 0.8,
    'cup': 0.5, 'firm': 0.75,
    'extra': {
        'buttocks/buttocks-volume-incr.target': 0.3,
        'stomach/stomach-pregnant-decr.target': 0.35,
    },
}


if __name__ == '__main__' and len(sys.argv) > 2 and sys.argv[2] == '--report':
    V, VT, faces, fuv, groups = load_obj(os.path.join(DATA, '3dobjs', 'base.obj'))
    build_body(V, PARAMS)
    sk = json.load(open(os.path.join(DATA, 'rigs', 'default.mhskel')))
    J = {k: V[v].mean(axis=0) for k, v in sk['joints'].items()}
    def bone(b):
        bb = sk['bones'][b]
        return J[bb['head']], J[bb['tail']]
    body_idx = sorted({i for f, g in zip(faces, groups) if g == 'body' for i in f})
    ys = V[body_idx][:, 1]
    print('altezza (dm)', ys.max() - ys.min(), 'min y', ys.min())
    for b in ['upperleg01.L', 'upperleg02.L', 'lowerleg01.L', 'lowerleg02.L', 'foot.L', 'upperarm01.L', 'upperarm02.L', 'lowerarm01.L', 'lowerarm02.L', 'wrist.L', 'spine05', 'spine01', 'neck01', 'head', 'clavicle.L', 'shoulder01.L', 'pelvis.L', 'root']:
        h, t = bone(b)
        print(f'{b:14s} head {np.round(h,3)} tail {np.round(t,3)} len {np.linalg.norm(t-h):.3f}')
