# Il programma di Forma

Forma è pensata per chi ha 30–45 minuti, si allena in casa e vuole rassodare tutto il corpo con priorità a gambe e glutei. Il programma unisce le linee guida e le revisioni sistematiche più recenti sull’allenamento di forza (elenco completo in fondo) ai vincoli reali: poco tempo, nessun attrezzo all’inizio, nessuno che controlli l’esecuzione.

Lo stesso testo, in forma più breve, è nella scheda **Guida** dell’app.

## In breve

- **Frequenza**: 3 sessioni a settimana consigliate; funziona anche con 2 o 4.
- **Durata**: 30–45 minuti la sessione completa (circa 25 nelle prime settimane), 15–25 la versione rapida. Se la stima supera il tetto (45 minuti, 25 nella versione rapida), l’app toglie prima il finisher, poi accorcia i recuperi, poi una serie agli esercizi accessori e solo alla fine ai principali, mai sotto le 2 serie.
- **Struttura**: corpo intero ogni volta, in superserie (due o tre esercizi di zone diverse alternati). Gambe e glutei ricevono circa il doppio delle serie della parte alta.
- **Progressione**: ogni movimento ha una scala di varianti dalla più facile alla più difficile. Quando chiudi tutte le serie al massimo della fascia di ripetizioni, passi alla variante successiva.
- **Sforzo**: regolato con le ripetizioni in riserva, cioè quante ne avresti ancora potute fare: 3 nelle prime settimane, poi 2, poi 0–1.
- **Controlli**: test iniziale, poi test di controllo nelle settimane leggere, circa ogni 6 settimane.

## Prima di iniziare

**Sicurezza.** Al primo avvio l’app pone sette domande ispirate al questionario PAR‑Q+. Un sì non esclude l’allenamento, ma va prima parlato con il medico o con uno specialista in medicina dello sport.

**Test iniziale.** Circa 10 minuti dopo un breve riscaldamento. I risultati scelgono il livello di partenza di ogni scala.

| Test | Come si esegue | Cosa decide |
|---|---|---|
| Squat a corpo libero | Più ripetizioni possibili con tecnica pulita, circa una ogni 2 secondi | Squat, affondi, step-up |
| Ponte su una gamba | Più ripetizioni possibili per lato, 1 minuto tra i lati; conta il lato più debole | Ponte e hip thrust, stacchi, femorali, gluteo medio |
| Piegamenti | La variante più difficile in cui fai almeno 5 ripetizioni: inclinati, sulle ginocchia o classici | Piegamenti |
| Plank sugli avambracci | Finché il bacino resta in linea | Core anteriore e laterale |

Per esempio, con 20 squat, 10 ponti per lato, 10 piegamenti sulle ginocchia e 40 secondi di plank si parte da squat a corpo libero, split squat, ponte con pausa in alto, good morning, piegamenti sulle ginocchia, dead bug e plank laterale.

## Le fasi

| Fase | Settimane | Ripetizioni in riserva | Recupero tra i giri | Cosa cambia |
|---|---|---|---|---|
| 1. Fondamenta | 1–4 | 3 | 50 s (40 s nel blocco finale) | Si imparano i movimenti con tempo 2‑1‑2: 2 secondi in discesa, 1 di pausa, 2 in salita. Le prime due settimane hanno 2 serie per esercizio, poi 3. |
| 2. Costruzione | 5–10 | 2 | 60 s (40 s) | Più serie per glutei e gambe, lavoro su una gamba, femorali con l’asciugamano. Finisher di 4 minuti nelle sessioni A e C. La settimana 10 è leggera, con test. |
| 3. Intensificazione | 11–16 | 0–1 | 60–75 s (40 s) | 4 serie sugli esercizi principali; nell’ultima si arriva al cedimento tecnico e si aggiungono fino a 5 ripetizioni parziali nella parte bassa del movimento. La settimana 16 è leggera, con test. |
| 4. Cicli | dalla 17 | 0–1 | secondo il ciclo | Blocchi di 6 settimane, 5 di lavoro e 1 leggera con test, che ruotano tre accenti. |

I tre cicli si alternano in quest’ordine e poi ricominciano:

- **Carico**: recuperi più lunghi di 15 secondi; si spinge sul livello delle varianti e sul carico.
- **Volume glutei**: una serie in più su ponte e hip thrust e sul gluteo medio.
- **Densità**: recuperi più corti di 15 secondi e finisher in ogni sessione.

Altre regole del calendario:

- **Settimana leggera**: una serie in meno per esercizio, 3 ripetizioni in riserva, test di controllo alla prima sessione.
- **Rientro**: dopo più di 10 giorni di stop la sessione successiva è alleggerita in automatico.
- **Mantenimento**: modalità per i periodi pieni, da attivare nella scheda Programma. Due sessioni a settimana, 2 serie per esercizio vicino al cedimento: basta per conservare forza e massa muscolare.

## Com’è fatta una sessione

1. **Riscaldamento**, circa 4 minuti: marcia sul posto, gatto‑cammello, good morning, ponte, squat, affondo indietro. Nella versione rapida tre esercizi.
2. **Tre blocchi in superserie.** Primo blocco: l’esercizio principale per le gambe con uno per la parte alta. Secondo: ponte o stacco con un altro esercizio per la parte alta. Terzo: gluteo medio, femorali o polpacci con il core. Tra un esercizio e l’altro dello stesso blocco ci sono 12 secondi per cambiare posizione, tra un giro e l’altro il recupero della fase. Così ogni muscolo riposa 90–150 secondi tra due serie e la sessione resta nei tempi.
3. **Finisher**, facoltativo, 4 minuti quando previsto: a basso impatto nella fase 2; nella fase 3 con o senza salti, oppure swing con la kettlebell se ce l’hai.
4. **Defaticamento**, 2–3 minuti: allungamento dei flessori dell’anca, posizione del bambino, respirazione.

Il player guida ogni passaggio con timer, voce e indicazioni tecniche. Dopo l’ultima serie di ogni esercizio chiede le ripetizioni fatte, quante ne restavano e se c’è stato dolore.

### Le sessioni della settimana

Le sessioni ruotano: A e B con 2 giorni a settimana, A, B e C con 3, da A a D con 4. Con 2 giorni gli esercizi principali hanno una serie in più (al massimo 4), così il volume per gambe e glutei resta vicino a quello dei 3 giorni.

Il numero dopo ogni esercizio indica le serie. Dove ci sono due alternative, l’app usa la prima se hai l’attrezzo o il livello necessario: lo step‑up richiede uno step o un gradino, le spalle (pike push‑up) si sbloccano quando arrivi ai piegamenti classici.

**Fase 1, Fondamenta** (nelle prime due settimane 2 serie al posto di 3)

| | Blocco 1 | Blocco 2 | Blocco 3 |
|---|---|---|---|
| A | Squat 3 + Piegamenti 3 | Ponte 3 + Rematore 3 | Gluteo medio 2 + Core anteriore 2 |
| B | Affondi 3 + Rematore 3 | Stacco 3 + Piegamenti 3 | Ponte 2 + Core laterale 2 |
| C | Ponte 3 + Piegamenti 3 | Squat 3 + Dorso alto 3 | Gluteo medio 2 + Core anteriore 2 |
| D | Ponte 3 + Gluteo medio 3 | Affondi 2 + Core laterale 2 | |

**Fase 2, Costruzione**

| | Blocco 1 | Blocco 2 | Blocco 3 |
|---|---|---|---|
| A | Affondi o squat bulgaro 3 + Piegamenti 3 | Ponte o hip thrust 3 + Rematore 3 | Gluteo medio 3 + Core anteriore 2 + Polpacci 2, finisher |
| B | Squat 3 + Rematore 3 | Stacco 3 + Piegamenti 3 | Femorali 3 + Gluteo medio 2 + Core laterale 2 |
| C | Step‑up o affondi 3 + Spalle o piegamenti 3 | Ponte o hip thrust 3 + Dorso alto 3 | Gluteo medio 3 + Core anteriore 2, finisher |
| D | Ponte o hip thrust 3 + Gluteo medio 3 | Affondi 3 + Stacco 3 | Femorali 2 |

**Fase 3, Intensificazione, e cicli** (l’asterisco indica l’ultima serie al cedimento tecnico con parziali in basso)

| | Blocco 1 | Blocco 2 | Blocco 3 |
|---|---|---|---|
| A | Affondi o squat bulgaro 4* + Piegamenti 3 | Ponte o hip thrust 4* + Rematore 3 | Gluteo medio 3 + Core anteriore 2, finisher |
| B | Squat 3 + Rematore 3 | Stacco 4* + Piegamenti 3 | Femorali 3 + Core laterale 2 + Polpacci 2 |
| C | Step‑up o affondi 4* + Spalle o piegamenti 3 | Ponte o hip thrust 3 + Dorso alto 3 | Gluteo medio 3 + Core anteriore 2, finisher |
| D | Ponte o hip thrust 4* + Gluteo medio 3 | Stacco 3 + Femorali 3 | |

### Serie a settimana e durata

Con 3 sessioni a settimana e livelli intermedi. La durata varia con le varianti: quelle su una gamba richiedono più tempo.

| Settimana | Fase | Glutei e femorali | Squat, affondi, polpacci | Spinta | Tirata | Core | Durata stimata |
|---|---|---|---|---|---|---|---|
| 1 | Fondamenta | 12 | 6 | 6 | 6 | 6 | 23–25 min |
| 3 | Fondamenta | 15 | 9 | 9 | 9 | 6 | 29–31 min |
| 5 | Costruzione | 20 | 11 | 9 | 9 | 6 | 34–39 min |
| 11 | Intensificazione | 20 | 13 | 9 | 9 | 6 | 38–42 min |
| 17 | Ciclo Carico | 20 | 13 | 9 | 9 | 6 | 40–44 min |
| 23 | Ciclo Volume glutei | 24 | 13 | 9 | 9 | 6 | 38–42 min |
| 29 | Ciclo Densità | 20 | 13 | 9 | 9 | 6 | 37–41 min |

Squat e affondi lavorano molto anche i glutei: in totale la parte bassa passa da 18 serie a settimana all’inizio a 33–37 nelle fasi avanzate, mentre la parte alta resta intorno alle 9 serie per spinta e tirata, vicino al minimo efficace di circa 10 serie indicato dalla posizione ACSM.

## Le scale di esercizi

Regole di progressione, applicate dall’app alla fine di ogni sessione:

- Ogni variante ha una fascia di ripetizioni, per esempio 8–15.
- Se chiudi tutte le serie al massimo della fascia, alla sessione successiva passi alla variante più difficile.
- Se resti sotto il minimo per due sessioni di fila, torni alla variante precedente.
- Se segnali dolore, non semplice fatica, il livello resta fermo; se succede di nuovo la volta dopo, torni alla variante precedente.
- Negli altri casi l’obiettivo della volta dopo è la tua serie migliore più una ripetizione (più 5 secondi negli esercizi a tempo), purché lo sforzo sia stato nel bersaglio della fase.
- Negli esercizi su una gamba conta il lato più debole.
- Le varianti che richiedono un attrezzo che non hai vengono saltate. All’ultima variante disponibile l’app suggerisce di aggiungere carico allo zaino o di rallentare la discesa.
- Puoi sempre cambiare livello a mano dalla scheda Programma.

Nelle varianti “3‑1‑1” scendi in 3 secondi, fai 1 secondo di pausa e sali in 1; nelle “1½” fai una ripetizione completa più mezza ripetizione dal basso. Le fasce sono ripetizioni per serie, per lato negli esercizi su una gamba.

- **Squat**: squat alla sedia (8–15) → squat assistito con le cinghie (10–20) → squat a corpo libero (10–20) → squat 3‑1‑1 (10–20) → squat 1½ (8–15) → goblet squat con carico (8–15) → squat sumo con carico (8–15) → goblet squat con pausa (8–12).
- **Affondi e squat bulgaro**: split squat con appoggio (6–12) → split squat (8–15) → affondo indietro (8–15) → affondo indietro scivolato (8–12) → split squat con carico (8–12) → split squat con piede avanti rialzato (8–12) → squat bulgaro (8–15) → squat bulgaro 3‑1‑1 (8–12) → squat bulgaro con carico (8–12) → squat bulgaro 1½ con carico (6–10).
- **Step‑up**, con step o gradino: step‑up basso (8–15) → step‑up alto (8–12) → step‑up con carico (8–12).
- **Ponte e hip thrust**: ponte (12–20) → ponte con pausa in alto (10–20) → hip thrust al divano (10–20) → ponte su una gamba (8–15) → hip thrust su una gamba (8–15) → hip thrust con carico (8–15).
- **Stacchi**: hip hinge al muro (10–15) → good morning (10–15) → stacco da terra con carico (8–15) → stacco rumeno su una gamba con appoggio (8–12) → stacco rumeno su una gamba (8–12) → stacco rumeno con carico (8–15) → stacco rumeno su una gamba con carico (8–12).
- **Femorali**: walkout (6–10) → leg curl da prono con cavigliere (10–20) → leg curl con fitball (8–15) → leg curl con le cinghie (8–15) → leg curl eccentrico con asciugamano (6–10) → leg curl con asciugamano (8–15) → leg curl con fitball su una gamba (6–12) → leg curl su una gamba con asciugamano (6–12).
- **Gluteo medio**: conchiglia (12–25) → conchiglia con mini band (12–20) → abduzione su un fianco (12–20) → idrante (10–20) → abduzione con pausa (10–15) → abduzione con cavigliere (10–20) → abduzione con mini band (10–20) → passi laterali con mini band (10–20) → plank laterale con abduzione (6–12).
- **Slanci per i glutei** (compaiono nelle sessioni solo se hai cavigliere o elastici): slancio indietro in quadrupedia (12–20) → con elastico (10–20) → con cavigliere (10–20).
- **Polpacci**: sollevamenti sui polpacci (15–25) → su una gamba (10–20) → su una gamba con carico (10–20).
- **Piegamenti**: al muro (10–20) → inclinati al piano della cucina (8–15) → inclinati al divano (8–15) → sulle ginocchia (8–15) → classici (6–15) → 3‑1‑1 (6–12) → con piedi rialzati (6–12) → con elastico (6–12).
- **Spalle**: pike push‑up (5–12) → spinta sopra la testa a un braccio con manubrio o kettlebell (6–12) → pike push‑up con piedi rialzati (5–10).
- **Rematori**: sollevamenti a Y da prono (8–15) → rematore inclinato con le cinghie (10–20) → rematore piegato con manubri o zaino (8–15) → rematore con elastico da seduta (10–20) → rematore con le cinghie (8–15) → rematore piegato con pausa (8–12) → rematore a un braccio (8–12).
- **Dorso alto**, senza sbarra: sollevamenti a Y da prono (8–15) → pull‑apart con elastico (12–20) → lat machine con elastico (12–20).
- **Trazioni**, con la sbarra al posto del dorso alto: scapole alla sbarra (6–12) → trazione negativa (3–8) → trazione assistita con elastico (5–10) → trazione (3–10).
- **Core anteriore**: bird dog (6–10) → dead bug solo gambe (6–10) → dead bug (8–12) → plank (20–45 s) → rollout con fitball (6–12) → plank con tocco della spalla (8–16) → ginocchia al petto alla sbarra (6–15) → plank a leva lunga (15–40 s).
- **Core laterale**: plank laterale sulle ginocchia (15–30 s) → plank laterale (20–45 s) → Pallof press con elastico (8–12) → plank laterale con abduzione (6–12).

Le varianti che richiedono un attrezzo che non hai vengono saltate: ogni scala si accorcia o si allunga in base a quello che selezioni.

## Attrezzatura e piani dedicati

Nella schermata **Attrezzatura** selezioni cosa hai e, per kettlebell, manubri e cavigliere, quali pesi; per lo zaino il carico massimo che riesci a metterci. Il piano si rigenera subito e il riquadro *Il tuo piano* mostra cosa cambia rispetto al corpo libero.

| Attrezzo | Cosa cambia nel piano |
|---|---|
| Zaino, kettlebell, manubri | Goblet squat, squat sumo, stacchi, hip thrust, split squat e squat bulgaro con carico, rematori e spinte. L’app sceglie l’attrezzo più adatto a ogni esercizio (per esempio kettlebell per il goblet squat, manubri per il rematore) e il peso di partenza. |
| Mini band ed elastico lungo | Conchiglie, abduzioni e passi laterali per il gluteo medio; rematore, lat machine, pull‑apart, Pallof press, piegamenti con elastico e trazioni assistite. Con gli elastici compaiono anche gli slanci per i glutei. |
| Cavigliere | Leg curl da prono, abduzioni e slanci con carico; gli slanci vengono aggiunti alle sessioni B (e D con 4 giorni). |
| Sbarra per trazioni | La tirata verticale diventa una progressione di trazioni; per il core, ginocchia al petto alla sbarra. |
| Cinghie in sospensione | Squat assistito, rematori inclinati e leg curl con le cinghie. |
| Fitball | Leg curl (anche su una gamba) e rollout. |
| Step o gradino | Step‑up al posto degli affondi nella sessione C. |

**Progressione sul peso.** Negli esercizi con carico, quando chiudi tutte le serie al massimo della fascia l’app propone prima il peso successivo tra quelli che hai (lo zaino sale di 1 kg alla volta) e solo dopo, raggiunto il peso più alto, la variante più difficile. Se resti sotto la fascia per due sessioni torna al peso precedente. Il peso da usare è indicato nella sessione, nel player e annunciato dalla voce.

## La figura in 3D

Gli esercizi sono dimostrati da un’atleta in 3D, costruita sulla mesh umana di MakeHuman (licenza CC0) con abbigliamento sportivo, animata con le stesse pose degli esercizi e con i muscoli che lavorano evidenziati in rosso. Se il telefono non supporta il 3D, o se lo spegni nelle Impostazioni, l’app usa figure essenziali in 2D.

## Attrezzatura: cosa comprare e quando

Si parte senza spendere nulla. Gli acquisti servono quando le varianti a corpo libero diventano troppo facili, non prima.

**Da subito, gratis**

- Uno zaino da caricare con libri o bottiglie d’acqua (1 litro = 1 kg): goblet squat, rematore, hip thrust e stacchi. Chiudi bene il carico e proteggi la schiena con un asciugamano.
- Una sedia robusta appoggiata al muro e il divano: squat bulgaro, hip thrust, piegamenti inclinati.
- Un asciugamano o delle calze su parquet o piastrelle: leg curl.
- Un tappetino o una coperta piegata.

**Primo acquisto, il più utile per i glutei (25–45 € in tutto)**

- Set di mini band in tessuto, circa 15–26 €: sblocca abduzioni con elastico e passi laterali per il gluteo medio. Il tessuto non si arrotola e non pizzica.
- Elastico lungo o tubo con maniglie, circa 10–20 €: rematore e pull‑apart, cioè la parte alta che senza attrezzi resta più scoperta.

**Secondo acquisto, quando il corpo libero non basta più**

- Una kettlebell, circa 35–45 € per 12 kg (da Decathlon a ottobre 2026 i modelli da 12 kg andavano da circa 35 a 43 €, altri marchi fino a circa 67 €). Indicativamente 8–12 kg per iniziare se non ti alleni con i pesi, 12–16 kg se sei già allenato; più avanti una seconda più pesante, 16–20 kg, per ponte e stacchi. Occupa lo spazio di una scatola da scarpe.
- Uno step stabile, circa 20–35 €, facoltativo: sblocca gli step‑up, tra gli esercizi con l’attivazione dei glutei più alta. Va bene anche uno scalino di casa.
- In alternativa o in aggiunta alla kettlebell, una coppia di manubri: circa 20–35 € per 2 × 4 kg.
- Facoltativi, in base a cosa ti manca: cavigliere 2 × 1 kg (12–20 €) per gli slanci dei glutei, una sbarra da porta (20–30 €) per le trazioni, cinghie in sospensione (25–40 €) per rematori e leg curl, una fitball (17–20 €) per leg curl e rollout.

Sulla kettlebell in sé le prove scientifiche sono ancora poche e di bassa qualità (fonte 23): qui è usata semplicemente come carico comodo da tenere in casa.

## Rassodare: cosa conta oltre all’allenamento

- Il “rassodamento” è la somma di due cose: più massa muscolare e meno grasso sopra il muscolo. L’allenamento di forza fa crescere il muscolo e da solo riduce un po’ il grasso: in media circa 1,5 punti percentuali di grasso corporeo e mezzo chilo di massa grassa, compreso il grasso viscerale.
- Il grasso non si consuma nel punto che alleni. In uno studio di dodici settimane in cui si allenava una sola gamba con migliaia di ripetizioni, il grasso è calato nel tronco e nelle braccia, non nella gamba allenata. Per ridurre il grasso su cosce e glutei servono un leggero deficit calorico e movimento quotidiano.
- L’OMS raccomanda 150–300 minuti a settimana di attività aerobica moderata oltre alla forza: camminate veloci, bici, scale. Contare i passi è un modo semplice per arrivarci.
- Proteine: oltre circa 1,6 g per kg di peso al giorno non si sono visti ulteriori guadagni di massa magra; per una persona di 65 kg sono circa 105 g al giorno, divisi su 3–4 pasti. Dormire 7–9 ore aiuta il recupero.
- Per vedere i cambiamenti usa il metro (vita, fianchi, coscia) e foto nelle stesse condizioni ogni 4 settimane: la bilancia da sola può restare ferma mentre il muscolo cresce e il grasso cala.
- Nelle prime settimane migliorano soprattutto forza e ripetizioni nei test, perché il sistema nervoso impara i movimenti. Per vedere cambiamenti di forma servono di solito almeno 8–12 settimane di costanza, e molto dipende da alimentazione e grasso corporeo.

## Sicurezza

- Se rispondi sì ad almeno una delle domande iniziali, parlane con il medico o con uno specialista in medicina dello sport prima di aumentare l’attività.
- Fermati subito e chiedi aiuto in caso di dolore o oppressione al petto, fiato corto sproporzionato, capogiri, palpitazioni o dolore improvviso a un’articolazione.
- L’indolenzimento dei giorni successivi è normale, soprattutto nelle prime settimane e quando cambi variante. Il dolore articolare acuto no: segnalalo nella registrazione della serie; se si ripete, l’app torna alla variante più facile. Se resta anche così, sospendi l’esercizio e fallo valutare.
- Respira durante lo sforzo: espira nella fase di spinta e non trattenere il fiato a lungo, in particolare se hai la pressione alta.
- In gravidanza, dopo un intervento o con patologie croniche il programma va adattato con il medico.
- Forma è uno strumento di allenamento e non sostituisce una valutazione medica.

## Su cosa si basa

| Indicazione | Come è applicata | Fonti |
|---|---|---|
| Il salto più grande nei risultati è tra nessun allenamento di forza e uno qualsiasi; minimo 2 giorni a settimana per tutti i grandi gruppi muscolari | Sessioni corte, versione rapida, calendario da 2 a 4 giorni | 1, 2 |
| Elastici, corpo libero e programmi domestici danno guadagni veri di forza e massa | Tutto il programma funziona con corpo, sedia, divano e zaino | 1, 12 |
| Con serie vicine al cedimento, carichi leggeri e pesanti danno crescita muscolare simile; la crescita aumenta avvicinandosi al cedimento | Sforzo regolato con varianti e ripetizioni in riserva, da 3 a 0–1 | 3, 4 |
| Il volume settimanale ha la relazione dose‑risposta più chiara per l’ipertrofia; circa 10 serie a settimana per gruppo muscolare | Volume più alto per glutei e gambe, crescente fase dopo fase | 1, 5, 6 |
| Hip thrust e squat danno crescita dei glutei simile; lo squat profondo fa crescere i glutei più del mezzo squat; step‑up, affondi, split squat, hip thrust e stacchi attivano molto il grande gluteo | Ogni sessione unisce uno squat o affondo profondo, un ponte o hip thrust, uno stacco e il gluteo medio | 8, 9, 10 |
| Il movimento completo, o le parziali con il muscolo allungato, rendono più delle parziali con il muscolo accorciato | Discese controllate, pause in basso, piede rialzato, parziali in basso nella fase 3 | 11 |
| Oltre 60 s di recupero c’è un piccolo vantaggio, oltre 90 s nessuna differenza; le superserie fanno risparmiare tempo | Superserie con 90–150 s tra due serie dello stesso muscolo | 7, 13 |
| A parità di volume la periodizzazione cambia poco per la massa; una settimana di pausa non riduce la crescita | Fasi graduali e settimana leggera con test | 1, 14, 15 |
| In media si sottostimano di circa una ripetizione quelle rimaste, di più oltre le 12 ripetizioni | Si sale di variante prima che le serie diventino troppo lunghe | 16 |
| La crescita relativa è simile tra uomini e donne | Stesso programma per tutti, livello di partenza dai test | 17, 18 |
| Forza e massa si mantengono con poche sessioni ad alta intensità | Modalità Mantenimento | 19 |
| L’allenamento di forza riduce un po’ il grasso, ma non in modo localizzato | Indicazioni su deficit calorico, passi e misure | 2, 20, 21 |
| Oltre circa 1,6 g/kg di proteine al giorno non ci sono ulteriori guadagni | Indicazioni alimentari | 22 |
| Seguire l’esecuzione aiuta, almeno in un gruppo di persone anziane | Player con tempi, voce e indicazioni tecniche | 24 |

## Bibliografia

1. Currier BS, D’Souza AC, Singh MAF, et al. American College of Sports Medicine Position Stand. Resistance training prescription for muscle function, hypertrophy, and physical performance in healthy adults: an overview of reviews. Med Sci Sports Exerc. 2026. [ACSM](https://acsm.org/science-spotlight-acsm-releases-new-position-stand-on-resistance-training/)
2. World Health Organization. WHO guidelines on physical activity and sedentary behaviour. Ginevra: WHO; 2020. [WHO](https://www.who.int/publications/i/item/9789240015128)
3. Schoenfeld BJ, Grgic J, Ogborn D, Krieger JW. Strength and hypertrophy adaptations between low- vs. high-load resistance training: a systematic review and meta-analysis. J Strength Cond Res. 2017;31(12):3508-3523. [PubMed](https://pubmed.ncbi.nlm.nih.gov/28834797/)
4. Robinson ZP, Pelland JC, Remmert JF, et al. Exploring the dose-response relationship between estimated resistance training proximity to failure, strength gain, and muscle hypertrophy: a series of meta-regressions. Sports Med. 2024;54(9):2209-2231. [DOI](https://doi.org/10.1007/s40279-024-02069-2)
5. Schoenfeld BJ, Ogborn D, Krieger JW. Dose-response relationship between weekly resistance training volume and increases in muscle mass: a systematic review and meta-analysis. J Sports Sci. 2017;35(11):1073-1082.
6. Pelland JC, et al. The resistance training dose response: meta-regressions exploring the effects of weekly volume and frequency on muscle hypertrophy and strength gains. Sports Med. 2026;56(2):481-505. [Scheda](https://sponet.de/sponet/Record/4097139?lng=en)
7. Iversen VM, Norum M, Schoenfeld BJ, Fimland MS. No time to lift? Designing time-efficient training programs for strength and hypertrophy: a narrative review. Sports Med. 2021;51(10):2079-2095. [PMC](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8449772/)
8. Neto WK, et al. Gluteus maximus activation during common strength and hypertrophy exercises: a systematic review. J Sports Sci Med. 2020;19(1):195-203. [PubMed](https://pubmed.ncbi.nlm.nih.gov/32132843/)
9. Plotkin DL, Rodas MA, Vigotsky AD, et al. Hip thrust and back squat training elicit similar gluteus muscle hypertrophy and transfer similarly to the deadlift. Front Physiol. 2023;14:1279170. [Frontiers](https://www.frontiersin.org/journals/physiology/articles/10.3389/fphys.2023.1279170/full)
10. Kubo K, Ikebukuro T, Yata H. Effects of squat training with different depths on lower limb muscle volumes. Eur J Appl Physiol. 2019;119(9):1933-1942.
11. Wolf M, Androulakis-Korakakis P, et al. Partial vs full range of motion resistance training: a systematic review and meta-analysis. Int J Strength Cond. 2023;3(1). [IJSC](https://journal.iusca.org/index.php/Journal/article/view/182)
12. Lopes JSS, Machado AF, Micheletti JK, et al. Effects of training with elastic resistance versus conventional resistance on muscular strength: a systematic review and meta-analysis. SAGE Open Med. 2019;7:2050312119831116. [DOI](https://doi.org/10.1177/2050312119831116)
13. Singer A, Wolf M, Generoso L, et al. Give it a rest: a systematic review with Bayesian meta-analysis on the effect of inter-set rest interval duration on muscle hypertrophy. Front Sports Act Living. 2024;6:1429789. [Frontiers](https://www.frontiersin.org/articles/10.3389/fspor.2024.1429789/full)
14. Moesgaard L, Beck MM, Christiansen L, Aagaard P, Lundbye-Jensen J. Effects of periodization on strength and muscle hypertrophy in volume-equated resistance training programs: a systematic review and meta-analysis. Sports Med. 2022;52(7):1647-1666. [PubMed](https://pubmed.ncbi.nlm.nih.gov/35044672/)
15. Coleman M, Burke R, Augustin F, et al. Gaining more from doing less? The effects of a one-week deload period during supervised resistance training on muscular adaptations. PeerJ. 2024;12:e16777. [PeerJ](https://peerj.com/articles/16777)
16. Halperin I, Malleron T, Har-Nir I, et al. Accuracy in predicting repetitions to task failure in resistance exercise: a scoping review and exploratory meta-analysis. Sports Med. 2022;52(2):377-390. [PubMed](https://pubmed.ncbi.nlm.nih.gov/34542869/)
17. Roberts BM, Nuckols G, Krieger JW. Sex differences in resistance training: a systematic review and meta-analysis. J Strength Cond Res. 2020;34(5):1448-1460. [PubMed](https://pubmed.ncbi.nlm.nih.gov/32218059/)
18. Refalo MC, et al. Sex differences in absolute and relative changes in muscle size following resistance training in healthy adults: a systematic review with Bayesian meta-analysis. PeerJ. 2025. [PMC](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC11869894/)
19. Spiering BA, Mujika I, Sharp MA, Foulis SA. Maintaining physical performance: the minimal dose of exercise needed to preserve endurance and strength over time. J Strength Cond Res. 2021;35(5):1449-1458. [PubMed](https://pubmed.ncbi.nlm.nih.gov/33629972/)
20. Wewege MA, Desai I, Honey C, et al. The effect of resistance training in healthy adults on body fat percentage, fat mass and visceral fat: a systematic review and meta-analysis. Sports Med. 2022;52(2):287-300. [PubMed](https://pubmed.ncbi.nlm.nih.gov/34536199/)
21. Ramírez-Campillo R, Andrade DC, Campos-Jara C, et al. Regional fat changes induced by localized muscle endurance resistance training. J Strength Cond Res. 2013;27(8):2219-2224. [Scheda](https://repositorio.unab.cl/xmlui/handle/ria/53433)
22. Morton RW, Murphy KT, McKellar SR, et al. A systematic review, meta-analysis and meta-regression of the effect of protein supplementation on resistance training-induced gains in muscle mass and strength in healthy adults. Br J Sports Med. 2018;52(6):376-384. [BJSM](https://bjsm.bmj.com/content/52/6/376)
23. Meigh NJ, Keogh JWL, Schram B, Hing WA. Kettlebell training in clinical practice: a scoping review. BMC Sports Sci Med Rehabil. 2019;11. [PMC](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6719359/)
24. Muscle size and strength of the lower body in supervised and in combined supervised and unsupervised low-load resistance training. J Sports Sci Med. 2020;19(4):721-726. [PubMed](https://pubmed.ncbi.nlm.nih.gov/33239946/)

Prezzi dell’attrezzatura, rilevati a ottobre 2026 e soggetti a variazioni: [kettlebell da 12 kg](https://www.decathlon.it/vc/kettlebell-12-kg), [manubri da 4 kg](https://www.decathlon.it/vc/manubri-4-kg), [cavigliere](https://www.decathlon.it/tutti-gli-sport/fitness-palestra/cavigliere-polsiere), [sbarre per trazioni](https://www.decathlon.it/vc/pull-up-bar), [fitball](https://www.decathlon.it/C-1265557-fitball), [cinghie in sospensione](https://www.decathlon.co.uk/sports/fitness-gym/suspension-strap-training) (prezzi in sterline).

Modello 3D: corpo da [MakeHuman](https://github.com/makehumancommunity/makehuman), asset con licenza CC0.
