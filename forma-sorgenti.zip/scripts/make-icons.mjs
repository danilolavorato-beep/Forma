// Genera icone e splash a partire dalla figura dello squat bulgaro (richiede: npm i -D sharp).
// Uso: node scripts/make-icons.mjs
import fs from 'node:fs';
import path from 'node:path';
import sharp from 'sharp';
import { ANIMS } from '../www/js/data/anims.js';
import { solve, poseAt } from '../www/js/figure.js';

const BG = '#edf0eb';
const INK = '#1d2328';
const FAR = '#8d9993';
const RED = '#d3412e';

function figureSVG(size, { pad = 0.2, bg = null, round = 0, circle = false } = {}) {
  const anim = ANIMS.bss;
  const J = solve(poseAt(anim, 1.71)); // posizione bassa
  const pts = ['head', 'hip', 'neck', 'kneeR', 'kneeL', 'ankleR', 'ankleL', 'toeR', 'toeL', 'heelR', 'heelL', 'wristR', 'wristL', 'elbowR', 'elbowL'].map((k) => J[k]);
  let x0 = Math.min(...pts.map((p) => p[0])) - 12, x1 = Math.max(...pts.map((p) => p[0])) + 12;
  let y0 = Math.min(...pts.map((p) => p[1])) - 14, y1 = 2;
  const w = x1 - x0, hgt = y1 - y0;
  const inner = size * (1 - pad * 2);
  const k = inner / Math.max(w, hgt);
  const ox = (size - w * k) / 2 - x0 * k;
  const oy = (size - hgt * k) / 2 - y0 * k;
  const T = (p) => `${(p[0] * k + ox).toFixed(1)} ${(p[1] * k + oy).toFixed(1)}`;
  const seg = (a, b, col, wid) => `<line x1="${(J[a][0] * k + ox).toFixed(1)}" y1="${(J[a][1] * k + oy).toFixed(1)}" x2="${(J[b][0] * k + ox).toFixed(1)}" y2="${(J[b][1] * k + oy).toFixed(1)}" stroke="${col}" stroke-width="${(wid * k).toFixed(1)}" stroke-linecap="round"/>`;
  let s = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">`;
  if (bg) {
    if (circle) s += `<circle cx="${size / 2}" cy="${size / 2}" r="${size / 2}" fill="${bg}"/>`;
    else s += `<rect width="${size}" height="${size}" rx="${round * size}" fill="${bg}"/>`;
  }
  // panca
  const bench = anim.props[0];
  s += `<rect x="${(bench.x * k + ox).toFixed(1)}" y="${(bench.y * k + oy).toFixed(1)}" width="${(bench.w * k).toFixed(1)}" height="${(-bench.y * k).toFixed(1)}" rx="${(3 * k).toFixed(1)}" fill="#c6cfc5"/>`;
  s += `<line x1="${(x0 * k + ox).toFixed(1)}" y1="${oy.toFixed(1)}" x2="${(x1 * k + ox).toFixed(1)}" y2="${oy.toFixed(1)}" stroke="#b9c2b8" stroke-width="${(3 * k).toFixed(1)}" stroke-linecap="round"/>`;
  s += seg('hipL', 'kneeL', FAR, 13) + seg('kneeL', 'ankleL', FAR, 11.5) + seg('heelL', 'toeL', FAR, 7);
  s += `<circle cx="${(J.glute[0] * k + ox).toFixed(1)}" cy="${(J.glute[1] * k + oy).toFixed(1)}" r="${(10.5 * k).toFixed(1)}" fill="${RED}"/>`;
  s += seg('hip', 'neck', INK, 15) + seg('neck', 'head', INK, 9);
  s += seg('hipR', 'kneeR', RED, 13) + seg('kneeR', 'ankleR', INK, 11.5) + seg('heelR', 'toeR', INK, 7);
  s += seg('shR', 'elbowR', INK, 10) + seg('elbowR', 'wristR', INK, 9);
  s += `<circle cx="${(J.head[0] * k + ox).toFixed(1)}" cy="${(J.head[1] * k + oy).toFixed(1)}" r="${(12 * k).toFixed(1)}" fill="${INK}"/>`;
  s += '</svg>';
  void T;
  return s;
}

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const out = (rel) => { const p = path.join(root, rel); fs.mkdirSync(path.dirname(p), { recursive: true }); return p; };
const png = (svg, file, size) => sharp(Buffer.from(svg)).resize(size, size).png().toFile(out(file));

// web
await png(figureSVG(512, { bg: BG, round: 0.22, pad: 0.16 }), 'www/icons/icon-512.png', 512);
await png(figureSVG(512, { bg: BG, round: 0.22, pad: 0.16 }), 'www/icons/icon-192.png', 192);
await png(figureSVG(512, { bg: BG, pad: 0.24 }), 'www/icons/icon-maskable-512.png', 512);

// android: icone tradizionali, rotonde e adattive
const dens = { mdpi: 1, hdpi: 1.5, xhdpi: 2, xxhdpi: 3, xxxhdpi: 4 };
for (const [d, f] of Object.entries(dens)) {
  const s48 = Math.round(48 * f);
  const s108 = Math.round(108 * f);
  await png(figureSVG(512, { bg: BG, round: 0.2, pad: 0.16 }), `android-res/mipmap-${d}/ic_launcher.png`, s48);
  await png(figureSVG(512, { bg: BG, circle: true, pad: 0.2 }), `android-res/mipmap-${d}/ic_launcher_round.png`, s48);
  await png(figureSVG(512, { pad: 0.27 }), `android-res/mipmap-${d}/ic_launcher_foreground.png`, s108);
}
fs.writeFileSync(out('android-res/values/ic_launcher_background.xml'), `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">${BG.toUpperCase()}</color>\n</resources>\n`);

// splash per Android < 12 (dal 12 il sistema usa l'icona su sfondo uniforme)
const splashSizes = {
  'drawable': [480, 320], 'drawable-land-mdpi': [480, 320], 'drawable-land-hdpi': [800, 480], 'drawable-land-xhdpi': [1280, 720],
  'drawable-land-xxhdpi': [1600, 960], 'drawable-land-xxxhdpi': [1920, 1280], 'drawable-port-mdpi': [320, 480],
  'drawable-port-hdpi': [480, 800], 'drawable-port-xhdpi': [720, 1280], 'drawable-port-xxhdpi': [960, 1600], 'drawable-port-xxxhdpi': [1280, 1920],
};
for (const [dir, [w, hh]] of Object.entries(splashSizes)) {
  const s = Math.round(Math.min(w, hh) * 0.42);
  const fig = await sharp(Buffer.from(figureSVG(512, { pad: 0.1 }))).resize(s, s).png().toBuffer();
  await sharp({ create: { width: w, height: hh, channels: 3, background: BG } })
    .composite([{ input: fig, left: Math.round((w - s) / 2), top: Math.round((hh - s) / 2) }])
    .png().toFile(out(`android-res/${dir}/splash.png`));
}
console.log('icone e splash generati');
