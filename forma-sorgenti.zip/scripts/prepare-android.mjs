// Personalizza il progetto Android generato da `npx cap add android`:
// icone e splash, colore dello splash di Android 12+, numero di versione e firma.
// Viene eseguito dalla GitHub Action dopo `cap add android` e prima di `cap sync android`.
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const android = path.join(root, 'android');
const res = path.join(android, 'app/src/main/res');
const BG = '#EDF0EB';

if (!fs.existsSync(android)) {
  console.error('Cartella android/ assente: esegui prima `npx cap add android`.');
  process.exit(1);
}

// 1. icone e immagini di avvio
function copyDir(src, dst) {
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, entry.name);
    const d = path.join(dst, entry.name);
    if (entry.isDirectory()) { fs.mkdirSync(d, { recursive: true }); copyDir(s, d); }
    else fs.copyFileSync(s, d);
  }
}
copyDir(path.join(root, 'android-res'), res);
console.log('✓ icone e splash copiati');

// 2. sfondo della schermata di avvio (Android 12+)
const stylesPath = path.join(res, 'values/styles.xml');
let styles = fs.readFileSync(stylesPath, 'utf8');
if (!styles.includes('windowSplashScreenBackground')) {
  styles = styles.replace(
    /(<style name="AppTheme\.NoActionBarLaunch" parent="Theme\.SplashScreen">)/,
    `$1\n        <item name="windowSplashScreenBackground">${BG}</item>\n        <item name="windowSplashScreenAnimatedIcon">@mipmap/ic_launcher_foreground</item>`,
  );
  fs.writeFileSync(stylesPath, styles);
  console.log('✓ colore dello splash impostato');
}

// 3. versione e firma
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const build = parseInt(process.env.BUILD_NUMBER || process.env.GITHUB_RUN_NUMBER || '1', 10);
const gradlePath = path.join(android, 'app/build.gradle');
let gradle = fs.readFileSync(gradlePath, 'utf8');
gradle = gradle.replace(/versionCode\s+\d+/, `versionCode ${build}`);
gradle = gradle.replace(/versionName\s+"[^"]*"/, `versionName "${pkg.version}.${build}"`);
if (!gradle.includes('signingConfigs.forma')) {
  gradle += `

// --- Forma: firma stabile, così ogni nuova build si installa sopra la precedente senza perdere i dati ---
android {
    signingConfigs {
        forma {
            storeFile file(System.getenv('FORMA_KEYSTORE') ?: '../../keystore/forma-release.p12')
            storePassword System.getenv('FORMA_KEYSTORE_PASSWORD') ?: 'forma-android'
            keyAlias System.getenv('FORMA_KEY_ALIAS') ?: 'forma'
            keyPassword System.getenv('FORMA_KEYSTORE_PASSWORD') ?: 'forma-android'
            storeType 'pkcs12'
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.forma
        }
        debug {
            signingConfig signingConfigs.forma
        }
    }
    lint {
        checkReleaseBuilds false
        abortOnError false
    }
}
`;
}
fs.writeFileSync(gradlePath, gradle);
console.log(`✓ versione ${pkg.version}.${build} (versionCode ${build}) e firma configurate`);
