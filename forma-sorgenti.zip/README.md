# Forma

App Android per allenarsi a casa in 30–45 minuti, con priorità a gambe e glutei. Parte da un test iniziale, procede per fasi e fa salire di livello gli esercizi da sola man mano che migliori. Funziona senza attrezzi; se selezioni quelli che hai (elastici, kettlebell, manubri, cavigliere, sbarra, cinghie in sospensione, fitball, step) il piano si rigenera con esercizi dedicati e progressione sul peso. Gli esercizi sono dimostrati da un’atleta in 3D con i muscoli che lavorano evidenziati. Nessun account e nessun dato in rete: tutto resta sul telefono.

Il programma, con le fonti scientifiche, è descritto in [PROGRAMMA.md](PROGRAMMA.md).

## Ottenere l’APK con GitHub

Una volta sola, circa 15 minuti. L’APK viene compilato da GitHub Actions a ogni modifica del ramo `main` e pubblicato tra le Release del repository, da dove lo scarichi direttamente dal telefono.

### 1. Crea il repository

1. Su github.com premi **New repository**.
2. Dai un nome, per esempio `forma`, e scegli **Private** (il motivo è in [La chiave di firma](#la-chiave-di-firma)).
3. Non aggiungere README, .gitignore o licenza e premi **Create repository**.

### 2. Carica i file

**Metodo semplice, due soli passaggi** (consigliato). Servono solo `forma-sorgenti.zip` e `build-apk.yml`, senza scompattare nulla:

1. Nel repository vuoto clicca **uploading an existing file** e trascina `forma-sorgenti.zip` (un solo file, non va scompattato). Premi **Commit changes**.
2. Premi **Add file → Create new file**. Nel campo del nome scrivi `.github/workflows/build-apk.yml` (digitando le barre GitHub crea da solo le cartelle), incolla il contenuto di `build-apk.yml` e premi **Commit changes**.

Per aggiornare l'app in futuro basta ricaricare `forma-sorgenti.zip` con lo stesso nome (**Add file → Upload files**, poi **Commit changes**): GitHub lo sostituisce e parte una nuova build.

**Metodo con le cartelle** (alternativa):

Scompatta lo zip sul computer: ottieni la cartella `forma`.

**Dal browser**, senza installare nulla:

1. Nella pagina del nuovo repository clicca il link **uploading an existing file**.
2. Apri la cartella `forma`, seleziona **tutto il suo contenuto** (non la cartella stessa) e trascinalo nella pagina. Devono esserci anche `.github`, `.gitignore` e `.gitattributes`: sul Mac i nomi che iniziano con il punto sono nascosti, mostrali nel Finder con ⌘ Maiusc . (punto).
3. Premi **Commit changes**.

I file sono circa 80, sotto il limite di 100 per caricamento.

**Con git**, se lo usi già:

```bash
cd forma
git init -b main
git add .
git commit -m "Prima versione di Forma"
git remote add origin https://github.com/TUO-UTENTE/forma.git
git push -u origin main
```

### 3. Aspetta la compilazione

Il caricamento avvia da solo il workflow **Build APK**, visibile nella scheda **Actions**. Dura 5–10 minuti: installa le dipendenze, esegue i test del programma, crea il progetto Android e compila l’APK firmato.

Se nella scheda Actions non compare nessuna esecuzione di Build APK, nel repository manca `.github/workflows/build-apk.yml`: al punto 2 la cartella nascosta non è stata caricata. Aggiungila con **Add file → Create new file**, scrivendo come nome `.github/workflows/build-apk.yml` e incollando il contenuto del file. Fai lo stesso con `.github/workflows/pages.yml` se ti interessa la versione web.

### 4. Installa sul telefono

1. Dal telefono apri github.com, accedi e vai al repository → **Releases**, oppure apri direttamente `https://github.com/TUO-UTENTE/forma/releases/latest`.
2. Tocca `Forma-N.apk` per scaricarlo, poi aprilo dalla notifica o dalla cartella Download.
3. La prima volta Android chiede di consentire l’installazione di app dal browser: consenti e torna indietro. Se Play Protect segnala un’app sconosciuta, scegli **Altri dettagli → Installa comunque**.

Serve Android 7 o successivo.

### Aggiornamenti

Ogni modifica caricata su `main` produce una nuova build e una nuova release; le modifiche ai soli file `.md` non avviano la build. L’APK nuovo si installa sopra il precedente e conserva i dati, perché è firmato con la stessa chiave e ha un numero di versione più alto. Puoi anche avviare una build a mano: **Actions → Build APK → Run workflow**.

L’APK resta disponibile per 30 giorni anche tra gli artifact della singola esecuzione, utile se la creazione della release non riesce.

## La chiave di firma

Android installa un aggiornamento sopra la versione esistente solo se entrambe sono firmate con la stessa chiave. Per questo il repository contiene una chiave pronta, `keystore/forma-release.p12` (password `forma-android`): ogni build si installa sopra la precedente senza configurare nulla.

Chi ha accesso al repository può usare la chiave: per questo il repository va tenuto privato. Se lo vuoi pubblico, per esempio per la versione web su GitHub Pages con l’account gratuito, usa una chiave tua:

1. Crea la chiave. Serve OpenSSL, già presente su Mac e Linux e incluso in Git per Windows:

   ```bash
   openssl req -x509 -newkey rsa:2048 -nodes -keyout chiave.pem -out cert.pem -days 12000 -subj "/CN=Forma"
   openssl pkcs12 -export -inkey chiave.pem -in cert.pem -name forma -out forma.p12 -passout pass:SCEGLI-UNA-PASSWORD
   base64 < forma.p12 | tr -d '\n' > forma.p12.txt
   ```

2. Nel repository apri **Settings → Secrets and variables → Actions** e crea tre secret con **New repository secret**:
   - `FORMA_KEYSTORE_BASE64`: il contenuto di `forma.p12.txt`
   - `FORMA_KEYSTORE_PASSWORD`: la password scelta
   - `FORMA_KEY_ALIAS`: `forma`
3. Elimina la cartella `keystore/` dal repository e conserva `forma.p12` e la password in un posto sicuro, fuori dal repository. Cancella `chiave.pem`, `cert.pem` e `forma.p12.txt`.

Un APK firmato con una chiave diversa non si installa sopra quello vecchio: va prima disinstallata l’app, e con lei i dati. Esporta un backup prima di cambiare chiave, o meglio decidi all’inizio.

## Attrezzatura e modello 3D

- **Attrezzatura** (dal Programma o dalle Impostazioni): attiva quello che hai e, per kettlebell, manubri e cavigliere, i pesi disponibili; per lo zaino il carico massimo. Il riquadro *Il tuo piano* mostra subito cosa cambia rispetto al corpo libero.
- **Modello 3D**: la figura è disegnata con WebGL. Se il telefono non lo supporta, o se spegni *Modello 3D realistico* nelle Impostazioni, l’app usa le figure essenziali in 2D.

Il modello (`www/model/atleta.glb`, circa 1,1 MB) è già pronto. Per rigenerarlo, per esempio cambiando colori o proporzioni in `tools/model/`:

```bash
git clone --depth 1 https://github.com/makehumancommunity/makehuman.git
pip install numpy pillow opencv-python-headless
python3 tools/model/build_model.py makehuman/makehuman/data www/model/atleta.glb
```

La mesh del corpo viene da MakeHuman, i cui asset sono rilasciati con licenza CC0; abbigliamento, capelli e texture sono generati dallo script. `tools/model/sheet3d.html` mostra tutte le animazioni in 3D (servi la cartella del progetto con un server locale).

## Backup dei dati

Livelli, storico, test, misure e impostazioni sono salvati solo sul telefono. In **Impostazioni → Esporta backup** ottieni un file da salvare dove vuoi (Drive, email, cartella del telefono); **Importa backup** lo ripristina e sostituisce i dati presenti. Fallo prima di disinstallare l’app o di cambiare telefono.

## Versione web, facoltativa

Lo stesso codice funziona nel browser, utile per provarla al computer o su iPhone.

- **In locale**: `npx serve www` oppure `python3 -m http.server 8080 -d www`, poi apri l’indirizzo indicato. Aprire `index.html` con un doppio clic non funziona: i moduli JavaScript richiedono un server.
- **Su GitHub Pages**: in **Settings → Pages** scegli come Source **GitHub Actions**, poi **Actions → Pubblica la web app → Run workflow**. Con l’account gratuito GitHub Pages funziona solo con repository pubblici: in quel caso usa una chiave tua (vedi sopra).

I dati della versione web e dell’APK sono separati; per spostarli usa il backup.

## Struttura del progetto

```
www/                   l'app: HTML, CSS e JavaScript senza framework
  js/engine.js         motore del programma: sessioni, durata, progressione (senza interfaccia, testato)
  js/data/program.js   fasi, sessioni, scale di esercizi, test, cicli
  js/data/exercises.js esercizi: fasce di ripetizioni, attrezzi, indicazioni tecniche
  js/data/anims.js     pose delle animazioni
  js/figure.js         pose degli esercizi e figure essenziali in SVG
  js/pose3d.js         dalle pose 2D alla posa 3D del modello (cinematica inversa)
  js/body3d.js         caricamento del modello e disegno WebGL
  js/figure3d.js       figure 3D animate, oggetti di scena e inquadratura
  js/views/equipment.js  schermata Attrezzatura
  model/atleta.glb     modello 3D dell'atleta
  js/data/guide.js     testi della Guida e bibliografia
  js/views/            schermate: Oggi, Programma, Esercizi, Progressi, Guida, Impostazioni, player
tests/                 test del motore (npm test)
scripts/               generazione delle icone e preparazione del progetto Android
tools/model/           costruzione del modello 3D da MakeHuman e fogli di controllo delle animazioni
android-res/           icone e schermata di avvio già generate
keystore/              chiave di firma (vedi sopra)
.github/workflows/     compilazione dell'APK e pubblicazione della versione web
```

L’APK è costruito con Capacitor 8: l’app gira in una WebView Android, con plugin per vibrazione, schermo sempre acceso durante l’allenamento, voce in italiano, tasto Indietro e condivisione del backup.

## Modificare l’app

- Serve Node.js 22 o successivo: `npm install`, poi `npm test`.
- Fasi e sessioni sono in `www/js/data/program.js`. Dopo ogni modifica `npm test` controlla, tra l’altro, che tutte le sessioni restino entro 45 minuti (25 nella versione rapida).
- Icone e schermata di avvio: `npm install --no-save sharp`, poi `node scripts/make-icons.mjs`.
- Per compilare l’APK sul computer servono anche JDK 21 e l’Android SDK (per esempio con Android Studio): `npx cap add android`, `node scripts/prepare-android.mjs`, `npx cap sync android`, poi `./gradlew assembleRelease` nella cartella `android`.

## Per il futuro: verifica degli sviluppatori Android

Google sta introducendo la verifica degli sviluppatori anche per le app installate fuori dal Play Store: è obbligatoria dal 30 settembre 2026 in Brasile, Indonesia, Singapore e Thailandia, mentre negli altri Paesi l’estensione è prevista dal 2027. Oggi in Italia l’APK si installa come descritto sopra. Quando la regola arriverà, le strade saranno un account sviluppatore gratuito per la distribuzione limitata (fino a 20 dispositivi) oppure la procedura avanzata di Android per installare app non verificate. La versione web non è interessata.

## Avvertenze

Forma è uno strumento di allenamento e non sostituisce una valutazione medica. Le domande di sicurezza al primo avvio si ispirano al questionario PAR‑Q+: se rispondi sì ad almeno una, parlane con il medico prima di iniziare.

Caratteri: Big Shoulders Display e Atkinson Hyperlegible Next, con licenza SIL Open Font License (testi delle licenze in `www/fonts`).
