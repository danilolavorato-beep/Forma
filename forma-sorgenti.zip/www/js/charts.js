// Forma — grafici SVG minimi: una serie per grafico, linee sottili, etichetta sull'ultimo valore,
// valore di ogni punto al tocco (e in <title> per lettori di schermo e mouse).
const NS = 'http://www.w3.org/2000/svg';

function el(tag, attrs, parent) {
  const e = document.createElementNS(NS, tag);
  for (const k in attrs) e.setAttribute(k, attrs[k]);
  if (parent) parent.appendChild(e);
  return e;
}

function niceRange(min, max) {
  if (min === max) { min -= 1; max += 1; }
  const span = max - min;
  const step = Math.pow(10, Math.floor(Math.log10(span)));
  const err = span / step;
  const s = err > 5 ? step * 2 : err > 2 ? step : step / 2;
  return [Math.floor(min / s) * s, Math.ceil(max / s) * s, s];
}

const fmt = (v) => (Math.round(v * 10) / 10).toLocaleString('it-IT');

// points: [{ x: timestamp, y: number, label: string }]
export function lineChart(points, { width = 320, height = 120, unit = '', caption = null, spark = false } = {}) {
  const svg = el('svg', { viewBox: `0 0 ${width} ${height}`, class: 'chart', role: 'img' });
  if (!points.length) return svg;
  const padL = spark ? 4 : 30, padR = spark ? 8 : 40, padT = spark ? 6 : 10, padB = spark ? 6 : 20;
  const ys = points.map((p) => p.y);
  const [y0, y1, step] = niceRange(Math.min(...ys), Math.max(...ys));
  const xs = points.map((p) => p.x);
  const x0 = Math.min(...xs), x1 = Math.max(...xs);
  const X = (x) => (x1 === x0 ? padL + (width - padL - padR) / 2 : padL + ((x - x0) / (x1 - x0)) * (width - padL - padR));
  const Y = (y) => padT + (1 - (y - y0) / (y1 - y0)) * (height - padT - padB);
  svg.setAttribute('aria-label', `Andamento: da ${fmt(points[0].y)} a ${fmt(points[points.length - 1].y)} ${unit}`);
  if (!spark) {
    for (let v = y0; v <= y1 + 1e-9; v += step) {
      el('line', { x1: padL, x2: width - padR, y1: Y(v), y2: Y(v), class: 'grid' }, svg);
      const t = el('text', { x: padL - 6, y: Y(v) + 4, 'text-anchor': 'end' }, svg);
      t.textContent = fmt(v);
    }
  }
  const d = points.map((p, k) => `${k ? 'L' : 'M'}${X(p.x).toFixed(1)} ${Y(p.y).toFixed(1)}`).join(' ');
  if (points.length > 1) {
    el('path', { d: `${d} L${X(points[points.length - 1].x).toFixed(1)} ${height - padB} L${X(points[0].x).toFixed(1)} ${height - padB} Z`, class: 'area' }, svg);
    el('path', { d, class: 'line' }, svg);
  }
  points.forEach((p, k) => {
    const isLast = k === points.length - 1;
    if (isLast || !spark) el('circle', { cx: X(p.x), cy: Y(p.y), r: spark ? 3.5 : 4.5, class: 'pt' }, svg);
    if (!spark) {
      const hit = el('circle', { cx: X(p.x), cy: Y(p.y), r: 14, class: 'hit', tabindex: '0' }, svg);
      const ti = el('title', {}, hit);
      ti.textContent = `${p.label}: ${fmt(p.y)} ${unit}`;
      const show = () => { if (caption) caption.textContent = `${p.label}: ${fmt(p.y)} ${unit}`; };
      hit.addEventListener('click', show);
      hit.addEventListener('mouseenter', show);
      hit.addEventListener('focus', show);
    }
  });
  const last = points[points.length - 1];
  if (!spark) {
    const t = el('text', { x: X(last.x) + 8, y: Y(last.y) + 4, class: 'val' }, svg);
    t.textContent = fmt(last.y);
  }
  return svg;
}

// bars: [{ label, value }], target: linea di riferimento
export function barChart(bars, { width = 320, height = 130, target = null, caption = null, unit = '' } = {}) {
  const svg = el('svg', { viewBox: `0 0 ${width} ${height}`, class: 'chart', role: 'img' });
  const padL = 6, padR = 6, padT = 16, padB = 20;
  const max = Math.max(target || 0, ...bars.map((b) => b.value), 1);
  const slot = (width - padL - padR) / bars.length;
  const bw = Math.min(24, slot * 0.6);
  const base = height - padB;
  const Y = (v) => padT + (1 - v / max) * (base - padT);
  svg.setAttribute('aria-label', `Sessioni per settimana, ultime ${bars.length} settimane`);
  el('line', { x1: padL, x2: width - padR, y1: base, y2: base, class: 'grid' }, svg);
  if (target) {
    el('line', { x1: padL, x2: width - padR, y1: Y(target), y2: Y(target), class: 'ref', 'stroke-dasharray': '0' }, svg);
  }
  bars.forEach((b, k) => {
    const cx = padL + slot * k + slot / 2;
    const v = b.value;
    if (v > 0) {
      const top = Y(v);
      const r = Math.min(4, (base - top) / 2);
      const x = cx - bw / 2;
      el('path', { d: `M${x} ${base} L${x} ${top + r} Q${x} ${top} ${x + r} ${top} L${x + bw - r} ${top} Q${x + bw} ${top} ${x + bw} ${top + r} L${x + bw} ${base} Z`, class: 'bar' }, svg);
      const t = el('text', { x: cx, y: top - 4, 'text-anchor': 'middle', class: 'val' }, svg);
      t.textContent = String(v);
    } else {
      el('rect', { x: cx - bw / 2, y: base - 3, width: bw, height: 3, rx: 1.5, class: 'bar empty' }, svg);
    }
    const lab = el('text', { x: cx, y: height - 5, 'text-anchor': 'middle' }, svg);
    lab.textContent = b.label;
    const hit = el('rect', { x: cx - slot / 2, y: 0, width: slot, height, class: 'hit', tabindex: '0' }, svg);
    const ti = el('title', {}, hit);
    ti.textContent = `${b.full || b.label}: ${v} ${unit}`;
    const show = () => { if (caption) caption.textContent = `${b.full || b.label}: ${v} ${unit}`; };
    hit.addEventListener('click', show);
    hit.addEventListener('mouseenter', show);
    hit.addEventListener('focus', show);
  });
  return svg;
}
