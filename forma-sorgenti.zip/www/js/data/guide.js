// Forma — contenuti della Guida: come funziona il programma e su quali prove si basa.

export const REFS = {
  acsm26: 'Currier BS, D’Souza AC, Singh MAF, et al. American College of Sports Medicine Position Stand. Resistance training prescription for muscle function, hypertrophy, and physical performance in healthy adults: an overview of reviews. Med Sci Sports Exerc. 2026.',
  who20: 'World Health Organization. WHO guidelines on physical activity and sedentary behaviour. Ginevra: WHO; 2020.',
  schoenfeld17load: 'Schoenfeld BJ, Grgic J, Ogborn D, Krieger JW. Strength and hypertrophy adaptations between low- vs. high-load resistance training: a systematic review and meta-analysis. J Strength Cond Res. 2017;31(12):3508-3523.',
  robinson24: 'Robinson ZP, Pelland JC, Remmert JF, et al. Exploring the dose-response relationship between estimated resistance training proximity to failure, strength gain, and muscle hypertrophy: a series of meta-regressions. Sports Med. 2024;54(9):2209-2231.',
  schoenfeld17vol: 'Schoenfeld BJ, Ogborn D, Krieger JW. Dose-response relationship between weekly resistance training volume and increases in muscle mass: a systematic review and meta-analysis. J Sports Sci. 2017;35(11):1073-1082.',
  pelland26: 'Pelland JC, et al. The resistance training dose response: meta-regressions exploring the effects of weekly volume and frequency on muscle hypertrophy and strength gains. Sports Med. 2026;56(2):481-505.',
  iversen21: 'Iversen VM, Norum M, Schoenfeld BJ, Fimland MS. No time to lift? Designing time-efficient training programs for strength and hypertrophy: a narrative review. Sports Med. 2021;51(10):2079-2095.',
  neto20: 'Neto WK, et al. Gluteus maximus activation during common strength and hypertrophy exercises: a systematic review. J Sports Sci Med. 2020;19(1):195-203.',
  plotkin23: 'Plotkin DL, Rodas MA, Vigotsky AD, et al. Hip thrust and back squat training elicit similar gluteus muscle hypertrophy and transfer similarly to the deadlift. Front Physiol. 2023;14:1279170.',
  kubo19: 'Kubo K, Ikebukuro T, Yata H. Effects of squat training with different depths on lower limb muscle volumes. Eur J Appl Physiol. 2019;119(9):1933-1942.',
  wolf23: 'Wolf M, Androulakis-Korakakis P, et al. Partial vs full range of motion resistance training: a systematic review and meta-analysis. Int J Strength Cond. 2023;3(1).',
  lopes19: 'Lopes JSS, Machado AF, Micheletti JK, et al. Effects of training with elastic resistance versus conventional resistance on muscular strength: a systematic review and meta-analysis. SAGE Open Med. 2019;7:2050312119831116.',
  singer24: 'Singer A, Wolf M, Generoso L, et al. Give it a rest: a systematic review with Bayesian meta-analysis on the effect of inter-set rest interval duration on muscle hypertrophy. Front Sports Act Living. 2024;6:1429789.',
  moesgaard22: 'Moesgaard L, Beck MM, Christiansen L, Aagaard P, Lundbye-Jensen J. Effects of periodization on strength and muscle hypertrophy in volume-equated resistance training programs: a systematic review and meta-analysis. Sports Med. 2022;52(7):1647-1666.',
  coleman24: 'Coleman M, Burke R, Augustin F, et al. Gaining more from doing less? The effects of a one-week deload period during supervised resistance training on muscular adaptations. PeerJ. 2024;12:e16777.',
  halperin22: 'Halperin I, Malleron T, Har-Nir I, et al. Accuracy in predicting repetitions to task failure in resistance exercise: a scoping review and exploratory meta-analysis. Sports Med. 2022;52(2):377-390.',
  roberts20: 'Roberts BM, Nuckols G, Krieger JW. Sex differences in resistance training: a systematic review and meta-analysis. J Strength Cond Res. 2020;34(5):1448-1460.',
  refalo25: 'Refalo MC, et al. Sex differences in absolute and relative changes in muscle size following resistance training in healthy adults: a systematic review with Bayesian meta-analysis. PeerJ. 2025.',
  spiering21: 'Spiering BA, Mujika I, Sharp MA, Foulis SA. Maintaining physical performance: the minimal dose of exercise needed to preserve endurance and strength over time. J Strength Cond Res. 2021;35(5):1449-1458.',
  wewege22: 'Wewege MA, Desai I, Honey C, et al. The effect of resistance training in healthy adults on body fat percentage, fat mass and visceral fat: a systematic review and meta-analysis. Sports Med. 2022;52(2):287-300.',
  ramirez13: 'Ramírez-Campillo R, Andrade DC, Campos-Jara C, et al. Regional fat changes induced by localized muscle endurance resistance training. J Strength Cond Res. 2013;27(8):2219-2224.',
  morton18: 'Morton RW, Murphy KT, McKellar SR, et al. A systematic review, meta-analysis and meta-regression of the effect of protein supplementation on resistance training-induced gains in muscle mass and strength in healthy adults. Br J Sports Med. 2018;52(6):376-384.',
  meigh19: 'Meigh NJ, Keogh JWL, Schram B, Hing WA. Kettlebell training in clinical practice: a scoping review. BMC Sports Sci Med Rehabil. 2019;11.',
  jssm20: 'Muscle size and strength of the lower body in supervised and in combined supervised and unsupervised low-load resistance training. J Sports Sci Med. 2020;19(4):721-726.',
};

// Collegamenti alle pubblicazioni (PubMed, PMC o editore). Dove manca, la citazione basta a trovarla.
export const CREDITS = 'Il modello 3D è costruito sulla mesh umana di MakeHuman (makehumancommunity.org), rilasciata con licenza CC0; abbigliamento, capelli e animazioni sono generati per Forma.';

export const REF_LINKS = {
  acsm26: 'https://acsm.org/science-spotlight-acsm-releases-new-position-stand-on-resistance-training/',
  who20: 'https://www.who.int/publications/i/item/9789240015128',
  schoenfeld17load: 'https://pubmed.ncbi.nlm.nih.gov/28834797/',
  robinson24: 'https://doi.org/10.1007/s40279-024-02069-2',
  pelland26: 'https://sponet.de/sponet/Record/4097139?lng=en',
  iversen21: 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8449772/',
  neto20: 'https://pubmed.ncbi.nlm.nih.gov/32132843/',
  plotkin23: 'https://www.frontiersin.org/journals/physiology/articles/10.3389/fphys.2023.1279170/full',
  wolf23: 'https://journal.iusca.org/index.php/Journal/article/view/182',
  lopes19: 'https://doi.org/10.1177/2050312119831116',
  singer24: 'https://www.frontiersin.org/articles/10.3389/fspor.2024.1429789/full',
  moesgaard22: 'https://pubmed.ncbi.nlm.nih.gov/35044672/',
  coleman24: 'https://peerj.com/articles/16777',
  halperin22: 'https://pubmed.ncbi.nlm.nih.gov/34542869/',
  roberts20: 'https://pubmed.ncbi.nlm.nih.gov/32218059/',
  refalo25: 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC11869894/',
  spiering21: 'https://pubmed.ncbi.nlm.nih.gov/33629972/',
  wewege22: 'https://pubmed.ncbi.nlm.nih.gov/34536199/',
  ramirez13: 'https://repositorio.unab.cl/xmlui/handle/ria/53433',
  morton18: 'https://bjsm.bmj.com/content/52/6/376',
  meigh19: 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6719359/',
  jssm20: 'https://pubmed.ncbi.nlm.nih.gov/33239946/',
};

export const HOW = [
  'Il programma parte da quattro test (squat, ponte su una gamba, piegamenti, plank) che scelgono il livello di partenza di ogni esercizio. Poi procede in fasi: Fondamenta (settimane 1–4), Costruzione (5–10), Intensificazione (11–16) e, dalla settimana 17, cicli di 6 settimane che alternano tre accenti: carico, volume per i glutei, densità.',
  'Ogni sessione è fatta di coppie o terne di esercizi che lavorano zone diverse, alternate senza pause lunghe: mentre le gambe recuperano lavorano braccia o addome. È il modo più efficace per stare in 30–45 minuti senza perdere qualità.',
  'Ogni esercizio ha una fascia di ripetizioni, per esempio 8–15. Quando chiudi tutte le serie al massimo della fascia, alla sessione successiva passi alla variante più difficile della stessa scala. Se per due sessioni resti sotto il minimo, o se segnali dolore due volte di fila, torni alla variante precedente. I colori dei livelli seguono quelli degli elastici: giallo, arancio, rosso, verde, blu, nero, argento, oro.',
  'L’attrezzatura che selezioni cambia il piano: le scale di esercizi includono le varianti con kettlebell, manubri, elastici, cavigliere, sbarra, cinghie e fitball, e alcune sessioni aggiungono esercizi dedicati (per esempio gli slanci per i glutei con le cavigliere). Con i pesi la progressione passa prima al peso successivo che possiedi, poi alla variante più difficile.',
  'Dopo l’ultima serie di ogni esercizio l’app chiede quante ripetizioni ti restavano (ripetizioni in riserva). Serve a capire se la serie è stata abbastanza impegnativa: l’obiettivo della volta dopo cresce di una ripetizione solo se lo sforzo era nel bersaglio della fase.',
  'Ogni sei settimane circa c’è una settimana leggera: una serie in meno per esercizio e, alla prima sessione, i test per misurare i progressi. Se stai fermo più di dieci giorni, la sessione di rientro viene alleggerita in automatico.',
];

export const EVIDENCE = [
  {
    t: 'Conta soprattutto allenarsi con costanza',
    p: 'La posizione 2026 dell’American College of Sports Medicine, basata su 137 revisioni sistematiche, conclude che il salto più grande nei risultati avviene passando da nessun allenamento di forza a un allenamento qualsiasi, e che il programma migliore è quello che si riesce a seguire nel tempo. L’indicazione minima è allenare tutti i grandi gruppi muscolari almeno due giorni a settimana, come raccomanda anche l’OMS.',
    app: 'Sessioni corte, una versione rapida per i giorni pieni e un calendario che si adatta a 2, 3 o 4 giorni.',
    refs: ['acsm26', 'who20'],
  },
  {
    t: 'A casa e senza attrezzi si ottengono risultati veri',
    p: 'Secondo la stessa posizione ACSM, elastici, esercizi a corpo libero e programmi domestici producono miglioramenti marcati di forza, massa muscolare e funzione. Una meta-analisi ha trovato guadagni di forza simili tra elastici e pesi o macchine.',
    app: 'Tutto il programma funziona con il solo corpo, una sedia, il divano e uno zaino; elastici e kettlebell aggiungono varianti, non sono obbligatori.',
    refs: ['acsm26', 'lopes19'],
  },
  {
    t: 'I carichi leggeri funzionano, se ti avvicini al cedimento',
    p: 'Quando le serie arrivano al cedimento muscolare, carichi bassi e alti producono un aumento di massa muscolare simile; la forza massima invece cresce di più con carichi alti. Una serie di meta-regressioni del 2024 mostra che la crescita muscolare aumenta man mano che la serie si chiude più vicino al cedimento, mentre la forza dipende poco da questo fattore.',
    app: 'Con il corpo libero lo sforzo si regola con la variante e con le ripetizioni in riserva: da 3 nella prima fase a 0–1 nella terza.',
    refs: ['schoenfeld17load', 'robinson24'],
  },
  {
    t: 'Circa 10 serie a settimana per muscolo, di più per le priorità',
    p: 'Il volume settimanale è la variabile con la relazione dose-risposta più chiara per l’ipertrofia: più serie portano più crescita, con rendimenti che diminuiscono man mano. La posizione ACSM indica circa 10 serie settimanali per gruppo muscolare per la crescita. Con volume uguale, distribuire le serie su più giorni cambia poco per la massa muscolare.',
    app: 'Glutei e gambe ricevono il volume maggiore, che cresce fase dopo fase; la parte alta resta intorno al minimo efficace.',
    refs: ['acsm26', 'schoenfeld17vol', 'pelland26'],
  },
  {
    t: 'Glutei: profondità, ponte e lavoro su una gamba',
    p: 'In nove settimane, hip thrust e squat hanno prodotto una crescita dei glutei simile; lo squat ha fatto crescere di più le cosce. Lo squat profondo ha aumentato il volume di grande gluteo e adduttori più del mezzo squat. Tra gli esercizi con attivazione del grande gluteo molto alta figurano step-up, affondi, split squat, hip thrust e stacchi; l’attivazione elettrica però non predice da sola la crescita.',
    app: 'Ogni sessione combina un esercizio a dominanza di ginocchio profondo, un ponte o hip thrust, una flessione d’anca (stacco) e lavoro per il gluteo medio.',
    refs: ['plotkin23', 'kubo19', 'neto20'],
  },
  {
    t: 'Allenare il muscolo quando è allungato',
    p: 'Una meta-analisi su ampiezza di movimento indica che il movimento completo, o le parziali eseguite nella parte in cui il muscolo è allungato, tendono a dare risultati migliori delle parziali nella parte accorciata.',
    app: 'Discese controllate, pause in basso, varianti con piede rialzato e, nella fase 3, parziali in basso dopo il cedimento tecnico.',
    refs: ['wolf23'],
  },
  {
    t: 'Recuperi e superserie per risparmiare tempo',
    p: 'Recuperare più di 60 secondi tra le serie dello stesso esercizio dà un piccolo vantaggio per l’ipertrofia, ma oltre i 90 secondi non emergono differenze. Superserie e altre tecniche riducono il tempo di allenamento mantenendo il volume; per chi ha poco tempo basta un riscaldamento specifico, senza lunghe sessioni di allungamento.',
    app: 'Tra due serie dello stesso esercizio passano di solito 90–150 secondi, perché in mezzo c’è l’esercizio abbinato. Il riscaldamento dura circa 4 minuti.',
    refs: ['singer24', 'iversen21'],
  },
  {
    t: 'Periodizzazione semplice e settimane leggere',
    p: 'A parità di volume, i modelli di periodizzazione non cambiano la crescita muscolare, mentre danno un piccolo vantaggio sulla forza. Una settimana di stop a metà programma non ha ridotto la crescita muscolare in soggetti allenati, con un piccolo calo di forza degli arti inferiori.',
    app: 'Le fasi aumentano gradualmente volume e impegno; la settimana leggera serve a recuperare e a ripetere i test.',
    refs: ['moesgaard22', 'coleman24', 'acsm26'],
  },
  {
    t: 'Stimare le ripetizioni in riserva si impara',
    p: 'In media sottostimiamo di circa una ripetizione quante ne potremmo ancora fare, e l’errore aumenta nelle serie lunghe, oltre le 12 ripetizioni.',
    app: 'Quando superi la fascia di ripetizioni l’app propone una variante più difficile: le serie restano in un intervallo dove la stima è più affidabile.',
    refs: ['halperin22'],
  },
  {
    t: 'Uomini e donne rispondono in modo simile',
    p: 'In termini relativi la crescita muscolare dopo l’allenamento è simile tra uomini e donne; nelle donne la forza della parte alta aumenta in percentuale persino di più.',
    app: 'Lo stesso programma vale per tutti; cambia solo il livello di partenza, scelto dai test.',
    refs: ['roberts20', 'refalo25'],
  },
  {
    t: 'Quando il tempo manca: il mantenimento',
    p: 'Forza e massa muscolare si mantengono a lungo anche con una sola sessione a settimana e una serie per esercizio, purché l’intensità resti alta; nelle persone più anziane servono due sessioni e 2–3 serie.',
    app: 'La modalità Mantenimento propone due sessioni a settimana con due serie vicino al cedimento.',
    refs: ['spiering21'],
  },
  {
    t: 'Seguire la sessione aiuta',
    p: 'In uno studio su persone anziane, dodici settimane di allenamento a basso carico con corpo libero ed elastici hanno fatto crescere di più i muscoli nel gruppo seguito sempre di persona rispetto a quello che si allenava in parte da solo a casa, a parità di programma. Il dato riguarda un gruppo specifico, ma indica che la qualità dell’esecuzione conta.',
    app: 'Il player guida ogni serie con tempi, voce e indicazioni tecniche, e registra lo sforzo per tenere alta la qualità anche da soli.',
    refs: ['jssm20'],
  },
];

export const TONE = [
  'Il “rassodamento” è la somma di due cose: più massa muscolare e meno grasso sopra il muscolo. L’allenamento di forza fa crescere il muscolo e da solo riduce un po’ il grasso: in media circa 1,5 punti percentuali di grasso corporeo e mezzo chilo di massa grassa, compreso il grasso viscerale.',
  'Il grasso non si consuma nel punto che alleni. In uno studio di dodici settimane in cui si allenava una sola gamba con migliaia di ripetizioni, il grasso è calato nel tronco e nelle braccia, non nella gamba allenata. Per ridurre il grasso su cosce e glutei serve un leggero deficit calorico e movimento quotidiano.',
  'L’OMS raccomanda 150–300 minuti a settimana di attività aerobica moderata oltre alla forza: camminate veloci, bici, scale. Contare i passi è un modo semplice per arrivarci.',
  'Proteine: oltre circa 1,6 g per kg di peso al giorno non si sono visti ulteriori guadagni di massa magra; per una persona di 65 kg sono circa 105 g al giorno, divisi su 3–4 pasti. Dormire 7–9 ore aiuta il recupero.',
  'Per vedere i cambiamenti usa il metro (vita, fianchi, coscia) e foto nelle stesse condizioni ogni 4 settimane: la bilancia da sola può restare ferma mentre il muscolo cresce e il grasso cala.',
];

export const EQUIPMENT_STAGES = [
  {
    t: 'Da subito, senza spendere',
    items: [
      ['Zaino caricabile', 'gratis', 'Libri o bottiglie d’acqua (1 litro = 1 kg). Serve per goblet squat, rematore, hip thrust e stacchi. Chiudi bene il carico e proteggi la schiena con un asciugamano. L’app aumenta il carico di 1 kg alla volta fino al massimo che indichi.'],
      ['Sedia robusta e divano', 'gratis', 'Per squat bulgaro, hip thrust, piegamenti inclinati e appoggio. La sedia va appoggiata al muro.'],
      ['Asciugamano o calze', 'gratis', 'Su parquet o piastrelle diventa uno slider per leg curl e affondi scivolati.'],
    ],
  },
  {
    t: 'Primo acquisto, il più utile per i glutei',
    items: [
      ['Set di mini band in tessuto', 'circa 15–26 €', 'Sblocca conchiglie, abduzioni con elastico e passi laterali per il gluteo medio.'],
      ['Elastico lungo o tubo con maniglie', 'circa 10–20 €', 'Rematore, lat machine con elastico, trazioni assistite e Pallof press: copre la parte alta, che senza attrezzi resta più scoperta.'],
      ['Cavigliere 2 × 1 kg', 'circa 12–20 €', 'Facoltative: aggiungono carico a slanci e abduzioni, i più mirati per i glutei.'],
    ],
  },
  {
    t: 'Secondo acquisto, quando il corpo libero non basta più',
    items: [
      ['Una kettlebell o una coppia di manubri', 'kettlebell 12 kg 35–45 €, coppia 2 × 4 kg 20–35 €', 'Per goblet squat, squat sumo, stacchi, hip thrust e rematori. Indicativamente 8–12 kg per iniziare se non ti alleni con i pesi, 12–16 kg se sei già allenata. Inserisci in Attrezzatura i pesi che hai: l’app sceglie quale usare e quando passare al successivo.'],
      ['Sbarra per trazioni da porta', 'circa 20–30 €', 'Trasforma la tirata verticale in vere trazioni, partendo da scapole e trazioni negative.'],
      ['Cinghie in sospensione', 'circa 25–40 €', 'Rematori inclinati e leg curl: un attrezzo leggero che copre parte alta e femorali.'],
      ['Fitball', 'circa 17–20 €', '55 cm fino a 165 cm di altezza, 65 cm oltre. Per leg curl e rollout.'],
      ['Uno step stabile', 'circa 20–35 €', 'Sblocca gli step-up, tra gli esercizi con maggiore attivazione dei glutei. Va bene anche uno scalino di casa.'],
    ],
  },
];

export const PRICE_NOTE = 'Prezzi indicativi rilevati online a ottobre 2026 (Decathlon e negozi online); possono variare. Sul kettlebell in sé le prove scientifiche sono ancora poche e di bassa qualità: qui è usato semplicemente come carico comodo da tenere in casa.';
export const PRICE_REFS = ['meigh19'];

export const SAFETY = [
  'Prima di iniziare rispondi alle domande di sicurezza (ispirate al questionario PAR‑Q+). Se rispondi sì ad almeno una, parlane con il tuo medico o con uno specialista in medicina dello sport prima di aumentare l’attività.',
  'Fermati subito e chiedi aiuto in caso di dolore o oppressione al petto, fiato corto sproporzionato, capogiri, palpitazioni o dolore improvviso a un’articolazione.',
  'L’indolenzimento muscolare dei giorni successivi è normale, soprattutto nelle prime settimane e quando cambi variante. Il dolore articolare acuto no: segnalalo nella registrazione della serie; se si ripete, l’app torna alla variante più facile. Se il dolore resta anche con la variante più facile, sospendi l’esercizio e fallo valutare.',
  'Respira durante lo sforzo: espira nella fase di spinta e non trattenere il fiato a lungo, in particolare se hai la pressione alta.',
  'In gravidanza, dopo un intervento o con patologie croniche il programma va adattato con il medico.',
  'Questa app è uno strumento di allenamento e non sostituisce una valutazione medica.',
];

export const PARQ = [
  'Un medico ti ha mai detto che hai un problema cardiaco o la pressione alta?',
  'Senti dolore al petto a riposo, nelle attività quotidiane o quando fai attività fisica?',
  'Negli ultimi 12 mesi hai perso l’equilibrio per capogiri o hai perso conoscenza?',
  'Ti è stata diagnosticata un’altra malattia cronica?',
  'Prendi farmaci prescritti per una malattia cronica?',
  'Hai, o hai avuto negli ultimi 12 mesi, un problema a ossa, articolazioni o tessuti molli che l’attività fisica potrebbe peggiorare?',
  'Un medico ti ha mai detto di fare attività fisica solo sotto supervisione medica?',
];
