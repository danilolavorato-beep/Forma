// Forma — struttura del programma a lungo termine.
// Le "scale" (ladders) ordinano le varianti di uno stesso schema dal più facile al più difficile:
// quando raggiungi il massimo della fascia di ripetizioni in tutte le serie, sali di livello.

export const LADDERS = {
  SQ: { name: 'Squat', role: 'lower', list: ['sq_box', 'sq_trx', 'sq_bw', 'sq_tempo', 'sq_15', 'sq_goblet', 'sq_sumo', 'sq_goblet_pause'] },
  SPLIT: { name: 'Affondi e squat bulgaro', role: 'lower', list: ['split_assist', 'split_squat', 'rev_lunge', 'slider_lunge', 'split_loaded', 'split_deficit', 'bss', 'bss_tempo', 'bss_loaded', 'bss_15'] },
  STEP: { name: 'Step-up', role: 'lower', list: ['step_low', 'step_high', 'step_loaded'] },
  BRIDGE: { name: 'Ponte e hip thrust', role: 'lower', list: ['bridge', 'bridge_pause', 'hip_thrust', 'sl_bridge', 'sl_hip_thrust', 'hip_thrust_loaded'] },
  HINGE: { name: 'Stacchi e hip hinge', role: 'lower', list: ['hinge_wall', 'good_morning', 'kb_deadlift', 'sl_rdl_assist', 'sl_rdl', 'rdl_loaded', 'sl_rdl_loaded'] },
  CURL: { name: 'Femorali', role: 'lower', list: ['ham_walkout', 'prone_curl', 'ball_curl', 'trx_curl', 'slider_curl_ecc', 'slider_curl', 'sl_ball_curl', 'sl_slider_curl'] },
  ABD: { name: 'Gluteo medio', role: 'lower', list: ['clamshell', 'clamshell_band', 'side_abd', 'fire_hydrant', 'side_abd_pause', 'side_abd_ankle', 'side_abd_band', 'lateral_walk', 'side_plank_abd'] },
  KICK: { name: 'Slanci per i glutei', role: 'lower', list: ['donkey_kick', 'donkey_band', 'donkey_ankle'] },
  CALF: { name: 'Polpacci', role: 'lower', list: ['calf_raise', 'sl_calf_raise', 'sl_calf_loaded'] },
  PUSH: { name: 'Piegamenti', role: 'upper', list: ['pu_wall', 'pu_high', 'pu_low', 'pu_knee', 'pushup', 'pu_tempo', 'pu_feet_up', 'band_pushup'] },
  PIKE: { name: 'Spalle', role: 'upper', list: ['pike_pushup', 'kb_press', 'pike_feet_up'] },
  PULL: { name: 'Rematori', role: 'upper', list: ['prone_y', 'trx_row_high', 'bp_row', 'band_row', 'trx_row', 'bp_row_pause', 'one_arm_row'] },
  PULLV: { name: 'Dorso alto', role: 'upper', list: ['prone_y', 'band_pullapart', 'band_pulldown'] },
  BAR: { name: 'Trazioni', role: 'upper', list: ['scap_pull', 'neg_pullup', 'band_pullup', 'pullup'] },
  ANTIEXT: { name: 'Core anteriore', role: 'core', list: ['bird_dog', 'dead_bug_legs', 'dead_bug', 'plank', 'ball_rollout', 'plank_taps', 'hang_knee', 'plank_long'] },
  LATERAL: { name: 'Core laterale', role: 'core', list: ['side_plank_knee', 'side_plank', 'pallof', 'side_plank_abd'] },
};
const at = (ladder, id) => LADDERS[ladder].list.indexOf(id);

// Slot con alternative: se la scala principale non ha varianti disponibili (attrezzi) o non è sbloccata,
// si usa la successiva.
export const SLOT = {
  STEP_OR_SPLIT: { ladders: ['STEP', 'SPLIT'] },
  PIKE_OR_PUSH: { ladders: ['PIKE', 'PUSH'], unlock: { PUSH: 4 } },
  // con la sbarra la tirata verticale diventa una vera trazione
  VPULL: { ladders: ['BAR', 'PULLV'] },
};

// i = item: { s: scala o slot, n: serie, e: serie nelle prime 2 settimane della fase (opzionale), main: esercizio principale,
//            opt: attrezzi che aggiungono l'esercizio al piano (se non ne hai nessuno l'esercizio viene saltato) }
const b = (rest, ...items) => ({ rest, items });
const i = (s, n, extra = {}) => ({ s, n, ...extra });

export const PHASES = [
  {
    id: 'f1', name: 'Fondamenta', from: 1, to: 4, rir: 3, light: [],
    goal: 'Imparare i movimenti, costruire l’abitudine e preparare tendini e articolazioni.',
    how: 'Fermati con circa 3 ripetizioni ancora in canna. Discesa in 2 secondi, breve pausa in basso.',
    note: 'Tempo 2-1-2: scendi in 2 secondi, 1 di pausa, sali in 2.',
    sessions: {
      A: [b(50, i('SQ', 3, { e: 2, main: true }), i('PUSH', 3, { e: 2 })), b(50, i('BRIDGE', 3, { e: 2, main: true }), i('PULL', 3, { e: 2 })), b(40, i('ABD', 2), i('ANTIEXT', 2))],
      B: [b(50, i('SPLIT', 3, { e: 2, main: true }), i('PULL', 3, { e: 2 })), b(50, i('HINGE', 3, { e: 2, main: true }), i('PUSH', 3, { e: 2 })), b(40, i('BRIDGE', 2), i('LATERAL', 2))],
      C: [b(50, i('BRIDGE', 3, { e: 2, main: true }), i('PUSH', 3, { e: 2 })), b(50, i('SQ', 3, { e: 2, main: true }), i('VPULL', 3, { e: 2 })), b(40, i('ABD', 2), i('ANTIEXT', 2))],
      D: [b(50, i('BRIDGE', 3, { e: 2, main: true }), i('ABD', 3, { e: 2 })), b(50, i('SPLIT', 2), i('LATERAL', 2))],
    },
  },
  {
    id: 'f2', name: 'Costruzione', from: 5, to: 10, rir: 2, light: [10],
    goal: 'Aumentare il volume per glutei e gambe e introdurre il lavoro su una gamba.',
    how: 'Chiudi ogni serie con 1–2 ripetizioni in canna. Più serie per glutei e gambe.',
    note: 'Discesa controllata in 2–3 secondi; chiudi con 1–2 ripetizioni in canna.',
    finisher: ['A', 'C'],
    sessions: {
      A: [b(60, i('SPLIT', 3, { main: true }), i('PUSH', 3)), b(60, i('BRIDGE', 3, { main: true }), i('PULL', 3)), b(40, i('ABD', 3), i('ANTIEXT', 2), i('CALF', 2))],
      B: [b(60, i('SQ', 3, { main: true }), i('PULL', 3)), b(60, i('HINGE', 3, { main: true }), i('PUSH', 3)), b(40, i('CURL', 3), i('ABD', 2), i('LATERAL', 2), i('KICK', 2, { opt: ['cavigliere', 'miniband', 'band'] }))],
      C: [b(60, i('STEP_OR_SPLIT', 3, { main: true }), i('PIKE_OR_PUSH', 3)), b(60, i('BRIDGE', 3, { main: true }), i('VPULL', 3)), b(40, i('ABD', 3), i('ANTIEXT', 2))],
      D: [b(50, i('BRIDGE', 3, { main: true }), i('ABD', 3)), b(50, i('SPLIT', 3), i('HINGE', 3)), b(40, i('CURL', 2))],
    },
  },
  {
    id: 'f3', name: 'Intensificazione', from: 11, to: 16, rir: 1, light: [16],
    goal: 'Portare le serie vicino al cedimento e aggiungere tecniche che allungano il lavoro nella parte bassa del movimento.',
    how: 'Chiudi le serie con 0–1 ripetizioni in canna. Nell’ultima serie degli esercizi principali arriva al cedimento tecnico e aggiungi fino a 5 parziali in basso.',
    note: 'Chiudi ogni serie con 0–1 ripetizioni in canna e controlla la discesa.',
    finisher: ['A', 'C'],
    sessions: {
      A: [b(75, i('SPLIT', 4, { main: true, push: true }), i('PUSH', 3)), b(75, i('BRIDGE', 4, { main: true, push: true }), i('PULL', 3)), b(40, i('ABD', 3), i('ANTIEXT', 2))],
      B: [b(75, i('SQ', 3, { main: true }), i('PULL', 3)), b(75, i('HINGE', 4, { main: true, push: true }), i('PUSH', 3)), b(40, i('CURL', 3), i('LATERAL', 2), i('CALF', 2), i('KICK', 2, { opt: ['cavigliere', 'miniband', 'band'] }))],
      C: [b(75, i('STEP_OR_SPLIT', 4, { main: true, push: true }), i('PIKE_OR_PUSH', 3)), b(60, i('BRIDGE', 3, { main: true }), i('VPULL', 3)), b(40, i('ABD', 3), i('ANTIEXT', 2))],
      D: [b(60, i('BRIDGE', 4, { main: true, push: true }), i('ABD', 3)), b(60, i('HINGE', 3), i('CURL', 3)), b(40, i('KICK', 3, { opt: ['cavigliere', 'miniband', 'band'] }))],
    },
  },
  {
    id: 'f4', name: 'Cicli', from: 17, to: null, rir: 1, light: 'cycle',
    goal: 'Continuare a progredire a blocchi di 6 settimane che cambiano accento: carico, volume per i glutei, densità.',
    how: '5 settimane di lavoro e 1 settimana leggera con test. Le varianti salgono di livello da sole.',
    note: 'Chiudi ogni serie con 0–1 ripetizioni in canna e controlla la discesa.',
    finisher: ['A', 'C'],
    sessions: null, // usa le sessioni della fase 3 con le modifiche del ciclo
  },
];

export const CYCLES = [
  { id: 'carico', name: 'Carico', desc: 'Varianti più impegnative e recuperi pieni: spingi sul livello e sul carico.', rest: 15, extra: {} },
  { id: 'volume', name: 'Volume glutei', desc: 'Una serie in più su ponte, hip thrust e gluteo medio.', rest: 0, extra: { BRIDGE: 1, ABD: 1 } },
  { id: 'densita', name: 'Densità', desc: 'Recuperi più brevi e finisher in ogni sessione: più lavoro nello stesso tempo.', rest: -15, extra: {}, finisherAll: true },
];

export const MAINTENANCE = {
  name: 'Mantenimento',
  desc: 'Due sessioni a settimana, due serie per esercizio vicino al cedimento: basta per conservare forza e massa muscolare quando il tempo manca.',
};

export const ROTATION = { 2: ['A', 'B'], 3: ['A', 'B', 'C'], 4: ['A', 'B', 'C', 'D'] };

export const WARMUP = {
  full: [['march', 40], ['cat_camel', 30], ['good_morning', 35], ['bridge', 35], ['sq_bw', 35], ['rev_lunge', 30]],
  short: [['march', 30], ['bridge', 30], ['sq_bw', 30]],
};

export const COOLDOWN = [['hip_flexor', 30], ['child_pose', 40], ['breathing', 40]];

export const FINISHERS = {
  soft: { name: 'Finisher a basso impatto', rounds: 4, work: 20, rest: 10, moves: ['step_jack', 'fast_squat'] },
  mid: { name: 'Finisher', rounds: 4, work: 20, rest: 10, moves: ['mountain', 'fast_squat'] },
  jump: { name: 'Finisher con salti', rounds: 4, work: 20, rest: 10, moves: ['squat_jump', 'mountain'] },
  kb: { name: 'Finisher con kettlebell', rounds: 6, work: 20, rest: 20, moves: ['swing_time'] },
};

export const TESTS = [
  {
    id: 'squat', ex: 'sq_bw', name: 'Squat a corpo libero', unit: 'rip', kind: 'reps', max: 60,
    how: 'Più ripetizioni possibili con buona tecnica, a ritmo costante (circa 1 ogni 2 secondi). Fermati quando non riesci più a scendere fino in fondo.',
  },
  {
    id: 'bridge', ex: 'sl_bridge', name: 'Ponte su una gamba', unit: 'rip per lato', kind: 'reps', sides: true, max: 50,
    how: 'Massime ripetizioni per lato, bacino che sale fino ad allineare spalle, anca e ginocchio. Riposa 1 minuto tra i lati.',
  },
  {
    id: 'push', ex: 'pushup', name: 'Piegamenti', unit: 'rip', kind: 'reps', variant: ['pu_high', 'pu_knee', 'pushup'], max: 80,
    how: 'Scegli la variante più difficile in cui riesci a fare almeno 5 ripetizioni. Petto vicino all’appoggio a ogni ripetizione.',
  },
  {
    id: 'plank', ex: 'plank', name: 'Plank sugli avambracci', unit: 's', kind: 'time', max: 240,
    how: 'Tieni la posizione finché il bacino resta in linea. Ferma il cronometro quando la tecnica cede.',
  },
];

export const MEASURES = [
  { id: 'peso', name: 'Peso', unit: 'kg', step: 0.1 },
  { id: 'vita', name: 'Vita', unit: 'cm', step: 0.5, how: 'All’altezza dell’ombelico, a fine espirazione.' },
  { id: 'fianchi', name: 'Fianchi', unit: 'cm', step: 0.5, how: 'Nel punto più largo dei glutei, piedi uniti.' },
  { id: 'coscia', name: 'Coscia', unit: 'cm', step: 0.5, how: 'A metà tra anca e ginocchio, gamba rilassata.' },
];

// Livelli di partenza calcolati dai test iniziali
export function levelsFromTests(t, eq = {}) {
  const pick = {};
  const sq = t.squat ?? 0;
  pick.SQ = sq < 10 ? 'sq_box' : sq < 25 ? 'sq_bw' : sq < 40 ? 'sq_tempo' : 'sq_15';
  pick.SPLIT = sq < 12 ? 'split_assist' : sq < 30 ? 'split_squat' : 'rev_lunge';
  pick.STEP = sq < 20 ? 'step_low' : 'step_high';
  const br = Math.min(t.bridgeR ?? 0, t.bridgeL ?? 0);
  pick.BRIDGE = br < 6 ? 'bridge' : br < 12 ? 'bridge_pause' : br < 20 ? 'hip_thrust' : br < 30 ? 'sl_bridge' : 'sl_hip_thrust';
  pick.HINGE = br < 10 ? 'hinge_wall' : br < 20 ? 'good_morning' : 'sl_rdl_assist';
  pick.CURL = br < 15 ? 'ham_walkout' : 'slider_curl_ecc';
  pick.ABD = br < 10 ? 'clamshell' : br < 25 ? 'side_abd' : 'side_abd_pause';
  pick.KICK = 'donkey_kick';
  pick.CALF = 'calf_raise';
  const pv = t.pushVariant || 'pushup';
  const pr = t.push ?? 0;
  if (pv === 'pu_high') pick.PUSH = pr < 8 ? 'pu_wall' : pr <= 20 ? 'pu_high' : 'pu_low';
  else if (pv === 'pu_knee') pick.PUSH = pr < 8 ? 'pu_low' : pr <= 20 ? 'pu_knee' : 'pushup';
  else pick.PUSH = pr < 5 ? 'pu_knee' : pr <= 12 ? 'pushup' : pr <= 25 ? 'pu_tempo' : 'pu_feet_up';
  pick.PIKE = 'pike_pushup';
  pick.PULL = eq.trx ? 'trx_row_high' : eq.zaino || eq.manubri ? 'bp_row' : 'prone_y';
  pick.PULLV = 'prone_y';
  pick.BAR = 'scap_pull';
  const pl = t.plank ?? 0;
  pick.ANTIEXT = pl < 20 ? 'bird_dog' : pl < 40 ? 'dead_bug_legs' : pl < 60 ? 'dead_bug' : pl < 90 ? 'plank' : 'plank_taps';
  pick.LATERAL = pl < 30 ? 'side_plank_knee' : pl < 75 ? 'side_plank' : 'side_plank_abd';
  const lv = {};
  for (const k in pick) lv[k] = at(k, pick[k]);
  return lv;
}

export const DEFAULT_LEVELS = {
  SQ: at('SQ', 'sq_bw'), SPLIT: 0, STEP: 0, BRIDGE: 0, HINGE: 0, CURL: 0, ABD: 0, KICK: 0, CALF: 0,
  PUSH: at('PUSH', 'pu_high'), PIKE: 0, PULL: at('PULL', 'bp_row'), PULLV: 0, BAR: 0, ANTIEXT: 0, LATERAL: 0,
};
