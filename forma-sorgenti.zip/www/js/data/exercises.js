// Forma — libreria esercizi.
// type: 'reps' (ripetizioni) o 'time' (secondi). uni: true = per lato.
// range: [min, max] della fascia di lavoro. eq: gruppi di attrezzi richiesti (basta uno per gruppo).
// cat: gambe | glutei | femorali | spinta | tirata | core | mobilita | cardio

// group: dove compare nella schermata Attrezzatura. weights: 'list' (pesi che possiedi) o 'max' (carico regolabile).
export const EQUIP = {
  zaino: { name: 'Zaino caricabile', group: 'casa', desc: 'Libri o bottiglie d’acqua (1 litro = 1 kg) in uno zaino robusto.', price: 'gratis', def: true, weights: 'max', defWeights: 8, choices: [4, 6, 8, 10, 12, 15, 18, 20] },
  liscio: { name: 'Pavimento liscio e asciugamano', group: 'casa', desc: 'Parquet o piastrelle, con calze o un asciugamano sotto piedi o talloni: fa da slider.', price: 'gratis', def: true },
  gradino: { name: 'Gradino o step', group: 'casa', desc: 'Uno scalino, uno step o una panca stabile alta 20–45 cm.', price: 'gratis o 20–35 €', def: false },
  miniband: { name: 'Mini band', group: 'elastici', desc: 'Elastico ad anello corto, meglio in tessuto: per gluteo medio e abduzioni.', price: '15–26 € il set', def: false },
  band: { name: 'Elastico lungo', group: 'elastici', desc: 'Tubo con maniglie o banda lunga: rematori, trazioni assistite, pull-apart, Pallof.', price: '10–20 €', def: false },
  kb: { name: 'Kettlebell', group: 'pesi', desc: 'Goblet squat, stacchi, hip thrust e swing.', price: '35–45 € (12 kg)', def: false, weights: 'list', defWeights: [12], choices: [4, 6, 8, 10, 12, 14, 16, 20, 24] },
  manubri: { name: 'Manubri', group: 'pesi', desc: 'Una o più coppie: stacchi, affondi, rematori e spinte con due pesi.', price: '20–35 € la coppia da 4 kg', def: false, weights: 'list', defWeights: [4], choices: [1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 20] },
  cavigliere: { name: 'Cavigliere zavorrate', group: 'pesi', desc: 'Pesi alle caviglie per slanci, idranti e abduzioni.', price: '12–20 € la coppia', def: false, weights: 'list', defWeights: [1], choices: [0.5, 1, 1.5, 2, 3] },
  sbarra: { name: 'Sbarra per trazioni', group: 'altro', desc: 'Da montare nello stipite della porta: trazioni e sollevamento delle ginocchia.', price: '20–30 €', def: false },
  trx: { name: 'Cinghie in sospensione (tipo TRX)', group: 'altro', desc: 'Si agganciano alla porta: rematori inclinati, leg curl, squat assistito.', price: '25–40 € (originale TRX oltre 150 €)', def: false },
  fitball: { name: 'Fitball', group: 'altro', desc: '55 cm fino a 165 cm di altezza, 65 cm oltre: leg curl, rollout.', price: '17–20 €', def: false },
};

export const EQUIP_GROUPS = [
  ['casa', 'Già in casa'],
  ['elastici', 'Elastici'],
  ['pesi', 'Pesi'],
  ['altro', 'Altri attrezzi'],
];

const LOAD = [['zaino', 'kb', 'manubri']];
const IRON = [['kb', 'manubri']];
// Ordine di preferenza dell'attrezzo e classe di carico (per il peso di partenza)
const BIG = { impl: ['kb', 'manubri', 'zaino'], load: 'big' };
const UNI = { impl: ['manubri', 'kb', 'zaino'], load: 'uni' };

export const EX = {
  // ---------------- GAMBE: squat ----------------
  sq_box: {
    name: 'Squat alla sedia', anim: 'box_squat', cat: 'gambe', type: 'reps', range: [8, 15],
    muscles: 'Glutei, quadricipiti, adduttori',
    cues: ['Piedi alla larghezza delle spalle, punte un po’ aperte', 'Spingi indietro il bacino e sfiora la sedia senza sederti di peso', 'Ginocchia nella direzione delle punte', 'Risali spingendo con tutto il piede'],
    errors: ['Lasciarsi cadere sulla sedia', 'Ginocchia che si chiudono verso l’interno', 'Talloni che si staccano'],
  },
  sq_bw: {
    name: 'Squat a corpo libero', anim: 'squat', cat: 'gambe', type: 'reps', range: [10, 20],
    muscles: 'Glutei, quadricipiti, adduttori',
    cues: ['Scendi il più in basso possibile mantenendo la schiena neutra', 'Braccia avanti per bilanciarti', 'Ginocchia sopra le punte', 'Spingi il pavimento per risalire'],
    errors: ['Fermarsi a metà discesa', 'Schiena che si incurva in basso', 'Peso sulle punte'],
  },
  sq_tempo: {
    name: 'Squat 3-1-1', anim: 'squat_tempo', cat: 'gambe', type: 'reps', range: [10, 20], tempo: '3-1-1',
    muscles: 'Glutei, quadricipiti, adduttori',
    cues: ['Conta 3 secondi in discesa', '1 secondo fermo in basso, senza rimbalzare', 'Risali deciso in 1 secondo'],
    errors: ['Accelerare la discesa quando arriva la fatica', 'Rilassarsi nella pausa in basso'],
  },
  sq_15: {
    pace: 6, name: 'Squat 1½', anim: 'squat15', cat: 'gambe', type: 'reps', range: [8, 15],
    muscles: 'Glutei, quadricipiti, adduttori',
    cues: ['Scendi in fondo, risali a metà, riscendi in fondo, poi sali: è 1 ripetizione', 'Lavora nella parte bassa, dove i glutei sono più allungati'],
    errors: ['Mezza ripetizione troppo corta', 'Perdere la profondità nella seconda discesa'],
  },
  sq_goblet: {
    ...BIG, name: 'Goblet squat', anim: 'goblet', cat: 'gambe', type: 'reps', range: [8, 15], eq: LOAD, loaded: true,
    muscles: 'Glutei, quadricipiti, adduttori',
    cues: ['Tieni il carico al petto (kettlebell per le maniglie, manubrio in verticale, zaino abbracciato), gomiti in basso', 'Petto alto, scendi tra le ginocchia', 'Spingi il pavimento con tutto il piede'],
    errors: ['Carico che si allontana dal petto', 'Ginocchia che si chiudono'],
  },
  sq_goblet_pause: {
    ...BIG, pace: 5.5, name: 'Goblet squat con pausa', anim: 'goblet_pause', cat: 'gambe', type: 'reps', range: [8, 12], eq: LOAD, loaded: true,
    muscles: 'Glutei, quadricipiti, adduttori',
    cues: ['Discesa in 2–3 secondi', '2 secondi fermo in basso, tronco attivo', 'Risali deciso'],
    errors: ['Rimbalzare in basso invece di fermarsi'],
  },
  wall_sit: {
    name: 'Sedia al muro', anim: 'wallsit', cat: 'gambe', type: 'time', range: [20, 60],
    muscles: 'Quadricipiti, glutei',
    cues: ['Schiena appoggiata al muro, cosce parallele al pavimento', 'Ginocchia sopra le caviglie', 'Respira con calma'],
    errors: ['Mani appoggiate sulle cosce', 'Ginocchia oltre le punte'],
  },

  // ---------------- GAMBE: affondi e split squat ----------------
  split_assist: {
    name: 'Split squat con appoggio', anim: 'split_assist', cat: 'gambe', type: 'reps', uni: true, range: [6, 12],
    muscles: 'Glutei, quadricipiti',
    cues: ['Un piede avanti e uno indietro, come su due binari', 'Appoggia una mano allo schienale di una sedia', 'Scendi in verticale finché il ginocchio dietro sfiora il pavimento', 'Spingi con il tallone del piede avanti'],
    errors: ['Tirarsi su con il braccio', 'Ginocchio avanti che crolla verso l’interno'],
  },
  split_squat: {
    name: 'Split squat', anim: 'split', cat: 'gambe', type: 'reps', uni: true, range: [8, 15],
    muscles: 'Glutei, quadricipiti',
    cues: ['Piedi distanti un passo lungo, larghi come le anche', 'Scendi dritto verso il basso', 'Ginocchio dietro che sfiora il pavimento', 'Busto leggermente in avanti per coinvolgere di più il gluteo'],
    errors: ['Passo troppo corto', 'Spinta con la gamba dietro'],
  },
  rev_lunge: {
    name: 'Affondo indietro', anim: 'rev_lunge', cat: 'gambe', type: 'reps', uni: true, range: [8, 15],
    muscles: 'Glutei, quadricipiti',
    cues: ['Fai un passo indietro e scendi', 'Il peso resta sulla gamba davanti', 'Torna su spingendo con il tallone davanti', 'Completa tutte le ripetizioni di un lato, poi cambia'],
    errors: ['Piede dietro troppo vicino', 'Busto che crolla in avanti'],
  },
  split_deficit: {
    name: 'Split squat con piede avanti rialzato', anim: 'split_deficit', cat: 'gambe', type: 'reps', uni: true, range: [8, 12],
    muscles: 'Glutei, quadricipiti',
    cues: ['Piede davanti su 5–10 cm (libri stabili o un gradino basso)', 'Scendi più in basso del solito: è lì che il gluteo lavora di più', 'Discesa controllata in 2 secondi'],
    errors: ['Rialzo instabile', 'Rimbalzare in basso'],
  },
  bss: {
    name: 'Squat bulgaro', anim: 'bss', cat: 'gambe', type: 'reps', uni: true, range: [8, 15],
    muscles: 'Glutei, quadricipiti, adduttori',
    cues: ['Collo del piede dietro su sedia o divano', 'Piede avanti a un passo e mezzo di distanza', 'Busto inclinato in avanti per spostare il lavoro sul gluteo', 'Scendi finché la coscia davanti è parallela al pavimento'],
    errors: ['Piede davanti troppo vicino alla sedia', 'Spinta con la gamba dietro', 'Ginocchio avanti che crolla verso l’interno'],
  },
  bss_tempo: {
    name: 'Squat bulgaro 3-1-1', anim: 'bss_tempo', cat: 'gambe', type: 'reps', uni: true, range: [8, 12], tempo: '3-1-1',
    muscles: 'Glutei, quadricipiti, adduttori',
    cues: ['3 secondi in discesa', '1 secondo fermo in basso', 'Su in 1 secondo'],
    errors: ['Accorciare la discesa sulle ultime ripetizioni'],
  },
  bss_loaded: {
    ...UNI, name: 'Squat bulgaro con carico', anim: 'bss_kb', cat: 'gambe', type: 'reps', uni: true, range: [8, 12], eq: LOAD, loaded: true,
    muscles: 'Glutei, quadricipiti, adduttori',
    cues: ['Carico al petto (o zaino sulle spalle)', 'Busto leggermente avanti', 'Discesa in 2 secondi, su deciso'],
    errors: ['Perdere l’equilibrio per un carico troppo pesante: riduci e controlla'],
  },
  bss_15: {
    ...UNI, pace: 6, name: 'Squat bulgaro 1½ con carico', anim: 'bss15_kb', cat: 'gambe', type: 'reps', uni: true, range: [6, 10], eq: LOAD, loaded: true,
    muscles: 'Glutei, quadricipiti, adduttori',
    cues: ['Giù in fondo, su a metà, di nuovo giù, poi su: 1 ripetizione', 'Resta a lungo nella parte bassa'],
    errors: ['Mezza ripetizione troppo corta'],
  },
  step_low: {
    name: 'Step-up su gradino', anim: 'stepup', cat: 'gambe', type: 'reps', uni: true, range: [8, 15], eq: [['gradino']],
    muscles: 'Glutei, quadricipiti',
    cues: ['Tutto il piede sul gradino', 'Spingi con la gamba sopra, non saltare con quella sotto', 'Scendi lentamente, in 2 secondi'],
    errors: ['Darsi la spinta con il piede a terra', 'Ginocchio che crolla verso l’interno'],
  },
  step_high: {
    name: 'Step-up alto', anim: 'stepup_high', cat: 'gambe', type: 'reps', uni: true, range: [8, 12], eq: [['gradino']],
    muscles: 'Glutei, quadricipiti',
    cues: ['Rialzo stabile all’altezza del ginocchio o poco sotto', 'Busto un po’ in avanti all’inizio', 'Sali fino in piedi, scendi controllando'],
    errors: ['Rialzo che si muove', 'Spinta con il piede a terra'],
  },
  step_loaded: {
    ...UNI, name: 'Step-up con carico', anim: 'stepup_kb', cat: 'gambe', type: 'reps', uni: true, range: [8, 12], eq: [['gradino'], ['zaino', 'kb']], loaded: true,
    muscles: 'Glutei, quadricipiti',
    cues: ['Carico al petto o zaino in spalla', 'Sali e scendi con controllo, senza slanci'],
    errors: ['Carico che sbilancia: riduci il peso'],
  },

  // ---------------- GLUTEI: ponte e hip thrust ----------------
  bridge: {
    name: 'Ponte glutei', anim: 'bridge', cat: 'glutei', type: 'reps', range: [12, 20],
    muscles: 'Grande gluteo, femorali',
    cues: ['Talloni a circa 30 cm dai glutei', 'Spingi con i talloni e solleva il bacino', 'In alto stringi i glutei per 1 secondo, costole basse', 'Scendi lentamente'],
    errors: ['Inarcare la zona lombare invece di estendere l’anca', 'Spingere con le punte'],
  },
  bridge_pause: {
    pace: 4.5, name: 'Ponte con pausa in alto', anim: 'bridge_pause', cat: 'glutei', type: 'reps', range: [10, 20],
    muscles: 'Grande gluteo, femorali',
    cues: ['Come il ponte, ma resta 2 secondi in alto', 'Bacino stabile, non inarcare la schiena'],
    errors: ['Accorciare la pausa con la fatica'],
  },
  hip_thrust: {
    pace: 3.5, name: 'Hip thrust al divano', anim: 'hipthrust', cat: 'glutei', type: 'reps', range: [10, 20],
    muscles: 'Grande gluteo',
    cues: ['Parte alta della schiena sul bordo del divano o di una panca stabile', 'Piedi larghi come le anche, tibie verticali in alto', 'Mento leggermente verso il petto', 'Spingi coi talloni fino ad allineare spalle, anche e ginocchia'],
    errors: ['Divano che scivola', 'Iperestendere la schiena in alto'],
  },
  sl_bridge: {
    name: 'Ponte su una gamba', anim: 'sl_bridge', cat: 'glutei', type: 'reps', uni: true, range: [8, 15],
    muscles: 'Grande gluteo, femorali',
    cues: ['Una gamba tesa verso l’alto o ginocchio al petto', 'Spingi con il tallone a terra', 'Bacino dritto: non deve ruotare'],
    errors: ['Bacino che cade dal lato della gamba sollevata'],
  },
  sl_hip_thrust: {
    pace: 3.5, name: 'Hip thrust su una gamba', anim: 'sl_hipthrust', cat: 'glutei', type: 'reps', uni: true, range: [8, 15],
    muscles: 'Grande gluteo',
    cues: ['Schiena sul divano, una gamba sollevata', 'Scendi in profondità e risali con il tallone', 'In alto bacino a livello'],
    errors: ['Usare lo slancio', 'Bacino che ruota'],
  },
  hip_thrust_loaded: {
    ...BIG, pace: 4, name: 'Hip thrust con carico', anim: 'hipthrust_kb', cat: 'glutei', type: 'reps', range: [8, 15], eq: LOAD, loaded: true,
    muscles: 'Grande gluteo',
    cues: ['Carico appoggiato sul bacino, tenuto con le mani (metti un asciugamano sotto)', '1 secondo di contrazione in alto', 'Scendi controllando'],
    errors: ['Carico che scivola: tienilo con entrambe le mani'],
  },
  frog_pump: {
    pace: 1.5, name: 'Frog pump', anim: 'frogpump', cat: 'glutei', type: 'reps', range: [15, 30],
    muscles: 'Grande gluteo',
    cues: ['Piante dei piedi unite, ginocchia aperte', 'Piccoli sollevamenti rapidi del bacino', 'Stringi i glutei in alto'],
    errors: ['Muovere la schiena invece del bacino'],
  },

  // ---------------- GLUTEI e FEMORALI: hip hinge ----------------
  hinge_wall: {
    name: 'Hip hinge al muro', anim: 'hinge_wall', cat: 'femorali', type: 'reps', range: [10, 15],
    muscles: 'Femorali, glutei, erettori',
    cues: ['Schiena al muro, talloni a 20–30 cm da esso', 'Spingi il bacino indietro fino a toccare il muro', 'Schiena dritta, ginocchia appena flesse', 'Torna su spingendo il bacino in avanti'],
    errors: ['Piegare le ginocchia come in uno squat', 'Incurvare la schiena'],
  },
  good_morning: {
    pace: 4.5, name: 'Good morning', anim: 'goodmorning', cat: 'femorali', type: 'reps', range: [10, 15],
    muscles: 'Femorali, glutei, erettori',
    cues: ['Mani dietro la testa o zaino sulle spalle', 'Bacino indietro, busto quasi parallelo al pavimento', 'Senti l’allungamento dietro le cosce', 'Discesa in 3 secondi'],
    errors: ['Schiena che si incurva', 'Scendere oltre la propria flessibilità'],
  },
  sl_rdl_assist: {
    pace: 4, name: 'Stacco rumeno su una gamba con appoggio', anim: 'slrdl_assist', cat: 'femorali', type: 'reps', uni: true, range: [8, 12],
    muscles: 'Glutei, femorali',
    cues: ['Una mano sul muro solo per l’equilibrio', 'La gamba libera va indietro in linea con il busto', 'Bacino parallelo al pavimento', 'Torna su spingendo con il tallone a terra'],
    errors: ['Ruotare il bacino verso l’alto', 'Piegare troppo il ginocchio d’appoggio'],
  },
  sl_rdl: {
    pace: 4, name: 'Stacco rumeno su una gamba', anim: 'slrdl', cat: 'femorali', type: 'reps', uni: true, range: [8, 12],
    muscles: 'Glutei, femorali',
    cues: ['Ginocchio d’appoggio appena flesso', 'Busto e gamba libera si muovono insieme, come un’altalena', 'Scendi finché senti tirare dietro la coscia'],
    errors: ['Perdere l’allineamento del bacino', 'Fretta: l’equilibrio si allena andando piano'],
  },
  rdl_loaded: {
    impl: ['manubri', 'kb', 'zaino'], load: 'big', name: 'Stacco rumeno con carico', anim: 'rdl_kb', cat: 'femorali', type: 'reps', range: [8, 15], eq: LOAD, loaded: true,
    muscles: 'Femorali, glutei',
    cues: ['Carico vicino alle gambe', 'Bacino indietro, schiena neutra', 'Scendi fin sotto le ginocchia, risali stringendo i glutei'],
    errors: ['Carico che si allontana dal corpo', 'Arrotondare la schiena'],
  },
  sl_rdl_loaded: {
    ...UNI, pace: 4, name: 'Stacco rumeno su una gamba con carico', anim: 'slrdl_kb', cat: 'femorali', type: 'reps', uni: true, range: [8, 12], eq: LOAD, loaded: true,
    muscles: 'Glutei, femorali',
    cues: ['Carico nella mano opposta alla gamba d’appoggio', 'Movimento lento e controllato'],
    errors: ['Ruotare il busto verso il carico'],
  },
  kb_swing: {
    impl: ['kb'], load: 'swing', pace: 2, name: 'Kettlebell swing', anim: 'swing', cat: 'femorali', type: 'reps', range: [12, 20], eq: [['kb']], loaded: true,
    muscles: 'Glutei, femorali, core',
    cues: ['È una spinta d’anca, non uno squat', 'La kettlebell passa alta tra le gambe', 'Scatta con i glutei: le braccia accompagnano soltanto', 'In alto corpo dritto come in un plank in piedi'],
    errors: ['Sollevare con le braccia', 'Inarcare la schiena in alto', 'Piegare troppo le ginocchia'],
  },

  // ---------------- FEMORALI: leg curl ----------------
  ham_walkout: {
    pace: 6, name: 'Walkout femorali', anim: 'walkout', cat: 'femorali', type: 'reps', range: [6, 10],
    muscles: 'Femorali, glutei',
    cues: ['Parti dal ponte', 'A piccoli passi porta i talloni lontano finché le gambe sono quasi tese', 'Torna indietro a piccoli passi senza abbassare il bacino'],
    errors: ['Far cadere il bacino a terra'],
  },
  slider_curl_ecc: {
    pace: 5, name: 'Leg curl eccentrico con asciugamano', anim: 'curl_ecc', cat: 'femorali', type: 'reps', range: [6, 10], eq: [['liscio']],
    muscles: 'Femorali',
    cues: ['Talloni sull’asciugamano, bacino sollevato', 'Allunga le gambe lentamente in 3–4 secondi', 'Abbassa il bacino e riporta i talloni vicino ai glutei per ripartire'],
    errors: ['Lasciar cadere il bacino durante l’allungamento'],
  },
  slider_curl: {
    name: 'Leg curl con asciugamano', anim: 'curl', cat: 'femorali', type: 'reps', range: [8, 15], eq: [['liscio']],
    muscles: 'Femorali, glutei',
    cues: ['Bacino alto per tutta la serie', 'Tira i talloni verso i glutei', 'Allunga di nuovo lentamente'],
    errors: ['Bacino che scende quando le gambe sono tese'],
  },
  sl_slider_curl: {
    name: 'Leg curl su una gamba', anim: 'sl_curl', cat: 'femorali', type: 'reps', uni: true, range: [6, 12], eq: [['liscio']],
    muscles: 'Femorali, glutei',
    cues: ['Una gamba sollevata, l’altra sull’asciugamano', 'Bacino alto e dritto', 'Allunga lentamente'],
    errors: ['Bacino che ruota'],
  },

  // ---------------- GLUTEO MEDIO ----------------
  side_abd: {
    pace: 2.2, name: 'Abduzione su un fianco', anim: 'sideabd', cat: 'glutei', type: 'reps', uni: true, range: [12, 20],
    muscles: 'Gluteo medio e piccolo',
    cues: ['Sdraiato su un fianco, corpo in linea', 'Solleva la gamba di sopra leggermente all’indietro', 'Punta del piede rivolta in avanti o un po’ verso il basso', 'Scendi lentamente'],
    errors: ['Ruotare il bacino all’indietro', 'Portare la gamba in avanti'],
  },
  side_abd_pause: {
    pace: 4, name: 'Abduzione su un fianco con pausa', anim: 'sideabd_pause', cat: 'glutei', type: 'reps', uni: true, range: [10, 15],
    muscles: 'Gluteo medio e piccolo',
    cues: ['Resta 2 secondi in alto', 'Bacino fermo, solo la gamba si muove'],
    errors: ['Usare lo slancio'],
  },
  side_abd_band: {
    pace: 2.2, name: 'Abduzione su un fianco con mini band', anim: 'sideabd_band', cat: 'glutei', type: 'reps', uni: true, range: [10, 20], eq: [['miniband']],
    muscles: 'Gluteo medio e piccolo',
    cues: ['Mini band sopra le ginocchia o alle caviglie', 'Solleva e controlla la discesa'],
    errors: ['Band troppo duro: perdi l’allineamento'],
  },
  lateral_walk: {
    pace: 1.6, name: 'Passi laterali con mini band', anim: 'latwalk', cat: 'glutei', type: 'reps', uni: true, range: [10, 20], eq: [['miniband']],
    muscles: 'Gluteo medio e piccolo',
    cues: ['Mezzo squat, band alle caviglie o sopra le ginocchia', 'Passi laterali senza far toccare i piedi', 'Ginocchia spinte leggermente in fuori', 'Le ripetizioni sono passi per lato'],
    errors: ['Alzarsi in piedi durante i passi', 'Piedi che si avvicinano troppo'],
  },
  side_plank_abd: {
    pace: 3, name: 'Plank laterale con abduzione', anim: 'sideplank_abd', cat: 'glutei', type: 'reps', uni: true, range: [6, 12],
    muscles: 'Gluteo medio, obliqui',
    cues: ['Plank laterale sull’avambraccio', 'Solleva la gamba di sopra e riabbassala lentamente', 'Bacino alto per tutta la serie'],
    errors: ['Bacino che crolla verso il pavimento'],
  },

  // ---------------- POLPACCI ----------------
  calf_raise: {
    pace: 2.5, name: 'Sollevamento sui polpacci', anim: 'calf', cat: 'gambe', type: 'reps', range: [15, 25],
    muscles: 'Polpacci',
    cues: ['Sali più in alto che puoi', '1 secondo in alto, scendi in 2 secondi', 'Una mano al muro per l’equilibrio'],
    errors: ['Rimbalzare'],
  },
  sl_calf_raise: {
    pace: 2.5, name: 'Polpacci su una gamba', anim: 'sl_calf', cat: 'gambe', type: 'reps', uni: true, range: [10, 20],
    muscles: 'Polpacci',
    cues: ['Su un gradino puoi scendere con il tallone sotto il livello del piede', 'Pausa in alto, discesa lenta'],
    errors: ['Movimento corto'],
  },

  // ---------------- SPINTA ----------------
  pu_wall: {
    name: 'Piegamenti al muro', anim: 'pu_wall', cat: 'spinta', type: 'reps', range: [10, 20],
    muscles: 'Pettorali, tricipiti, spalle',
    cues: ['Mani al muro all’altezza delle spalle', 'Corpo in linea dalla testa ai talloni', 'Gomiti a 45° dal busto'],
    errors: ['Bacino che sporge indietro', 'Gomiti larghi a 90°'],
  },
  pu_high: {
    name: 'Piegamenti inclinati al piano cucina', anim: 'pu_counter', cat: 'spinta', type: 'reps', range: [8, 15],
    muscles: 'Pettorali, tricipiti, spalle',
    cues: ['Mani sul bordo di un piano stabile alto circa 90 cm', 'Corpo dritto, glutei stretti', 'Porta il petto verso il bordo'],
    errors: ['Piano che si muove', 'Bacino che cede'],
  },
  pu_low: {
    name: 'Piegamenti inclinati al divano', anim: 'pu_sofa', cat: 'spinta', type: 'reps', range: [8, 15],
    muscles: 'Pettorali, tricipiti, spalle',
    cues: ['Mani su divano, sedia contro il muro o gradino', 'Più basso è l’appoggio, più è difficile', 'Petto al bordo, gomiti a 45°'],
    errors: ['Testa che anticipa il petto'],
  },
  pu_knee: {
    name: 'Piegamenti sulle ginocchia', anim: 'pu_knee', cat: 'spinta', type: 'reps', range: [8, 15],
    muscles: 'Pettorali, tricipiti, spalle',
    cues: ['Ginocchia su un cuscino, corpo dritto dalle ginocchia alla testa', 'Petto quasi a terra', 'Spingi il pavimento lontano'],
    errors: ['Bacino piegato in alto'],
  },
  pushup: {
    name: 'Piegamenti', anim: 'pushup', cat: 'spinta', type: 'reps', range: [6, 15],
    muscles: 'Pettorali, tricipiti, spalle, core',
    cues: ['Mani poco più larghe delle spalle', 'Corpo rigido come una tavola', 'Petto a un pugno da terra', 'Gomiti a 45°'],
    errors: ['Bacino che cede', 'Movimento a metà'],
  },
  pu_tempo: {
    name: 'Piegamenti 3-1-1', anim: 'pu_tempo', cat: 'spinta', type: 'reps', range: [6, 12], tempo: '3-1-1',
    muscles: 'Pettorali, tricipiti, spalle, core',
    cues: ['3 secondi in discesa', '1 secondo fermo in basso', 'Su deciso'],
    errors: ['Appoggiarsi a terra nella pausa'],
  },
  pu_feet_up: {
    name: 'Piegamenti con piedi rialzati', anim: 'pu_decline', cat: 'spinta', type: 'reps', range: [6, 12],
    muscles: 'Pettorali alti, spalle, tricipiti',
    cues: ['Piedi su sedia o divano', 'Corpo dritto', 'Petto verso le mani'],
    errors: ['Bacino troppo alto o troppo basso'],
  },
  pike_pushup: {
    name: 'Pike push-up', anim: 'pike', cat: 'spinta', type: 'reps', range: [5, 12],
    muscles: 'Spalle, tricipiti',
    cues: ['Bacino in alto, corpo a V rovesciata', 'Porta la testa verso il pavimento davanti alle mani', 'Spingi indietro e in alto'],
    errors: ['Trasformarlo in un piegamento normale abbassando il bacino'],
  },
  kb_press: {
    impl: ['manubri', 'kb'], load: 'press', name: 'Spinta sopra la testa a un braccio', anim: 'kb_press', cat: 'spinta', type: 'reps', uni: true, range: [6, 12], eq: IRON, loaded: true,
    muscles: 'Spalle, tricipiti, core',
    cues: ['Manubrio all’altezza della spalla o kettlebell appoggiata sull’avambraccio, gomito sotto', 'Glutei e addome contratti', 'Spingi in alto fino a braccio teso vicino all’orecchio'],
    errors: ['Inarcare la schiena per spingere'],
  },
  pike_feet_up: {
    name: 'Pike push-up con piedi rialzati', anim: 'pike_feet_up', cat: 'spinta', type: 'reps', range: [5, 10],
    muscles: 'Spalle, tricipiti',
    cues: ['Piedi su sedia o divano, bacino sopra le spalle', 'Testa verso il pavimento, gomiti indietro', 'Movimento lento e controllato'],
    errors: ['Gomiti che si aprono troppo'],
  },

  // ---------------- TIRATA ----------------
  prone_y: {
    pace: 4, name: 'Sollevamenti a Y da prono', anim: 'prone_y', cat: 'tirata', type: 'reps', range: [8, 15],
    muscles: 'Trapezio medio e basso, deltoidi posteriori',
    cues: ['Sdraiato a pancia in giù, braccia avanti a Y, pollici in alto', 'Solleva le braccia da terra e tieni 2 secondi', 'Collo lungo, sguardo a terra'],
    errors: ['Alzare la testa', 'Sollevare con lo slancio'],
  },
  bp_row: {
    impl: ['manubri', 'zaino'], load: 'row', name: 'Rematore piegato', anim: 'bp_row', cat: 'tirata', type: 'reps', range: [8, 15], eq: [['zaino', 'manubri']], loaded: true,
    muscles: 'Dorsali, romboidi, bicipiti',
    cues: ['Busto inclinato in avanti, schiena dritta', 'Tira i manubri o lo zaino verso l’ombelico', 'Avvicina le scapole, scendi lentamente'],
    errors: ['Strattonare con la schiena', 'Spalle che salgono verso le orecchie'],
  },
  band_row: {
    name: 'Rematore con elastico da seduto', anim: 'band_row', cat: 'tirata', type: 'reps', range: [10, 20], eq: [['band']],
    muscles: 'Dorsali, romboidi, bicipiti',
    cues: ['Seduto a gambe tese, elastico attorno alle piante dei piedi', 'Busto dritto', 'Tira i gomiti indietro e chiudi le scapole'],
    errors: ['Dondolare col busto'],
  },
  bp_row_pause: {
    impl: ['manubri', 'zaino'], load: 'row', pace: 5.5, name: 'Rematore piegato con pausa', anim: 'bp_row', cat: 'tirata', type: 'reps', range: [8, 12], eq: [['zaino', 'manubri']], loaded: true,
    muscles: 'Dorsali, romboidi, bicipiti',
    cues: ['Come il rematore, con 2 secondi di pausa in alto', 'Discesa in 3 secondi'],
    errors: ['Perdere la posizione del busto'],
  },
  one_arm_row: {
    impl: ['manubri', 'kb', 'zaino'], load: 'row', name: 'Rematore a un braccio', anim: 'row1', cat: 'tirata', type: 'reps', uni: true, range: [8, 12], eq: LOAD, loaded: true,
    muscles: 'Dorsali, romboidi, bicipiti',
    cues: ['Mano libera su una sedia, schiena piatta', 'Tira il gomito verso il fianco', 'Scendi fino a braccio teso'],
    errors: ['Ruotare il busto per tirare'],
  },
  band_pullapart: {
    name: 'Pull-apart con elastico', anim: 'pullapart', cat: 'tirata', type: 'reps', range: [12, 20], eq: [['band']],
    muscles: 'Deltoidi posteriori, romboidi',
    cues: ['Braccia tese davanti all’altezza delle spalle', 'Apri le braccia fino a toccare il petto con l’elastico', 'Torna lentamente'],
    errors: ['Piegare i gomiti', 'Spalle alte'],
  },

  // ---------------- CORE ----------------
  bird_dog: {
    pace: 4, name: 'Bird dog', anim: 'birddog', cat: 'core', type: 'reps', uni: true, range: [6, 10],
    muscles: 'Core, glutei, erettori',
    cues: ['In quadrupedia, mani sotto le spalle', 'Allunga braccio e gamba opposti', 'Tieni 2 secondi senza ruotare il bacino'],
    errors: ['Inarcare la schiena', 'Ruotare il bacino'],
  },
  dead_bug_legs: {
    pace: 3, name: 'Dead bug solo gambe', anim: 'deadbug_legs', cat: 'core', type: 'reps', uni: true, range: [6, 10],
    muscles: 'Addominali profondi',
    cues: ['Schiena bassa schiacciata a terra', 'Allunga una gamba alla volta sfiorando il pavimento', 'Espira mentre allunghi'],
    errors: ['Schiena che si stacca dal pavimento'],
  },
  dead_bug: {
    pace: 3.5, name: 'Dead bug', anim: 'deadbug', cat: 'core', type: 'reps', uni: true, range: [8, 12],
    muscles: 'Addominali profondi',
    cues: ['Braccia verso il soffitto, gambe a 90°', 'Allunga braccio e gamba opposti', 'Schiena bassa sempre a contatto con il pavimento'],
    errors: ['Muoversi troppo in fretta'],
  },
  plank: {
    name: 'Plank sugli avambracci', anim: 'plank', cat: 'core', type: 'time', range: [20, 45],
    muscles: 'Addominali, core',
    cues: ['Gomiti sotto le spalle', 'Glutei stretti, costole verso il bacino', 'Corpo in linea'],
    errors: ['Bacino che cede', 'Sedere in alto'],
  },
  plank_taps: {
    pace: 1.6, name: 'Plank con tocco della spalla', anim: 'plank_taps', cat: 'core', type: 'reps', range: [8, 16],
    muscles: 'Core, obliqui, spalle',
    cues: ['Plank a braccia tese, piedi un po’ larghi', 'Tocca la spalla opposta senza far oscillare il bacino', 'Conta i tocchi totali'],
    errors: ['Bacino che ondeggia'],
  },
  plank_long: {
    name: 'Plank a leva lunga', anim: 'plank_long', cat: 'core', type: 'time', range: [15, 40],
    muscles: 'Addominali, core',
    cues: ['Gomiti più avanti delle spalle', 'Glutei e addome contratti al massimo', 'Respira corto, senza perdere la posizione'],
    errors: ['Schiena che si inarca'],
  },
  side_plank_knee: {
    name: 'Plank laterale sulle ginocchia', anim: 'sideplank_knee', cat: 'core', type: 'time', uni: true, range: [15, 30],
    muscles: 'Obliqui, gluteo medio',
    cues: ['Gomito sotto la spalla, ginocchia piegate', 'Solleva il bacino in linea con spalle e ginocchia'],
    errors: ['Bacino basso'],
  },
  side_plank: {
    name: 'Plank laterale', anim: 'sideplank', cat: 'core', type: 'time', uni: true, range: [20, 45],
    muscles: 'Obliqui, gluteo medio',
    cues: ['Gomito sotto la spalla, piedi uno sull’altro', 'Corpo dritto dalla testa ai piedi'],
    errors: ['Bacino che scende o va indietro'],
  },

  // ================= ATTREZZI AGGIUNTIVI =================
  sq_trx: {
    name: 'Squat assistito con le cinghie', anim: 'trx_squat', cat: 'gambe', type: 'reps', range: [10, 20], eq: [['trx']],
    muscles: 'Glutei, quadricipiti, adduttori',
    cues: ['Cinghie tese davanti a te, braccia quasi distese', 'Scendi in profondità usando le cinghie solo per l’equilibrio', 'Risali spingendo con i talloni'],
    errors: ['Tirarsi su con le braccia', 'Ginocchia che si chiudono'],
  },
  sq_sumo: {
    impl: ['kb', 'manubri'], load: 'big', name: 'Squat sumo con carico', anim: 'sumo', cat: 'gambe', type: 'reps', range: [8, 15], eq: IRON, loaded: true,
    muscles: 'Glutei, adduttori, quadricipiti',
    cues: ['Piedi molto larghi, punte aperte a 30–45°', 'Carico tra le gambe, braccia distese', 'Ginocchia spinte in fuori sopra le punte', 'Scendi dritto e risali stringendo i glutei'],
    errors: ['Ginocchia che rientrano', 'Busto che crolla in avanti'],
  },
  slider_lunge: {
    pace: 4, name: 'Affondo indietro scivolato', anim: 'slide_lunge', cat: 'gambe', type: 'reps', uni: true, range: [8, 12], eq: [['liscio']],
    muscles: 'Glutei, quadricipiti, adduttori',
    cues: ['Punta del piede dietro su un asciugamano', 'Fai scivolare il piede indietro e scendi sulla gamba davanti', 'Torna tirando con il tallone davanti'],
    errors: ['Caricare il peso sul piede che scivola'],
  },
  split_loaded: {
    ...UNI, name: 'Split squat con carico', anim: 'split_kb', cat: 'gambe', type: 'reps', uni: true, range: [8, 12], eq: LOAD, loaded: true,
    muscles: 'Glutei, quadricipiti',
    cues: ['Carico al petto', 'Scendi dritto finché il ginocchio dietro sfiora il pavimento', 'Spingi con il tallone davanti'],
    errors: ['Passo troppo corto'],
  },
  kb_deadlift: {
    impl: ['kb', 'manubri', 'zaino'], load: 'big', name: 'Stacco da terra con carico', anim: 'kb_deadlift', cat: 'femorali', type: 'reps', range: [8, 15], eq: LOAD, loaded: true,
    muscles: 'Glutei, femorali, quadricipiti',
    cues: ['Carico a terra tra i piedi, gambe un po’ più larghe delle anche', 'Bacino indietro, schiena neutra, afferra il carico', 'Spingi il pavimento e porta il bacino avanti fino in piedi'],
    errors: ['Schiena arrotondata', 'Tirare con le braccia'],
  },
  prone_curl: {
    impl: ['cavigliere'], load: 'ankle', name: 'Leg curl da prono con cavigliere', anim: 'prone_curl', cat: 'femorali', type: 'reps', range: [10, 20], eq: [['cavigliere']], loaded: true,
    muscles: 'Femorali',
    cues: ['A pancia in giù, cavigliere alle caviglie', 'Piega le ginocchia portando i talloni verso i glutei', 'Scendi in 2–3 secondi'],
    errors: ['Sollevare il bacino'],
  },
  ball_curl: {
    name: 'Leg curl con fitball', anim: 'ball_curl', cat: 'femorali', type: 'reps', range: [8, 15], eq: [['fitball']],
    muscles: 'Femorali, glutei',
    cues: ['Talloni sulla fitball, bacino sollevato', 'Avvicina la palla piegando le ginocchia', 'Bacino alto anche quando allunghi'],
    errors: ['Bacino che scende'],
  },
  sl_ball_curl: {
    name: 'Leg curl con fitball su una gamba', anim: 'sl_ball_curl', cat: 'femorali', type: 'reps', uni: true, range: [6, 12], eq: [['fitball']],
    muscles: 'Femorali, glutei',
    cues: ['Un tallone sulla palla, l’altra gamba in alto', 'Bacino alto e dritto', 'Movimento lento'],
    errors: ['Bacino che ruota'],
  },
  trx_curl: {
    name: 'Leg curl con le cinghie', anim: 'trx_curl', cat: 'femorali', type: 'reps', range: [8, 15], eq: [['trx']],
    muscles: 'Femorali, glutei',
    cues: ['Talloni nelle staffe, cinghie verticali', 'Solleva il bacino e porta i talloni verso i glutei', 'Allunga lentamente tenendo il bacino alto'],
    errors: ['Dondolare le cinghie'],
  },
  clamshell: {
    pace: 2.2, name: 'Conchiglia', anim: 'clamshell', cat: 'glutei', type: 'reps', uni: true, range: [12, 25],
    muscles: 'Gluteo medio e piccolo',
    cues: ['Su un fianco, anche e ginocchia piegate, piedi uniti', 'Apri il ginocchio di sopra senza muovere il bacino', 'Chiudi lentamente'],
    errors: ['Ruotare il bacino all’indietro'],
  },
  clamshell_band: {
    pace: 2.4, name: 'Conchiglia con mini band', anim: 'clamshell_band', cat: 'glutei', type: 'reps', uni: true, range: [12, 20], eq: [['miniband']],
    muscles: 'Gluteo medio e piccolo',
    cues: ['Mini band sopra le ginocchia', 'Apri e tieni 1 secondo in alto', 'Bacino fermo'],
    errors: ['Usare lo slancio'],
  },
  fire_hydrant: {
    pace: 2.5, name: 'Idrante', anim: 'hydrant', cat: 'glutei', type: 'reps', uni: true, range: [10, 20],
    muscles: 'Gluteo medio, grande gluteo',
    cues: ['In quadrupedia, ginocchio piegato a 90°', 'Porta la coscia di lato fino all’altezza del bacino', 'Busto e bacino fermi'],
    errors: ['Inclinare il busto dall’altra parte'],
  },
  side_abd_ankle: {
    impl: ['cavigliere'], load: 'ankle', pace: 2.4, name: 'Abduzione su un fianco con cavigliere', anim: 'sideabd_ankle', cat: 'glutei', type: 'reps', uni: true, range: [10, 20], eq: [['cavigliere']], loaded: true,
    muscles: 'Gluteo medio e piccolo',
    cues: ['Cavigliera sulla gamba di sopra', 'Solleva leggermente all’indietro, punta in avanti', 'Scendi in 2 secondi'],
    errors: ['Ruotare il bacino'],
  },
  donkey_kick: {
    pace: 2.4, name: 'Slancio indietro in quadrupedia', anim: 'donkey', cat: 'glutei', type: 'reps', uni: true, range: [12, 20],
    muscles: 'Grande gluteo',
    cues: ['In quadrupedia, ginocchio piegato a 90°', 'Spingi il tallone verso il soffitto fino a coscia orizzontale', 'Non inarcare la schiena'],
    errors: ['Inarcare la zona lombare', 'Slancio veloce'],
  },
  donkey_band: {
    pace: 2.6, name: 'Slancio indietro con elastico', anim: 'donkey_band', cat: 'glutei', type: 'reps', uni: true, range: [10, 20], eq: [['band', 'miniband']],
    muscles: 'Grande gluteo',
    cues: ['Elastico attorno al piede che spinge, tenuto sotto il ginocchio d’appoggio', 'Spingi il tallone in alto, scendi lento'],
    errors: ['Schiena che si inarca'],
  },
  donkey_ankle: {
    impl: ['cavigliere'], load: 'ankle', pace: 2.6, name: 'Slancio indietro con cavigliere', anim: 'donkey_ankle', cat: 'glutei', type: 'reps', uni: true, range: [10, 20], eq: [['cavigliere']], loaded: true,
    muscles: 'Grande gluteo',
    cues: ['Cavigliera sulla gamba che lavora', '1 secondo in alto, discesa in 2'],
    errors: ['Slancio'],
  },
  sl_calf_loaded: {
    impl: ['manubri', 'kb'], load: 'calf', pace: 2.5, name: 'Polpacci su una gamba con carico', anim: 'sl_calf_kb', cat: 'gambe', type: 'reps', uni: true, range: [10, 20], eq: IRON, loaded: true,
    muscles: 'Polpacci',
    cues: ['Peso nella mano dello stesso lato, l’altra al muro', 'Su più alto che puoi, giù lento'],
    errors: ['Movimento corto'],
  },
  band_pushup: {
    name: 'Piegamenti con elastico', anim: 'band_pushup', cat: 'spinta', type: 'reps', range: [6, 12], eq: [['band']],
    muscles: 'Pettorali, tricipiti, spalle, core',
    cues: ['Elastico dietro la schiena, estremità sotto le mani', 'Corpo rigido, petto quasi a terra', 'Spingi contro la resistenza fino a braccia tese'],
    errors: ['Bacino che cede'],
  },
  trx_row_high: {
    name: 'Rematore inclinato con le cinghie', anim: 'trx_row_high', cat: 'tirata', type: 'reps', range: [10, 20], eq: [['trx']],
    muscles: 'Dorsali, romboidi, bicipiti',
    cues: ['Corpo quasi in piedi, leggermente inclinato indietro', 'Tira il petto verso le mani, gomiti vicino al busto', 'Torna lentamente a braccia tese'],
    errors: ['Bacino che cede', 'Spalle alle orecchie'],
  },
  trx_row: {
    name: 'Rematore con le cinghie', anim: 'trx_row', cat: 'tirata', type: 'reps', range: [8, 15], eq: [['trx']],
    muscles: 'Dorsali, romboidi, bicipiti',
    cues: ['Piedi più avanti: corpo più inclinato, più difficile', 'Corpo dritto come in un plank', 'Chiudi le scapole in alto'],
    errors: ['Piegare il bacino per salire'],
  },
  band_pulldown: {
    name: 'Lat machine con elastico', anim: 'band_pulldown', cat: 'tirata', type: 'reps', range: [12, 20], eq: [['band']],
    muscles: 'Dorsali, romboidi, bicipiti',
    cues: ['Elastico fissato in alto (sopra la porta), in ginocchio davanti', 'Tira i gomiti verso i fianchi', 'Petto alto, risali lentamente'],
    errors: ['Tirare con il busto all’indietro'],
  },
  scap_pull: {
    pace: 3, name: 'Scapole alla sbarra', anim: 'scap_pull', cat: 'tirata', type: 'reps', range: [6, 12], eq: [['sbarra']],
    muscles: 'Dorsali, trapezio medio e basso',
    cues: ['Appesa a braccia tese', 'Abbassa le spalle lontano dalle orecchie senza piegare i gomiti', 'Torna giù controllando'],
    errors: ['Piegare le braccia'],
  },
  neg_pullup: {
    pace: 5, name: 'Trazione negativa', anim: 'neg_pullup', cat: 'tirata', type: 'reps', range: [3, 8], eq: [['sbarra']],
    muscles: 'Dorsali, bicipiti, romboidi',
    cues: ['Sali con un salto o da una sedia con il mento sopra la sbarra', 'Scendi lentamente in 3–5 secondi', 'Fino a braccia tese'],
    errors: ['Lasciarsi cadere nella parte finale'],
  },
  band_pullup: {
    pace: 3.5, name: 'Trazione assistita con elastico', anim: 'band_pullup', cat: 'tirata', type: 'reps', range: [5, 10], eq: [['sbarra'], ['band']],
    muscles: 'Dorsali, bicipiti, romboidi',
    cues: ['Elastico agganciato alla sbarra, un ginocchio o un piede dentro', 'Tira il petto verso la sbarra', 'Scendi fino a braccia tese'],
    errors: ['Mezze ripetizioni'],
  },
  pullup: {
    pace: 3.5, name: 'Trazione alla sbarra', anim: 'pullup', cat: 'tirata', type: 'reps', range: [3, 10], eq: [['sbarra']],
    muscles: 'Dorsali, bicipiti, romboidi',
    cues: ['Presa poco più larga delle spalle (o palmi verso di te, più facile)', 'Parti da braccia tese, mento sopra la sbarra', 'Scendi controllando'],
    errors: ['Slancio con le gambe'],
  },
  hang_knee: {
    pace: 3, name: 'Ginocchia al petto alla sbarra', anim: 'hang_knee', cat: 'core', type: 'reps', range: [6, 15], eq: [['sbarra']],
    muscles: 'Addominali, flessori dell’anca',
    cues: ['Appesa, spalle attive', 'Porta le ginocchia al petto arrotondando il bacino', 'Scendi senza dondolare'],
    errors: ['Dondolare'],
  },
  ball_rollout: {
    pace: 4, name: 'Rollout con fitball', anim: 'ball_rollout', cat: 'core', type: 'reps', range: [6, 12], eq: [['fitball']],
    muscles: 'Addominali, core',
    cues: ['In ginocchio, avambracci sulla palla', 'Fai rotolare la palla in avanti allungando il corpo', 'Costole basse, schiena neutra; torna indietro'],
    errors: ['Schiena che si inarca'],
  },
  pallof: {
    pace: 4, name: 'Pallof press', anim: 'pallof', cat: 'core', type: 'reps', uni: true, range: [8, 12], eq: [['band']],
    muscles: 'Obliqui, core',
    cues: ['Elastico fissato di lato all’altezza del petto', 'Spingi le mani avanti e resisti alla rotazione', '2 secondi a braccia tese, poi torna'],
    errors: ['Ruotare il busto verso l’elastico'],
  },

  // ---------------- RISCALDAMENTO E DEFATICAMENTO ----------------
  march: { name: 'Marcia sul posto', anim: 'march', cat: 'mobilita', type: 'time', range: [30, 60], muscles: 'Riscaldamento generale', cues: ['Ginocchia alte, braccia che accompagnano', 'Ritmo vivace'], errors: [] },
  step_jack: { name: 'Step jack', anim: 'step_jack', cat: 'cardio', type: 'time', range: [20, 45], muscles: 'Riscaldamento generale', cues: ['Un passo di lato e braccia in alto, alternando', 'Senza salti: adatto anche in condominio'], errors: [] },
  cat_camel: { name: 'Gatto-cammello', anim: 'cat_camel', cat: 'mobilita', type: 'time', range: [30, 45], muscles: 'Mobilità della colonna', cues: ['In quadrupedia, arrotonda e poi distendi la schiena', 'Movimento lento con il respiro'], errors: [] },
  arm_circles: { name: 'Circonduzioni delle braccia', anim: 'arm_circles', cat: 'mobilita', type: 'time', range: [20, 40], muscles: 'Mobilità delle spalle', cues: ['Cerchi ampi e lenti', 'Cambia verso a metà'], errors: [] },
  hip_flexor: { name: 'Allungamento flessori dell’anca', anim: 'hip_flexor', cat: 'mobilita', type: 'time', uni: true, range: [30, 45], muscles: 'Flessori dell’anca', cues: ['In ginocchio su un cuscino, un piede avanti', 'Stringi il gluteo dietro e porta il bacino avanti', 'Braccio dello stesso lato in alto'], errors: ['Inarcare la schiena'] },
  knee_hug: { name: 'Ginocchio al petto', anim: 'knee_hug', cat: 'mobilita', type: 'time', uni: true, range: [30, 45], muscles: 'Glutei, zona lombare', cues: ['Supino, abbraccia un ginocchio verso il petto', 'Respira lentamente'], errors: [] },
  child_pose: { name: 'Posizione del bambino', anim: 'child_pose', cat: 'mobilita', type: 'time', range: [30, 60], muscles: 'Schiena, glutei', cues: ['Siediti sui talloni e allunga le braccia avanti', 'Fronte a terra, respira con la pancia'], errors: [] },
  breathing: { name: 'Respirazione lenta', anim: 'breathing', cat: 'mobilita', type: 'time', range: [40, 60], muscles: 'Recupero', cues: ['Inspira dal naso in 4 secondi', 'Espira in 6 secondi'], errors: [] },

  // ---------------- FINISHER ----------------
  fast_squat: { name: 'Squat veloci', anim: 'squat_fast', cat: 'cardio', type: 'time', range: [20, 30], muscles: 'Gambe, sistema cardiovascolare', cues: ['Ritmo sostenuto, profondità comoda'], errors: [] },
  mountain: { name: 'Mountain climber', anim: 'mountain', cat: 'cardio', type: 'time', range: [20, 30], muscles: 'Core, sistema cardiovascolare', cues: ['Plank a braccia tese, porta le ginocchia al petto alternando', 'Bacino basso'], errors: [] },
  squat_jump: { name: 'Squat jump', anim: 'squat_jump', cat: 'cardio', type: 'time', range: [15, 30], jump: true, muscles: 'Gambe, potenza', cues: ['Atterra morbido sugli avampiedi e scendi subito nello squat', 'Ginocchia in linea con le punte'], errors: ['Atterrare rigido'] },
  jumping_jack: { name: 'Jumping jack', anim: 'jumping_jack', cat: 'cardio', type: 'time', range: [20, 40], jump: true, muscles: 'Sistema cardiovascolare', cues: ['Salti leggeri sugli avampiedi'], errors: [] },
  swing_time: { name: 'Kettlebell swing', anim: 'swing', cat: 'cardio', type: 'time', range: [15, 30], eq: [['kb']], muscles: 'Glutei, femorali, cardio', cues: ['Spinta d’anca esplosiva', 'Pausa quando la tecnica cala'], errors: [] },
};

export function hasEquipment(exId, eq) {
  const ex = EX[exId];
  if (!ex || !ex.eq) return true;
  return ex.eq.every((group) => group.some((k) => eq[k]));
}
