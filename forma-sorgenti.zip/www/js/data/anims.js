// Forma — pose chiave delle animazioni degli esercizi.
// Ogni animazione: { view, root, kf:[pose], t:[durate], h:[pause], props, focus }.
// Coordinate in unità ~cm: pavimento y = 0, valori negativi verso l'alto, la figura guarda a destra (+x).
import { P } from '../figure.js';

const HANG = { R: { a: 181, r: 0.97 }, L: { a: 178, r: 0.97 } };
const HIPS_HANDS = { R: { rel: 172, r: 0.8 }, L: { rel: 168, r: 0.8 } };
const CHEST_HOLD = { R: { a: 120, r: 0.42, w: 0.32 }, L: { a: 116, r: 0.42, w: 0.32 } };
const CROSSED = { R: { rel: 150, r: 0.32, w: 0.25 }, L: { rel: 146, r: 0.3, w: 0.25 } };
const BEHIND_HEAD = { R: { rel: -12, r: 0.36, w: 0.3, eo: 2.6 }, L: { rel: -8, r: 0.36, w: 0.3, eo: 2.6 } };
const FEET2 = { R: { p: [4, -6] }, L: { p: [0, -6] } };

const STAND = { hip: [0, -94], trunk: 0, legs: FEET2, arms: HANG };

// ---------- squat ----------
const SQ_TOP = P(STAND, { arms: { R: { a: 178, r: 0.97 }, L: { a: 176, r: 0.97 } } });
const SQ_BOT = { hip: [-30, -42], trunk: 42, legs: FEET2, arms: { R: { a: 88, r: 0.95 }, L: { a: 84, r: 0.95 } } };
const SQ_HALF = { hip: [-14, -70], trunk: 25, legs: FEET2, arms: { R: { a: 100, r: 0.95 }, L: { a: 96, r: 0.95 } } };
const SQ_FOCUS = ['glute', 'thighR', 'thighL'];

const GOB_TOP = { hip: [0, -94], trunk: 0, legs: FEET2, arms: CHEST_HOLD };
const GOB_BOT = { hip: [-28, -42], trunk: 34, legs: FEET2, arms: CHEST_HOLD };
const GOB_HALF = { hip: [-13, -70], trunk: 20, legs: FEET2, arms: CHEST_HOLD };

// ---------- split squat / affondi ----------
const SPLIT_LEGS = { R: { p: [24, -6] }, L: { p: [-44, -15.5] } };
const SPLIT_FEET = { L: 135 };
const SPLIT_TOP = { hip: [-6, -88], trunk: 3, legs: SPLIT_LEGS, feet: SPLIT_FEET, arms: HIPS_HANDS };
const SPLIT_BOT = { hip: [-6, -50], trunk: 6, legs: SPLIT_LEGS, feet: SPLIT_FEET, arms: HIPS_HANDS };

const ASSIST_LEGS = { R: { p: [14, -6] }, L: { p: [-54, -15.5] } };
const ASSIST_ARMS = { R: { p: [36, -104] }, L: { a: 178, r: 0.97 } };

const LUNGE_STAND = { hip: [0, -94], trunk: 0, legs: { R: { p: [4, -6] }, L: { p: [0, -6] } }, arms: HIPS_HANDS };
const LUNGE_L = { hip: [-20, -48], trunk: 8, legs: { R: { p: [4, -6] }, L: { p: [-66, -15.5] } }, feet: { L: 135 }, arms: HIPS_HANDS };
const LUNGE_R = { hip: [-24, -48], trunk: 8, legs: { R: { p: [-70, -15.5] }, L: { p: [0, -6] } }, feet: { R: 135 }, arms: HIPS_HANDS };

const DEF_LEGS = { R: { p: [24, -16] }, L: { p: [-44, -15.5] } };

const BSS_LEGS = { R: { p: [22, -6] }, L: { p: [-52, -52] } };
const BSS_FEET = { L: -95 };
const BSS_SOLE = { L: -1 };
const BSS_TOP = { hip: [-6, -88], trunk: 5, legs: BSS_LEGS, feet: BSS_FEET, sole: BSS_SOLE, arms: HIPS_HANDS };
const BSS_BOT = { hip: [-12, -48], trunk: 22, legs: BSS_LEGS, feet: BSS_FEET, sole: BSS_SOLE, arms: HIPS_HANDS };
const BSS_HALF = { hip: [-9, -66], trunk: 14, legs: BSS_LEGS, feet: BSS_FEET, sole: BSS_SOLE, arms: HIPS_HANDS };
const BENCH_BSS = { t: 'box', x: -92, y: -46, w: 46 };

// ---------- step-up ----------
const STEP_LOW = [
  { hip: [-8, -88], trunk: 12, legs: { R: { p: [20, -28] }, L: { p: [-14, -6] } }, arms: HANG },
  { hip: [6, -104], trunk: 8, legs: { R: { p: [20, -28] }, L: { p: [-6, -20] } }, arms: HANG },
  { hip: [18, -114], trunk: 3, legs: { R: { p: [20, -28] }, L: { p: [10, -50] } }, arms: HANG },
  { hip: [6, -104], trunk: 8, legs: { R: { p: [20, -28] }, L: { p: [-6, -20] } }, arms: HANG },
];
const STEP_HIGH = [
  { hip: [-12, -84], trunk: 18, legs: { R: { p: [20, -46] }, L: { p: [-14, -6] } }, arms: HANG },
  { hip: [6, -112], trunk: 12, legs: { R: { p: [20, -46] }, L: { p: [-8, -24] } }, arms: HANG },
  { hip: [18, -132], trunk: 3, legs: { R: { p: [20, -46] }, L: { p: [10, -66] } }, arms: HANG },
  { hip: [6, -112], trunk: 12, legs: { R: { p: [20, -46] }, L: { p: [-8, -24] } }, arms: HANG },
];

// ---------- ponte / hip thrust (radice al collo: spalle ferme) ----------
const BR_LEGS = { R: { p: [56, -6] }, L: { p: [52, -6] } };
const BR_ARMS = { R: { p: [27, -7] }, L: { p: [25, -7] } };
const BR_BEND = { eR: -1, eL: -1 };
const BR_BOT = { neck: [-30, -9], trunk: -90, headA: -90, legs: BR_LEGS, arms: BR_ARMS, bend: BR_BEND };
const BR_TOP = { neck: [-30, -9], trunk: -115, headA: -90, legs: BR_LEGS, arms: BR_ARMS, bend: BR_BEND };

const HT_LEGS = { R: { p: [60, -6] }, L: { p: [56, -6] } };
const HT_ARMS = { R: { p: [-88, -46] }, L: { p: [-84, -46] } };
const HT_BOT = { neck: [-36, -48], trunk: -45, head: 12, legs: HT_LEGS, arms: HT_ARMS };
const HT_TOP = { neck: [-36, -48], trunk: -90, head: 42, legs: HT_LEGS, arms: HT_ARMS };
const SOFA = { t: 'box', x: -96, y: -42, w: 56 };

// ---------- hinge ----------
const HINGE_TOP = { hip: [0, -93], trunk: 0, legs: FEET2 };
const HINGE_BOT = { hip: [-24, -86], trunk: 66, legs: FEET2 };
const SLRDL_TOP = { hip: [0, -93], trunk: 0, legs: { R: { p: [4, -6] }, L: { a: 184, r: 0.98 } }, arms: HANG };
const SLRDL_BOT = { hip: [-18, -87], trunk: 78, legs: { R: { p: [4, -6] }, L: { a: -100, r: 0.98 } }, arms: HANG };

// ---------- leg curl (radice al collo) ----------
const CURL_LEGS_EXT = { R: { p: [100, -4] }, L: { p: [96, -4] } };
const CURL_LEGS_FLEX = { R: { p: [52, -4] }, L: { p: [48, -4] } };
const CURL_EXT = { neck: [-30, -9], trunk: -110, headA: -90, legs: CURL_LEGS_EXT, feet: { R: 0, L: 0 }, arms: BR_ARMS, bend: BR_BEND };
const CURL_FLEX = { neck: [-30, -9], trunk: -118, headA: -90, legs: CURL_LEGS_FLEX, feet: { R: 0, L: 0 }, arms: BR_ARMS, bend: BR_BEND };

// ---------- su un fianco ----------
const SIDE_LYING = {
  hip: [0, -12], trunk: -90, headA: -96,
  legs: { R: { a: 90, r: 0.99 }, L: { a: 92, r: 0.98 } },
  feet: { R: 180, L: 180 }, footScale: 0.5,
  arms: { R: { a: 93, r: 0.99 }, L: { a: -90, r: 0.95 } },
  bend: { eR: -1 },
};

const CLAM = {
  hip: [0, -12], trunk: -90, headA: -96,
  legs: { R: { p: [28, -14], dz: 20, kz: 30 }, L: { p: [28, -10], dz: 20, kz: 30 } },
  feet: { R: 180, L: 180 }, footScale: 0.5,
  arms: { R: { a: 150, r: 0.6 }, L: { a: -90, r: 0.95 } },
  bend: { eR: -1, kR: 1, kL: 1 },
};

// ---------- plank laterale (vista frontale del corpo su un fianco) ----------
const SPLANK = {
  hip: [0, -24], trunk: -78, head: 0,
  legs: { R: { a: 101.8, r: 0.99 }, L: { p: [84, -5] } },
  feet: { R: 90, L: 90 }, footScale: 0.45,
  arms: { R: { a: 105, r: 0.85 }, L: { p: [-76, -4] } },
  bend: { eL: -1, eR: -1 },
};
const SPLANK_KNEE = {
  hip: [0, -20], trunk: -73, head: 0,
  legs: { R: { p: [40, -8], dz: -40 }, L: { p: [38, -6], dz: -40 } },
  scale: { shankR: 0.12, shankL: 0.12 }, footScale: 0.01,
  arms: { R: { a: 105, r: 0.85 }, L: { p: [-74, -4] } },
  bend: { eL: -1, eR: -1 },
};

// ---------- piegamenti ----------
const PU_ARMS = { R: { p: [64, -4] }, L: { p: [62, -4] } };
const PU_LEGS = { R: { p: [-68, -16] }, L: { p: [-70, -16] } };
const PU_FEET = { R: 180, L: 180 };
const PU_TOP = { hip: [14.9, -44.9], trunk: 70.8, legs: PU_LEGS, feet: PU_FEET, arms: PU_ARMS };
const PU_BOT = { hip: [19.7, -19.8], trunk: 87.6, legs: PU_LEGS, feet: PU_FEET, arms: PU_ARMS };

const TOES = { R: 150, L: 150 };

// ---------- quadrupedia ----------
const QUAD = {
  hip: [0, -52], trunk: 86,
  legs: { R: { a: -136.3, r: 0.724 }, L: { a: -134, r: 0.71 } },
  feet: { R: -90, L: -90 }, sole: { R: -1, L: -1 },
  arms: { R: { a: 175.6, r: 0.93 }, L: { a: 177, r: 0.93 } },
};

// ---------- supino ----------
const SUPINE_TABLE = {
  hip: [0, -10], trunk: -90, headA: -90,
  legs: { R: { p: [44, -54] }, L: { p: [40, -52] } },
  feet: { R: 0, L: 0 },
  arms: { R: { a: 0, r: 0.97 }, L: { a: 4, r: 0.97 } },
};

// ---------- prono ----------
const PRONE = {
  hip: [0, -10], trunk: 90, headA: 82,
  legs: { R: { a: -90, r: 0.99 }, L: { a: -90, r: 0.99 } },
  feet: { R: 180, L: 180 }, footScale: 0.6,
};

// ---------- attrezzi: sbarra, TRX, fitball ----------
const BAR = { t: 'bar', x: 12, y: -224 };
const HANG_BAR = { root: 'neck', neck: [4, -168], trunk: 0, head: 0, legs: { R: { a: 168, r: 0.86 }, L: { a: 172, r: 0.88 } }, feet: { R: 140, L: 140 }, arms: { R: { p: [12, -224], w: 1.25 }, L: { p: [10, -224], w: 1.25 } }, bend: { kR: 1, kL: 1 } };
const TOP_BAR = { ...HANG_BAR, neck: [8, -214], trunk: -6, head: 4 };
const TRX_A = [150, -228];
const ROW_LEGS = { R: { p: [34, -6] }, L: { p: [30, -6] } };

// ---------- vista frontale ----------
const FRONT_STAND = {
  hip: [0, -94], trunk: 0,
  legs: { R: { p: [10, -6] }, L: { p: [-10, -6] } },
  arms: { R: { a: 172, r: 0.97 }, L: { a: 188, r: 0.97 } },
};

export const ANIMS = {
  squat: { kf: [SQ_TOP, SQ_BOT], t: [1.5, 1.1], h: [0.5, 0.3], focus: SQ_FOCUS },
  squat_tempo: { kf: [SQ_TOP, SQ_BOT], t: [3, 1], h: [0.5, 1], focus: SQ_FOCUS },
  squat_fast: { kf: [SQ_TOP, SQ_BOT], t: [0.6, 0.5], h: [0.1, 0.05], focus: SQ_FOCUS },
  squat15: {
    kf: [SQ_TOP, SQ_BOT, SQ_HALF, SQ_BOT],
    t: [1.4, 0.8, 0.8, 1.1], h: [0.2, 0.2, 0.1, 0.4], focus: SQ_FOCUS,
  },
  box_squat: {
    kf: [SQ_TOP, P(SQ_BOT, { hip: [-36, -52], trunk: 34 })],
    t: [1.6, 1.2], h: [0.5, 0.5], focus: SQ_FOCUS,
    props: [{ t: 'box', x: -64, y: -44, w: 40 }],
  },
  goblet: {
    kf: [GOB_TOP, GOB_BOT], t: [1.6, 1.1], h: [0.5, 0.4], focus: SQ_FOCUS,
    props: [{ t: 'kb', at: 'wrists', dy: 2 }],
  },
  goblet_pause: {
    kf: [GOB_TOP, GOB_BOT], t: [2.5, 1.1], h: [0.5, 1.8], focus: SQ_FOCUS,
    props: [{ t: 'kb', at: 'wrists', dy: 2 }],
  },
  split_assist: {
    kf: [
      { hip: [-16, -88], trunk: 4, legs: ASSIST_LEGS, feet: SPLIT_FEET, arms: ASSIST_ARMS },
      { hip: [-16, -50], trunk: 8, legs: ASSIST_LEGS, feet: SPLIT_FEET, arms: ASSIST_ARMS },
    ],
    t: [1.6, 1.2], h: [0.5, 0.3], focus: ['glute', 'thighR'],
    props: [{ t: 'chair', x: 34, y: -46, w: 36, top: -104, back: 'left' }],
  },
  split: { kf: [SPLIT_TOP, SPLIT_BOT], t: [1.6, 1.2], h: [0.5, 0.3], focus: ['glute', 'thighR'] },
  split_tempo: { kf: [SPLIT_TOP, SPLIT_BOT], t: [3, 1.1], h: [0.5, 1], focus: ['glute', 'thighR'] },
  rev_lunge: {
    kf: [LUNGE_STAND, LUNGE_L, LUNGE_STAND, LUNGE_R],
    t: [1.1, 1.0, 1.1, 1.0], h: [0.3, 0.3, 0.3, 0.3], focus: ['glute', 'thighR', 'thighL'],
  },
  split_deficit: {
    kf: [
      { hip: [-6, -92], trunk: 4, legs: DEF_LEGS, feet: SPLIT_FEET, arms: HIPS_HANDS },
      { hip: [-6, -47], trunk: 10, legs: DEF_LEGS, feet: SPLIT_FEET, arms: HIPS_HANDS },
    ],
    t: [1.8, 1.2], h: [0.5, 0.4], focus: ['glute', 'thighR'],
    props: [{ t: 'box', x: 12, y: -10, w: 40 }],
  },
  bss: { kf: [BSS_TOP, BSS_BOT], t: [1.7, 1.2], h: [0.5, 0.3], focus: ['glute', 'thighR'], props: [BENCH_BSS] },
  bss_tempo: { kf: [BSS_TOP, BSS_BOT], t: [3, 1.1], h: [0.5, 1], focus: ['glute', 'thighR'], props: [BENCH_BSS] },
  bss_kb: {
    kf: [P(BSS_TOP, { arms: CHEST_HOLD }), P(BSS_BOT, { arms: CHEST_HOLD })],
    t: [1.8, 1.2], h: [0.5, 0.3], focus: ['glute', 'thighR'],
    props: [BENCH_BSS, { t: 'kb', at: 'wrists', dy: 2 }],
  },
  bss15_kb: {
    kf: [P(BSS_TOP, { arms: CHEST_HOLD }), P(BSS_BOT, { arms: CHEST_HOLD }), P(BSS_HALF, { arms: CHEST_HOLD }), P(BSS_BOT, { arms: CHEST_HOLD })],
    t: [1.5, 0.8, 0.8, 1.2], h: [0.2, 0.2, 0.1, 0.4], focus: ['glute', 'thighR'],
    props: [BENCH_BSS, { t: 'kb', at: 'wrists', dy: 2 }],
  },
  stepup: { kf: STEP_LOW, t: [0.7, 0.6, 0.8, 0.7], h: [0.4, 0, 0.4, 0], focus: ['glute', 'thighR'], props: [{ t: 'box', x: 6, y: -22, w: 44 }] },
  stepup_high: { kf: STEP_HIGH, t: [0.8, 0.7, 0.9, 0.8], h: [0.4, 0, 0.4, 0], focus: ['glute', 'thighR'], props: [{ t: 'box', x: 6, y: -40, w: 44 }] },
  stepup_kb: {
    kf: STEP_HIGH.map((k) => P(k, { arms: CHEST_HOLD })),
    t: [0.8, 0.7, 0.9, 0.8], h: [0.4, 0, 0.4, 0], focus: ['glute', 'thighR'],
    props: [{ t: 'box', x: 6, y: -40, w: 44 }, { t: 'kb', at: 'wrists', dy: 2 }],
  },
  wallsit: {
    kf: [{ hip: [-30, -50], trunk: 0, legs: { R: { p: [16, -6] }, L: { p: [12, -6] } }, arms: CROSSED }],
    focus: ['thighR', 'thighL'], props: [{ t: 'wall', x: -42 }],
  },

  bridge: { root: 'neck', kf: [BR_BOT, BR_TOP], t: [1.0, 1.4], h: [0.3, 1.0], focus: ['glute'], props: [{ t: 'mat', x: -60, w: 140 }] },
  bridge_pause: { root: 'neck', kf: [BR_BOT, BR_TOP], t: [1.0, 1.6], h: [0.3, 2.0], focus: ['glute'], props: [{ t: 'mat', x: -60, w: 140 }] },
  frogpump: {
    root: 'neck',
    kf: [P(BR_BOT, { legs: { R: { p: [44, -6] }, L: { p: [42, -6] } } }), P(BR_TOP, { trunk: -110, legs: { R: { p: [44, -6] }, L: { p: [42, -6] } } })],
    t: [0.6, 0.8], h: [0.1, 0.6], focus: ['glute'], props: [{ t: 'mat', x: -60, w: 140 }],
  },
  sl_bridge: {
    root: 'neck',
    kf: [P(BR_BOT, { legs: { R: { p: [56, -6] }, L: { a: 72, r: 0.98 } } }), P(BR_TOP, { legs: { R: { p: [56, -6] }, L: { a: 64, r: 0.98 } } })],
    t: [1.0, 1.4], h: [0.3, 1.0], focus: ['glute'], props: [{ t: 'mat', x: -60, w: 140 }],
  },
  hipthrust: { root: 'neck', kf: [HT_BOT, HT_TOP], t: [1.1, 1.4], h: [0.3, 1.0], focus: ['glute'], props: [SOFA] },
  sl_hipthrust: {
    root: 'neck',
    kf: [P(HT_BOT, { legs: { R: { p: [60, -6] }, L: { a: 80, r: 0.98 } } }), P(HT_TOP, { legs: { R: { p: [60, -6] }, L: { a: 88, r: 0.98 } } })],
    t: [1.1, 1.4], h: [0.3, 1.0], focus: ['glute'], props: [SOFA],
  },
  hipthrust_kb: {
    root: 'neck',
    kf: [P(HT_BOT, { arms: { R: { a: 134, r: 0.86 }, L: { a: 132, r: 0.86 } } }), P(HT_TOP, { arms: { R: { a: 92, r: 0.86 }, L: { a: 90, r: 0.86 } } })],
    t: [1.1, 1.4], h: [0.3, 1.2], focus: ['glute'], props: [SOFA, { t: 'kb', at: 'hip', dy: -16 }],
  },

  hinge_wall: {
    kf: [P(HINGE_TOP, { arms: CROSSED }), P(HINGE_BOT, { hip: [-26, -86], trunk: 62, arms: CROSSED })],
    t: [1.8, 1.2], h: [0.4, 0.4], focus: ['glute', 'thighR', 'thighL'], props: [{ t: 'wall', x: -35 }],
  },
  goodmorning: {
    kf: [P(HINGE_TOP, { arms: BEHIND_HEAD }), P(HINGE_BOT, { arms: BEHIND_HEAD })],
    t: [2.2, 1.3], h: [0.4, 0.5], focus: ['glute', 'thighR', 'thighL'],
  },
  rdl_kb: {
    kf: [P(HINGE_TOP, { arms: HANG }), P(HINGE_BOT, { hip: [-26, -86], trunk: 74, arms: HANG })],
    t: [2.2, 1.3], h: [0.4, 0.5], focus: ['glute', 'thighR', 'thighL'], props: [{ t: 'kb', at: 'wrists', dy: 2 }],
  },
  slrdl: { kf: [SLRDL_TOP, SLRDL_BOT], t: [2.0, 1.4], h: [0.4, 0.5], focus: ['glute', 'thighR'] },
  slrdl_assist: {
    kf: [P(SLRDL_TOP, { arms: { R: { p: [52, -110] }, L: { a: 180, r: 0.97 } } }), P(SLRDL_BOT, { arms: { R: { p: [52, -110] }, L: { a: 180, r: 0.97 } } })],
    t: [2.0, 1.4], h: [0.4, 0.5], focus: ['glute', 'thighR'], props: [{ t: 'wall', x: 56 }],
  },
  slrdl_kb: { kf: [SLRDL_TOP, SLRDL_BOT], t: [2.0, 1.4], h: [0.4, 0.5], focus: ['glute', 'thighR'], props: [{ t: 'kb', at: 'wrists', dy: 2 }] },
  swing: {
    kf: [
      { hip: [-26, -84], trunk: 68, legs: { R: { p: [8, -6] }, L: { p: [-2, -6] } }, arms: { R: { a: 212, r: 0.97 }, L: { a: 210, r: 0.97 } } },
      { hip: [-12, -90], trunk: 30, legs: { R: { p: [8, -6] }, L: { p: [-2, -6] } }, arms: { R: { a: 160, r: 0.97 }, L: { a: 158, r: 0.97 } } },
      { hip: [0, -94], trunk: -3, legs: { R: { p: [8, -6] }, L: { p: [-2, -6] } }, arms: { R: { a: 92, r: 0.97 }, L: { a: 90, r: 0.97 } } },
      { hip: [-12, -90], trunk: 30, legs: { R: { p: [8, -6] }, L: { p: [-2, -6] } }, arms: { R: { a: 160, r: 0.97 }, L: { a: 158, r: 0.97 } } },
    ],
    t: [0.35, 0.3, 0.35, 0.35], h: [0.05, 0, 0.12, 0], focus: ['glute', 'thighR', 'thighL'],
    props: [{ t: 'kb', at: 'wrists', dy: 2 }],
  },

  curl: {
    root: 'neck', kf: [CURL_EXT, CURL_FLEX], t: [1.2, 1.4], h: [0.4, 0.4], focus: ['thighR', 'thighL', 'glute'],
    props: [{ t: 'towel', at: 'heelR' }],
  },
  curl_ecc: {
    root: 'neck', kf: [CURL_FLEX, CURL_EXT], t: [3.2, 0.9], h: [0.3, 0.6], focus: ['thighR', 'thighL', 'glute'],
    props: [{ t: 'towel', at: 'heelR' }],
  },
  walkout: {
    root: 'neck', kf: [CURL_FLEX, P(CURL_EXT, { trunk: -112 })], t: [2.4, 2.4], h: [0.3, 0.3], focus: ['thighR', 'thighL', 'glute'],
  },
  sl_curl: {
    root: 'neck',
    kf: [P(CURL_EXT, { legs: { R: { p: [100, -4] }, L: { a: 40, r: 0.98 } } }), P(CURL_FLEX, { legs: { R: { p: [52, -4] }, L: { a: 40, r: 0.98 } } })],
    t: [1.3, 1.5], h: [0.4, 0.4], focus: ['thighR', 'glute'], props: [{ t: 'towel', at: 'heelR' }],
  },

  sideabd: {
    plane: 'lie',
    kf: [SIDE_LYING, P(SIDE_LYING, { legs: { R: { a: 58, r: 0.99 } }, feet: { R: 148 } })],
    t: [1.2, 1.4], h: [0.3, 0.6], focus: ['glute'], props: [{ t: 'mat', x: -110, w: 220 }],
  },
  sideabd_pause: {
    plane: 'lie',
    kf: [SIDE_LYING, P(SIDE_LYING, { legs: { R: { a: 58, r: 0.99 } }, feet: { R: 148 } })],
    t: [1.2, 2.0], h: [0.3, 2.0], focus: ['glute'], props: [{ t: 'mat', x: -110, w: 220 }],
  },
  sideabd_band: {
    plane: 'lie',
    kf: [SIDE_LYING, P(SIDE_LYING, { legs: { R: { a: 62, r: 0.99 } }, feet: { R: 152 } })],
    t: [1.2, 1.4], h: [0.3, 0.6], focus: ['glute'], props: [{ t: 'mat', x: -110, w: 220 }, { t: 'miniband', at: 'knees' }],
  },
  latwalk: {
    view: 'front',
    kf: [
      { hip: [0, -84], trunk: 0, legs: { R: { p: [13, -6] }, L: { p: [-13, -6] } }, arms: { R: { a: 165, r: 0.55 }, L: { a: 195, r: 0.55 } } },
      { hip: [10, -84], trunk: 0, legs: { R: { p: [33, -6] }, L: { p: [-13, -6] } }, arms: { R: { a: 165, r: 0.55 }, L: { a: 195, r: 0.55 } } },
      { hip: [20, -84], trunk: 0, legs: { R: { p: [33, -6] }, L: { p: [7, -6] } }, arms: { R: { a: 165, r: 0.55 }, L: { a: 195, r: 0.55 } } },
      { hip: [10, -84], trunk: 0, legs: { R: { p: [33, -6] }, L: { p: [-13, -6] } }, arms: { R: { a: 165, r: 0.55 }, L: { a: 195, r: 0.55 } } },
    ],
    t: [0.6, 0.6, 0.6, 0.6], h: [0.15, 0.15, 0.15, 0.15], focus: ['glute'],
    props: [{ t: 'miniband', at: 'ankles' }],
  },
  sideplank: { plane: 'lie', kf: [SPLANK], focus: ['trunk'], props: [{ t: 'mat', x: -90, w: 190 }] },
  sideplank_knee: { plane: 'lie', kf: [SPLANK_KNEE], focus: ['trunk'], props: [{ t: 'mat', x: -90, w: 150 }] },
  sideplank_abd: {
    plane: 'lie',
    kf: [SPLANK, P(SPLANK, { legs: { R: { a: 72, r: 0.99 } } })],
    t: [1.1, 1.3], h: [0.3, 0.6], focus: ['glute', 'trunk'], props: [{ t: 'mat', x: -90, w: 190 }],
  },

  calf: {
    kf: [
      P(STAND, { legs: { R: { p: [0, -6] }, L: { p: [-2, -6] } } }),
      P(STAND, { hip: [7, -103], legs: { R: { p: [7.6, -14.9] }, L: { p: [5.6, -14.9] } }, feet: { R: 130, L: 130 } }),
    ],
    t: [1.0, 1.4], h: [0.4, 0.8], focus: ['shankR', 'shankL'],
  },
  sl_calf: {
    kf: [
      P(STAND, { legs: { R: { p: [0, -6] }, L: { a: 200, r: 0.7 } } }),
      P(STAND, { hip: [7, -103], legs: { R: { p: [7.6, -14.9] }, L: { a: 200, r: 0.7 } }, feet: { R: 130 } }),
    ],
    t: [1.0, 1.4], h: [0.4, 0.8], focus: ['shankR'],
  },

  pu_wall: {
    kf: [
      { hip: [-17.2, -101], trunk: 15, legs: { R: { p: [-40, -16] }, L: { p: [-42, -16] } }, feet: TOES, arms: { R: { p: [52, -136] }, L: { p: [52, -132] } } },
      { hip: [5.3, -91.4], trunk: 31, legs: { R: { p: [-40, -16] }, L: { p: [-42, -16] } }, feet: TOES, arms: { R: { p: [52, -136] }, L: { p: [52, -132] } } },
    ],
    t: [1.4, 1.1], h: [0.4, 0.3], focus: ['upperR', 'upperL'], props: [{ t: 'wall', x: 56 }],
  },
  pu_counter: {
    kf: [
      { hip: [-9.5, -88.1], trunk: 35, legs: { R: { p: [-60, -16] }, L: { p: [-62, -16] } }, feet: TOES, arms: { R: { p: [68, -97] }, L: { p: [66, -97] } } },
      { hip: [7.4, -72.6], trunk: 50, legs: { R: { p: [-60, -16] }, L: { p: [-62, -16] } }, feet: TOES, arms: { R: { p: [68, -97] }, L: { p: [66, -97] } } },
    ],
    t: [1.4, 1.1], h: [0.4, 0.3], focus: ['upperR', 'upperL'], props: [{ t: 'table', x: 60, y: -93, w: 50 }],
  },
  pu_sofa: {
    kf: [
      { hip: [-7.9, -66.5], trunk: 55, legs: { R: { p: [-80, -16] }, L: { p: [-82, -16] } }, feet: TOES, arms: { R: { p: [68, -49] }, L: { p: [66, -49] } } },
      { hip: [2.7, -46.1], trunk: 70, legs: { R: { p: [-80, -16] }, L: { p: [-82, -16] } }, feet: TOES, arms: { R: { p: [68, -49] }, L: { p: [66, -49] } } },
    ],
    t: [1.4, 1.1], h: [0.4, 0.3], focus: ['upperR', 'upperL'], props: [{ t: 'box', x: 58, y: -45, w: 50 }],
  },
  pu_knee: {
    kf: [
      { hip: [21.75, -31.7], trunk: 54.4, legs: { R: { p: [-50, -26] }, L: { p: [-52, -26] } }, feet: { R: -57, L: -57 }, footScale: 0.8, arms: { R: { p: [70, -4] }, L: { p: [68, -4] } } },
      { hip: [29.4, -13.3], trunk: 80.4, legs: { R: { p: [-50, -26] }, L: { p: [-52, -26] } }, feet: { R: -57, L: -57 }, footScale: 0.8, arms: { R: { p: [70, -4] }, L: { p: [68, -4] } } },
    ],
    t: [1.4, 1.1], h: [0.4, 0.3], focus: ['upperR', 'upperL'], props: [{ t: 'mat', x: -60, w: 150 }],
  },
  pushup: { kf: [PU_TOP, PU_BOT], t: [1.4, 1.0], h: [0.4, 0.3], focus: ['upperR', 'upperL'] },
  pu_tempo: { kf: [PU_TOP, PU_BOT], t: [3, 1.0], h: [0.4, 1.0], focus: ['upperR', 'upperL'] },
  pu_decline: {
    kf: [
      { hip: [4, -60.5], trunk: 88.3, legs: { R: { p: [-84, -58] }, L: { p: [-86, -58] } }, feet: PU_FEET, arms: { R: { p: [62, -4] }, L: { p: [60, -4] } } },
      { hip: [1.4, -36.6], trunk: 104, legs: { R: { p: [-84, -58] }, L: { p: [-86, -58] } }, feet: PU_FEET, arms: { R: { p: [62, -4] }, L: { p: [60, -4] } } },
    ],
    t: [1.5, 1.1], h: [0.4, 0.3], focus: ['upperR', 'upperL'], props: [{ t: 'box', x: -118, y: -42, w: 44 }],
  },
  pike: {
    kf: [
      { hip: [-5, -95], trunk: 131.9, legs: { R: { p: [-44, -16] }, L: { p: [-46, -16] } }, feet: { R: 165, L: 165 }, arms: { R: { p: [40, -4] }, L: { p: [38, -4] } } },
      { hip: [14, -84], trunk: 160, legs: { R: { p: [-44, -16] }, L: { p: [-46, -16] } }, feet: { R: 165, L: 165 }, arms: { R: { p: [40, -4] }, L: { p: [38, -4] } } },
    ],
    t: [1.5, 1.1], h: [0.4, 0.3], focus: ['upperR', 'upperL'],
  },
  pike_feet_up: {
    kf: [
      { hip: [4, -108], trunk: 155, legs: { R: { p: [-60, -58] }, L: { p: [-62, -58] } }, feet: PU_FEET, arms: { R: { p: [32, -4] }, L: { p: [30, -4] } } },
      { hip: [10, -100], trunk: 172, legs: { R: { p: [-60, -58] }, L: { p: [-62, -58] } }, feet: PU_FEET, arms: { R: { p: [32, -4] }, L: { p: [30, -4] } } },
    ],
    t: [1.5, 1.1], h: [0.4, 0.3], focus: ['upperR', 'upperL'], props: [{ t: 'box', x: -92, y: -42, w: 40 }],
  },
  kb_press: {
    kf: [
      P(STAND, { arms: { R: { a: 80, r: 0.32 }, L: { a: 178, r: 0.97 } } }),
      P(STAND, { arms: { R: { a: 2, r: 0.97 }, L: { a: 178, r: 0.97 } } }),
    ],
    t: [1.1, 1.6], h: [0.5, 0.4], focus: ['upperR'], props: [{ t: 'kb', at: 'wristR', dy: -4 }],
  },

  prone_y: {
    kf: [P(PRONE, { arms: { R: { a: 94, r: 0.97 }, L: { a: 95, r: 0.97 } } }), P(PRONE, { trunk: 86, arms: { R: { a: 72, r: 0.97 }, L: { a: 73, r: 0.97 } } })],
    t: [1.0, 1.2], h: [0.4, 1.2], focus: ['upperR', 'upperL'], props: [{ t: 'mat', x: -100, w: 220 }],
  },
  bp_row: {
    kf: [
      { hip: [-24, -86], trunk: 70, legs: FEET2, arms: { R: { a: 180, r: 0.97 }, L: { a: 178, r: 0.97 } } },
      { hip: [-24, -86], trunk: 70, legs: FEET2, arms: { R: { a: 205, r: 0.5 }, L: { a: 203, r: 0.5 } } },
    ],
    t: [1.0, 1.6], h: [0.4, 0.6], focus: ['upperR', 'upperL'], props: [{ t: 'pack', at: 'wrists', dy: 2 }],
  },
  row1: {
    kf: [
      { hip: [-20, -84], trunk: 72, legs: { R: { p: [-6, -6] }, L: { p: [10, -6] } }, arms: { R: { a: 180, r: 0.97 }, L: { p: [50, -50] } } },
      { hip: [-20, -84], trunk: 72, legs: { R: { p: [-6, -6] }, L: { p: [10, -6] } }, arms: { R: { a: 205, r: 0.5 }, L: { p: [50, -50] } } },
    ],
    t: [1.0, 1.6], h: [0.4, 0.6], focus: ['upperR'], props: [{ t: 'chair', x: 40, y: -46, w: 40, top: -92, back: 'right' }, { t: 'kb', at: 'wristR', dy: 2 }],
  },
  band_row: {
    kf: [
      { hip: [0, -12], trunk: 0, legs: { R: { p: [86, -8] }, L: { p: [84, -8] } }, feet: { R: 0, L: 0 }, arms: { R: { a: 98, r: 0.95 }, L: { a: 100, r: 0.95 } } },
      { hip: [0, -12], trunk: -5, legs: { R: { p: [86, -8] }, L: { p: [84, -8] } }, feet: { R: 0, L: 0 }, arms: { R: { a: 150, r: 0.34 }, L: { a: 152, r: 0.34 } } },
    ],
    t: [1.0, 1.6], h: [0.3, 0.7], focus: ['upperR', 'upperL'],
    props: [{ t: 'band', from: 'wristR', to: 'toeR' }, { t: 'band', from: 'wristL', to: 'toeL' }],
  },
  pullapart: {
    view: 'front',
    kf: [
      P(FRONT_STAND, { arms: { R: { a: -121, r: 0.95 }, L: { a: 121, r: 0.95 } }, scale: { upperR: 0.3, foreR: 0.3, upperL: 0.3, foreL: 0.3 } }),
      P(FRONT_STAND, { arms: { R: { a: 90, r: 0.97 }, L: { a: -90, r: 0.97 } }, scale: { upperR: 1, foreR: 1, upperL: 1, foreL: 1 } }),
    ],
    t: [1.0, 1.4], h: [0.3, 0.7], focus: ['upperR', 'upperL'],
    props: [{ t: 'band', from: 'wristR', to: 'wristL' }],
  },

  deadbug_legs: {
    kf: [SUPINE_TABLE, P(SUPINE_TABLE, { legs: { R: { p: [86, -18] } }, feet: { R: 60 } }), SUPINE_TABLE, P(SUPINE_TABLE, { legs: { L: { p: [84, -18] } }, feet: { L: 60 } })],
    t: [1.2, 1.2, 1.2, 1.2], h: [0.4, 0.5, 0.4, 0.5], focus: ['trunk'], props: [{ t: 'mat', x: -100, w: 210 }],
  },
  deadbug: {
    kf: [
      SUPINE_TABLE,
      P(SUPINE_TABLE, { legs: { R: { p: [86, -18] } }, feet: { R: 60 }, arms: { L: { a: -80, r: 0.97 } } }),
      SUPINE_TABLE,
      P(SUPINE_TABLE, { legs: { L: { p: [84, -18] } }, feet: { L: 60 }, arms: { R: { a: -82, r: 0.97 } } }),
    ],
    t: [1.3, 1.3, 1.3, 1.3], h: [0.4, 0.5, 0.4, 0.5], focus: ['trunk'], props: [{ t: 'mat', x: -110, w: 220 }],
  },
  birddog: {
    kf: [
      QUAD,
      P(QUAD, { legs: { R: { a: -88, r: 0.99 } }, arms: { L: { a: 88, r: 0.97 } }, feet: { R: -90 } }),
      QUAD,
      P(QUAD, { legs: { L: { a: -88, r: 0.99 } }, arms: { R: { a: 88, r: 0.97 } } }),
    ],
    t: [1.3, 1.3, 1.3, 1.3], h: [0.3, 1.0, 0.3, 1.0], focus: ['trunk', 'glute'], props: [{ t: 'mat', x: -90, w: 200 }],
  },
  cat_camel: {
    kf: [QUAD, P(QUAD, { hip: [-2, -55], trunk: 80, head: 45 }), QUAD, P(QUAD, { hip: [2, -49], trunk: 92, head: -28 })],
    t: [1.2, 1.2, 1.2, 1.2], h: [0.2, 0.6, 0.2, 0.6], focus: ['trunk'], props: [{ t: 'mat', x: -90, w: 200 }],
  },
  plank: {
    kf: [{ hip: [0.4, -27.3], trunk: 82.6, legs: { R: { p: [-86.8, -16] }, L: { p: [-88.8, -16] } }, feet: PU_FEET, arms: { R: { p: [80, -4] }, L: { p: [78, -4] } } }],
    focus: ['trunk'], props: [{ t: 'mat', x: -110, w: 220 }],
  },
  plank_long: {
    kf: [{ hip: [0.4, -27.3], trunk: 82.6, legs: { R: { p: [-86.8, -16] }, L: { p: [-88.8, -16] } }, feet: PU_FEET, arms: { R: { p: [96, -4] }, L: { p: [94, -4] } } }],
    focus: ['trunk'], props: [{ t: 'mat', x: -110, w: 230 }],
  },
  plank_taps: {
    kf: [
      P(PU_TOP, { arms: { R: { a: 180, r: 0.99 }, L: { a: 182, r: 0.99 } } }),
      P(PU_TOP, { arms: { R: { a: 200, r: 0.36 }, L: { a: 182, r: 0.99 } } }),
      P(PU_TOP, { arms: { R: { a: 180, r: 0.99 }, L: { a: 182, r: 0.99 } } }),
      P(PU_TOP, { arms: { R: { a: 180, r: 0.99 }, L: { a: 200, r: 0.36 } } }),
    ],
    t: [0.6, 0.6, 0.6, 0.6], h: [0.3, 0.4, 0.3, 0.4], focus: ['trunk'],
  },

  march: {
    kf: [
      { hip: [0, -94], trunk: 0, legs: { R: { a: 178, r: 0.995 }, L: { a: 182, r: 0.995 } }, arms: HANG },
      { hip: [0, -94], trunk: 0, legs: { R: { a: 140, r: 0.55 }, L: { a: 182, r: 0.995 } }, arms: { R: { a: 210, r: 0.9 }, L: { a: 150, r: 0.9 } } },
      { hip: [0, -94], trunk: 0, legs: { R: { a: 178, r: 0.995 }, L: { a: 182, r: 0.995 } }, arms: HANG },
      { hip: [0, -94], trunk: 0, legs: { R: { a: 178, r: 0.995 }, L: { a: 140, r: 0.55 } }, arms: { R: { a: 150, r: 0.9 }, L: { a: 210, r: 0.9 } } },
    ],
    t: [0.35, 0.35, 0.35, 0.35], h: [0, 0.05, 0, 0.05], focus: [],
  },
  step_jack: {
    view: 'front',
    kf: [
      P(FRONT_STAND, { legs: { R: { p: [6, -6] }, L: { p: [-6, -6] } } }),
      P(FRONT_STAND, { hip: [6, -92], legs: { R: { p: [40, -6] }, L: { p: [-6, -6] } }, arms: { R: { a: 20, r: 0.97 }, L: { a: -20, r: 0.97 } } }),
      P(FRONT_STAND, { legs: { R: { p: [6, -6] }, L: { p: [-6, -6] } } }),
      P(FRONT_STAND, { hip: [-6, -92], legs: { R: { p: [6, -6] }, L: { p: [-40, -6] } }, arms: { R: { a: 20, r: 0.97 }, L: { a: -20, r: 0.97 } } }),
    ],
    t: [0.45, 0.45, 0.45, 0.45], h: [0.05, 0.1, 0.05, 0.1], focus: [],
  },
  jumping_jack: {
    view: 'front',
    kf: [
      P(FRONT_STAND, { legs: { R: { p: [6, -6] }, L: { p: [-6, -6] } } }),
      P(FRONT_STAND, { hip: [0, -100], legs: { R: { p: [34, -12] }, L: { p: [-34, -12] } }, arms: { R: { a: 18, r: 0.97 }, L: { a: -18, r: 0.97 } } }),
    ],
    t: [0.3, 0.3], h: [0.05, 0.05], focus: [],
  },
  arm_circles: {
    view: 'front',
    kf: [
      P(FRONT_STAND, { arms: { R: { a: 172, r: 0.97 }, L: { a: 188, r: 0.97 } } }),
      P(FRONT_STAND, { arms: { R: { a: 90, r: 0.97 }, L: { a: -90, r: 0.97 } } }),
      P(FRONT_STAND, { arms: { R: { a: 8, r: 0.97 }, L: { a: -8, r: 0.97 } } }),
      P(FRONT_STAND, { arms: { R: { a: 90, r: 0.97 }, L: { a: -90, r: 0.97 } } }),
    ],
    t: [0.5, 0.5, 0.5, 0.5], h: [0, 0, 0, 0], focus: ['upperR', 'upperL'],
  },
  mountain: {
    kf: [
      P(PU_TOP, { legs: { R: { a: 140, r: 0.5 }, L: { a: -109.2, r: 0.998 } }, feet: { R: 110, L: 180 } }),
      P(PU_TOP, { legs: { R: { a: -109.2, r: 0.998 }, L: { a: 140, r: 0.5 } }, feet: { R: 180, L: 110 } }),
    ],
    t: [0.32, 0.32], h: [0.02, 0.02], focus: ['trunk'],
  },
  squat_jump: {
    kf: [
      { hip: [-26, -46], trunk: 38, legs: FEET2, arms: { R: { a: 205, r: 0.95 }, L: { a: 203, r: 0.95 } } },
      { hip: [0, -112], trunk: 0, legs: { R: { p: [4, -24] }, L: { p: [0, -24] } }, feet: { R: 140, L: 140 }, arms: { R: { a: 12, r: 0.95 }, L: { a: 8, r: 0.95 } } },
    ],
    t: [0.35, 0.45], h: [0.3, 0.05], focus: SQ_FOCUS,
  },

  hip_flexor: {
    kf: [
      { hip: [-6, -52], trunk: -4, legs: { R: { p: [36, -6] }, L: { p: [-50, -8] } }, feet: { L: -90 }, sole: { L: -1 }, arms: { R: { p: [34, -58] }, L: { a: 4, r: 0.97 } } },
      { hip: [2, -50], trunk: -8, legs: { R: { p: [36, -6] }, L: { p: [-50, -8] } }, feet: { L: -90 }, sole: { L: -1 }, arms: { R: { p: [34, -58] }, L: { a: 0, r: 0.97 } } },
    ],
    t: [2.5, 2.5], h: [1.5, 1.5], focus: ['thighL'], props: [{ t: 'mat', x: -70, w: 130 }],
  },
  knee_hug: {
    kf: [
      { hip: [0, -10], trunk: -90, headA: -90, legs: { R: { p: [10, -60] }, L: { p: [86, -6] } }, arms: { R: { p: [-28, -44] }, L: { p: [-30, -42] } } },
      { hip: [0, -10], trunk: -90, headA: -90, legs: { R: { p: [2, -58] }, L: { p: [86, -6] } }, arms: { R: { p: [-34, -40] }, L: { p: [-36, -38] } } },
    ],
    t: [2.5, 2.5], h: [1.5, 1.5], focus: ['glute'], props: [{ t: 'mat', x: -90, w: 200 }],
  },
  child_pose: {
    kf: [{ hip: [-26, -28], trunk: 100, legs: { R: { p: [-34, -7] }, L: { p: [-36, -7] } }, feet: { R: -90, L: -90 }, sole: { R: -1, L: -1 }, arms: { R: { p: [80, -5] }, L: { p: [78, -5] } } }],
    focus: [], props: [{ t: 'mat', x: -70, w: 170 }],
  },
  breathing: { root: 'neck', kf: [BR_BOT], focus: ['trunk'], props: [{ t: 'mat', x: -60, w: 140 }] },
  // ================= attrezzi aggiuntivi =================
  trx_squat: {
    kf: [{ hip: [0, -94], trunk: -4, legs: FEET2, arms: { R: { a: 66, r: 0.95, w: 1.2 }, L: { a: 64, r: 0.95, w: 1.2 } } },
      { hip: [-34, -42], trunk: 26, legs: FEET2, arms: { R: { a: 70, r: 0.97, w: 1.2 }, L: { a: 68, r: 0.97, w: 1.2 } } }],
    t: [1.5, 1.1], h: [0.5, 0.3], focus: SQ_FOCUS, props: [{ t: 'trx', at: TRX_A, to: 'wrists' }],
  },
  sumo: {
    kf: [{ hip: [0, -92], trunk: 0, legs: { R: { p: [4, -6], w: 2.0, ko: 2.2 }, L: { p: [0, -6], w: 2.0, ko: 2.2 } }, arms: { R: { a: 172, r: 0.97, w: 0.3 }, L: { a: 170, r: 0.97, w: 0.3 } } },
      { hip: [-12, -52], trunk: 18, legs: { R: { p: [4, -6], w: 2.0, ko: 2.4 }, L: { p: [0, -6], w: 2.0, ko: 2.4 } }, arms: { R: { a: 176, r: 0.97, w: 0.3 }, L: { a: 174, r: 0.97, w: 0.3 } } }],
    t: [1.6, 1.2], h: [0.5, 0.3], focus: SQ_FOCUS, w3: { toesOut: 30 }, props: [{ t: 'kb', at: 'wrists', dy: 2 }],
  },
  slide_lunge: {
    kf: [LUNGE_STAND, LUNGE_L], t: [1.4, 1.1], h: [0.3, 0.3], focus: ['glute', 'thighR'],
    props: [{ t: 'towel', at: 'toeL' }],
  },
  split_kb: {
    kf: [P(SPLIT_TOP, { arms: CHEST_HOLD }), P(SPLIT_BOT, { arms: CHEST_HOLD })],
    t: [1.7, 1.2], h: [0.5, 0.3], focus: ['glute', 'thighR'], props: [{ t: 'kb', at: 'wrists', dy: 2 }],
  },
  kb_deadlift: {
    kf: [{ hip: [0, -93], trunk: 0, legs: { R: { p: [4, -6], w: 1.6 }, L: { p: [0, -6], w: 1.6 } }, arms: { R: { a: 180, r: 0.97, w: 0.32 }, L: { a: 178, r: 0.97, w: 0.32 } } },
      { hip: [-26, -50], trunk: 55, legs: { R: { p: [4, -6], w: 1.6, ko: 1.8 }, L: { p: [0, -6], w: 1.6, ko: 1.8 } }, arms: { R: { a: 180, r: 0.97, w: 0.32 }, L: { a: 178, r: 0.97, w: 0.32 } } }],
    t: [1.8, 1.2], h: [0.5, 0.3], focus: ['glute', 'thighR', 'thighL'], w3: { toesOut: 20 }, props: [{ t: 'kb', at: 'wrists', dy: 2 }],
  },
  prone_curl: {
    kf: [P(PRONE, { legs: { R: { a: -90, r: 0.99 }, L: { a: -90, r: 0.99 } }, arms: { R: { p: [40, -5], w: 0.5 }, L: { p: [38, -5], w: 0.5 } } }),
      P(PRONE, { legs: { R: { p: [-44, -52] }, L: { p: [-46, -50] } }, feet: { R: 90, L: 90 }, arms: { R: { p: [40, -5], w: 0.5 }, L: { p: [38, -5], w: 0.5 } } })],
    t: [1.2, 1.6], h: [0.4, 0.5], focus: ['thighR', 'thighL'], props: [{ t: 'mat', x: -110, w: 220 }, { t: 'ankle' }],
  },
  ball_curl: {
    root: 'neck',
    kf: [P(CURL_EXT, { trunk: -104, legs: { R: { p: [112, -50] }, L: { p: [108, -50] } }, feet: { R: 10, L: 10 } }),
      P(CURL_FLEX, { trunk: -122, legs: { R: { p: [70, -56] }, L: { p: [66, -56] } }, feet: { R: -20, L: -20 } })],
    t: [1.2, 1.4], h: [0.4, 0.4], focus: ['thighR', 'thighL', 'glute'], props: [{ t: 'ball', at: 'heels', r: 30 }],
  },
  sl_ball_curl: {
    root: 'neck',
    kf: [P(CURL_EXT, { trunk: -104, legs: { R: { p: [112, -50] }, L: { a: 40, r: 0.98 } }, feet: { R: 10 } }),
      P(CURL_FLEX, { trunk: -122, legs: { R: { p: [70, -56] }, L: { a: 40, r: 0.98 } }, feet: { R: -20 } })],
    t: [1.3, 1.5], h: [0.4, 0.4], focus: ['thighR', 'glute'], props: [{ t: 'ball', at: 'heelR', r: 30 }],
  },
  trx_curl: {
    root: 'neck',
    kf: [P(CURL_EXT, { trunk: -102, legs: { R: { p: [104, -34] }, L: { p: [100, -34] } }, feet: { R: 0, L: 0 } }),
      P(CURL_FLEX, { trunk: -120, legs: { R: { p: [62, -44] }, L: { p: [58, -44] } }, feet: { R: -30, L: -30 } })],
    t: [1.2, 1.4], h: [0.4, 0.4], focus: ['thighR', 'thighL', 'glute'], props: [{ t: 'mat', x: -60, w: 140 }, { t: 'trx', at: [112, -205], to: 'heels' }],
  },
  clamshell: {
    plane: 'lie',
    kf: [CLAM, P(CLAM, { legs: { R: { p: [28, -16], dz: 20, kz: 30, ky: 34 } } })],
    t: [1.1, 1.3], h: [0.3, 0.7], focus: ['glute'], props: [{ t: 'mat', x: -110, w: 220 }],
  },
  clamshell_band: {
    plane: 'lie',
    kf: [CLAM, P(CLAM, { legs: { R: { p: [28, -16], dz: 20, kz: 30, ky: 30 } } })],
    t: [1.1, 1.3], h: [0.3, 0.7], focus: ['glute'], props: [{ t: 'mat', x: -110, w: 220 }, { t: 'miniband', at: 'knees' }],
  },
  hydrant: {
    kf: [QUAD, P(QUAD, { legs: { R: { p: [-14, -46], w: 3.4, ko: 4.2 } } }), QUAD, P(QUAD, { legs: { L: { p: [-14, -46], w: 3.4, ko: 4.2 } } })],
    t: [1.0, 1.0, 1.0, 1.0], h: [0.3, 0.6, 0.3, 0.6], focus: ['glute'], cam: { yaw: 150, pitch: 14 }, props: [{ t: 'mat', x: -90, w: 200 }],
  },
  hydrant_band: {
    kf: [QUAD, P(QUAD, { legs: { R: { p: [-14, -46], w: 3.2, ko: 4 } } })],
    t: [1.0, 1.1], h: [0.3, 0.6], focus: ['glute'], cam: { yaw: 150, pitch: 14 }, props: [{ t: 'mat', x: -90, w: 200 }, { t: 'miniband', at: 'knees' }],
  },
  donkey: {
    kf: [QUAD, P(QUAD, { legs: { R: { p: [-50, -98] } }, feet: { R: 0 }, sole: { R: 1 } })],
    t: [1.0, 1.2], h: [0.3, 0.7], focus: ['glute'], props: [{ t: 'mat', x: -90, w: 200 }],
  },
  donkey_ankle: {
    kf: [QUAD, P(QUAD, { legs: { R: { p: [-50, -98] } }, feet: { R: 0 }, sole: { R: 1 } })],
    t: [1.0, 1.3], h: [0.3, 0.7], focus: ['glute'], props: [{ t: 'mat', x: -90, w: 200 }, { t: 'ankle' }],
  },
  donkey_band: {
    kf: [QUAD, P(QUAD, { legs: { R: { p: [-50, -98] } }, feet: { R: 0 }, sole: { R: 1 } })],
    t: [1.0, 1.3], h: [0.3, 0.7], focus: ['glute'], props: [{ t: 'mat', x: -90, w: 200 }, { t: 'band', from: 'kneeL', to: 'toeR' }],
  },
  sideabd_ankle: {
    plane: 'lie',
    kf: [SIDE_LYING, P(SIDE_LYING, { legs: { R: { a: 62, r: 0.99 } }, feet: { R: 150 } })],
    t: [1.2, 1.4], h: [0.3, 0.6], focus: ['glute'], props: [{ t: 'mat', x: -110, w: 220 }, { t: 'ankle' }],
  },
  sl_calf_kb: {
    kf: [
      P(STAND, { legs: { R: { p: [0, -6] }, L: { a: 200, r: 0.7 } }, arms: { R: { a: 180, r: 0.97 }, L: { a: 172, r: 0.97 } } }),
      P(STAND, { hip: [7, -103], legs: { R: { p: [7.6, -14.9] }, L: { a: 200, r: 0.7 } }, feet: { R: 130 }, arms: { R: { a: 180, r: 0.97 }, L: { a: 172, r: 0.97 } } }),
    ],
    t: [1.0, 1.4], h: [0.4, 0.8], focus: ['shankR'], props: [{ t: 'kb', at: 'wristR', dy: 2 }],
  },
  band_pushup: { kf: [PU_TOP, PU_BOT], t: [1.4, 1.0], h: [0.4, 0.3], focus: ['upperR', 'upperL'], props: [{ t: 'backband' }] },
  trx_row_high: {
    kf: [{ hip: [-12, -86], trunk: -20, legs: ROW_LEGS, arms: { R: { p: [70, -150], w: 1.0 }, L: { p: [68, -150], w: 1.0 } } },
      { hip: [-2, -90], trunk: -10, legs: ROW_LEGS, arms: { R: { a: 62, r: 0.36, w: 1.3 }, L: { a: 60, r: 0.36, w: 1.3 } } }],
    t: [1.0, 1.5], h: [0.4, 0.6], focus: ['upperR', 'upperL'], props: [{ t: 'trx', at: TRX_A, to: 'wrists' }],
  },
  trx_row: {
    kf: [{ hip: [-26, -73], trunk: -40, legs: ROW_LEGS, arms: { R: { p: [60, -126], w: 1.0 }, L: { p: [58, -126], w: 1.0 } } },
      { hip: [-11, -83], trunk: -28, legs: ROW_LEGS, arms: { R: { a: 64, r: 0.36, w: 1.3 }, L: { a: 62, r: 0.36, w: 1.3 } } }],
    t: [1.0, 1.5], h: [0.4, 0.6], focus: ['upperR', 'upperL'], props: [{ t: 'trx', at: TRX_A, to: 'wrists' }],
  },
  band_pulldown: {
    kf: [{ hip: [0, -52], trunk: 4, legs: { R: { p: [-44, -7] }, L: { p: [-46, -7] } }, feet: { R: -90, L: -90 }, sole: { R: -1, L: -1 }, arms: { R: { a: 26, r: 0.97, w: 1.4 }, L: { a: 24, r: 0.97, w: 1.4 } } },
      { hip: [0, -52], trunk: -2, legs: { R: { p: [-44, -7] }, L: { p: [-46, -7] } }, feet: { R: -90, L: -90 }, sole: { R: -1, L: -1 }, arms: { R: { a: 70, r: 0.42, w: 1.5, eo: 2.2 }, L: { a: 68, r: 0.42, w: 1.5, eo: 2.2 } } }],
    t: [1.0, 1.5], h: [0.4, 0.6], focus: ['upperR', 'upperL'], props: [{ t: 'mat', x: -70, w: 120 }, { t: 'trx', at: [70, -230], to: 'wrists', band: true }],
  },
  scap_pull: {
    root: 'neck', kf: [HANG_BAR, P(HANG_BAR, { neck: [4, -175] })], t: [0.9, 1.1], h: [0.3, 1.0],
    focus: ['upperR', 'upperL'], w3: { noSnap: true }, props: [BAR],
  },
  neg_pullup: {
    root: 'neck', kf: [TOP_BAR, HANG_BAR], t: [3.6, 1.0], h: [0.6, 0.5],
    focus: ['upperR', 'upperL'], w3: { noSnap: true }, props: [BAR],
  },
  pullup: {
    root: 'neck', kf: [HANG_BAR, TOP_BAR], t: [1.3, 1.6], h: [0.4, 0.4],
    focus: ['upperR', 'upperL'], w3: { noSnap: true }, props: [BAR],
  },
  band_pullup: {
    root: 'neck', kf: [HANG_BAR, TOP_BAR], t: [1.3, 1.6], h: [0.4, 0.4],
    focus: ['upperR', 'upperL'], w3: { noSnap: true }, props: [BAR, { t: 'trx', at: [12, -224], to: 'knees', band: true }],
  },
  hang_knee: {
    root: 'neck', kf: [HANG_BAR, P(HANG_BAR, { legs: { R: { a: 92, r: 0.62 }, L: { a: 94, r: 0.62 } }, feet: { R: 150, L: 150 }, bend: { kR: -1, kL: -1 } })],
    t: [1.2, 1.4], h: [0.4, 0.5], focus: ['trunk'], w3: { noSnap: true }, props: [BAR],
  },
  ball_rollout: {
    kf: [{ hip: [-30, -54], trunk: 48, legs: { R: { p: [-74, -7] }, L: { p: [-76, -7] } }, feet: { R: -90, L: -90 }, sole: { R: -1, L: -1 }, arms: { R: { p: [46, -58], w: 0.6, flat: false }, L: { p: [44, -58], w: 0.6, flat: false } } },
      { hip: [-12, -40], trunk: 74, legs: { R: { p: [-74, -7] }, L: { p: [-76, -7] } }, feet: { R: -90, L: -90 }, sole: { R: -1, L: -1 }, arms: { R: { p: [84, -52], w: 0.6, flat: false }, L: { p: [82, -52], w: 0.6, flat: false } } }],
    t: [1.6, 1.4], h: [0.4, 0.6], focus: ['trunk'], props: [{ t: 'mat', x: -100, w: 120 }, { t: 'ball', at: 'elbows', r: 28 }],
  },
  pallof: {
    kf: [{ hip: [0, -92], trunk: 0, legs: { R: { p: [4, -6], w: 1.5 }, L: { p: [0, -6], w: 1.5 } }, arms: CHEST_HOLD },
      { hip: [0, -92], trunk: 0, legs: { R: { p: [4, -6], w: 1.5 }, L: { p: [0, -6], w: 1.5 } }, arms: { R: { a: 92, r: 0.92, w: 0.15 }, L: { a: 90, r: 0.92, w: 0.15 } } }],
    t: [1.0, 1.4], h: [0.3, 1.2], focus: ['trunk'], props: [{ t: 'band', from: 'wrists', side: [14, -118, 0] }],
  },
};
