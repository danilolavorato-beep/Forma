// Forma — sceglie come disegnare le figure: modello 3D realistico se il dispositivo lo supporta,
// altrimenti la figura essenziale in 2D. Le viste chiamano solo createFigure(anim, opzioni).
import { createFigure as create2D } from './figure.js';

let f3 = null;
let mode = '2d';

// nomi dei muscoli negli esercizi → zone evidenziate sul modello
const MUSCLE_MAP = [
  [/medio|piccolo|abdutt/, 'glutemed'],
  [/glute/, 'glutes'],
  [/quadric/, 'quads'],
  [/femoral/, 'hamstrings'],
  [/addutt/, 'adductors'],
  [/polpacc/, 'calves'],
  [/core|addomin|obliqu/, 'core'],
  [/erettor|lombar/, 'lowback'],
  [/pettoral/, 'chest'],
  [/romboid|dorsal|trapez|schiena/, 'upperback'],
  [/spall|deltoid/, 'delts'],
  [/bicipit/, 'biceps'],
  [/tricipit/, 'triceps'],
  [/^gambe$/, 'quads'],
];
export function musclesOf(ex) {
  if (!ex || !ex.muscles) return [];
  const out = new Set();
  for (const raw of ex.muscles.split(',')) {
    const m = raw.trim().toLowerCase();
    for (const [re, id] of MUSCLE_MAP) if (re.test(m)) { out.add(id); break; }
  }
  return [...out];
}

export async function initFigures(enabled = true, timeoutMs = 6000) {
  if (!enabled) { mode = '2d'; return mode; }
  try {
    f3 = await import('./figure3d.js');
    await Promise.race([f3.load3d(), new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), timeoutMs))]);
    mode = '3d';
  } catch (e) {
    console.warn('Figure 3D non disponibili, uso il 2D:', e && e.message);
    mode = '2d';
  }
  return mode;
}
export const figureMode = () => mode;
export function setFigureMode(m) { mode = m === '3d' && f3 && f3.is3dReady() ? '3d' : '2d'; }

export function createFigure(anim, opts = {}) {
  if (mode === '3d' && f3 && f3.is3dReady()) {
    try { return f3.createFigure3D(anim, { ...opts, muscles: opts.muscles || musclesOf(opts.ex) }); } catch (e) { console.warn(e); }
  }
  return create2D(anim, opts);
}
