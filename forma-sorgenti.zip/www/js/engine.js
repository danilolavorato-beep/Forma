// Forma — motore del programma: costruzione delle sessioni, regole di progressione, calendario.
// Nessuna dipendenza dal DOM: è testato con `node --test`.
import { EX, EQUIP, hasEquipment } from './data/exercises.js';
import {
  LADDERS, SLOT, PHASES, CYCLES, ROTATION, WARMUP, COOLDOWN, FINISHERS, TESTS, DEFAULT_LEVELS, levelsFromTests,
} from './data/program.js';

export const DAY = 86400000;

// ---------- stato iniziale ----------
export function defaultState(now = Date.now()) {
  const eq = {};
  for (const k in EQUIP) eq[k] = EQUIP[k].def;
  return {
    v: 1,
    created: now,
    settings: {
      days: 3, quick: false, mode: 'prog', eq, weights: defaultWeights(), figure3d: true,
      finisher: true, noJumps: true, cooldown: true,
      voice: true, sound: true, vibe: true, theme: 'auto', onboarded: false, parq: null,
    },
    levels: { ...DEFAULT_LEVELS },
    perf: {},
    progress: { week: 1, inWeek: 0, rot: 0, total: 0, lastAt: null, testWeek: null },
    history: [],
    tests: [],
    measures: [],
  };
}

export function defaultWeights() {
  const w = {};
  for (const k in EQUIP) if (EQUIP[k].weights) w[k] = Array.isArray(EQUIP[k].defWeights) ? EQUIP[k].defWeights.slice() : EQUIP[k].defWeights;
  return w;
}

// ---------- attrezzi e carichi ----------
const IMPL_NAMES = { kb: 'Kettlebell', manubri: 'Manubri', zaino: 'Zaino', cavigliere: 'Cavigliere' };
const START_KG = {
  big: { kb: 12, manubri: 8, zaino: 8 }, uni: { kb: 8, manubri: 6, zaino: 6 }, row: { manubri: 6, kb: 8, zaino: 6 },
  press: { manubri: 4, kb: 8 }, swing: { kb: 12 }, calf: { manubri: 8, kb: 12 }, ankle: { cavigliere: 1 },
};

// pesi disponibili per un attrezzo, in ordine crescente
export function weightsOf(state, impl) {
  const w = (state.settings.weights || {})[impl];
  if (impl === 'zaino') {
    const max = Math.max(2, +w || 8);
    const out = [];
    for (let kg = 2; kg <= max; kg += 1) out.push(kg);
    return out;
  }
  return Array.isArray(w) && w.length ? [...new Set(w.map(Number))].filter((x) => x > 0).sort((a, b) => a - b) : [];
}

// attrezzo usato per un esercizio con carico, secondo le preferenze dell'esercizio e ciò che hai
export function implFor(state, exId) {
  const ex = EX[exId];
  if (!ex || !ex.impl) return null;
  const eq = state.settings.eq;
  for (const k of ex.impl) if (eq[k] && (k === 'zaino' || weightsOf(state, k).length)) return k;
  return null;
}

export function loadFor(state, exId) {
  const impl = implFor(state, exId);
  if (!impl) return null;
  const list = weightsOf(state, impl);
  const p = state.perf[exId];
  if (p && p.impl === impl && list.includes(p.kg)) return { impl, kg: p.kg, list };
  const start = (START_KG[EX[exId].load] || {})[impl] ?? list[0];
  const below = list.filter((x) => x <= start);
  return { impl, kg: below.length ? below[below.length - 1] : list[0], list };
}

export function loadLabel(load, ex) {
  if (!load) return '';
  const kg = String(load.kg).replace('.', ',');
  if (load.impl === 'manubri') return ex && ex.uni && ex.cat !== 'gambe' ? `Manubrio ${kg} kg` : `Manubri ${kg} kg`;
  return `${IMPL_NAMES[load.impl]} ${kg} kg`;
}

// ---------- fasi e settimane ----------
export function phaseForWeek(week) {
  const w = Math.max(1, week | 0);
  const ph = PHASES.find((p) => w >= p.from && (p.to == null || w <= p.to)) || PHASES[PHASES.length - 1];
  const out = { phase: ph, weekInPhase: w - ph.from + 1, light: false, cycle: null, cycleWeek: null, cycleNo: null };
  if (ph.light === 'cycle') {
    const idx = Math.floor((w - ph.from) / 6);
    out.cycleNo = idx + 1;
    out.cycle = CYCLES[idx % CYCLES.length];
    out.cycleWeek = ((w - ph.from) % 6) + 1;
    out.light = out.cycleWeek === 6;
  } else {
    out.light = ph.light.includes(w);
  }
  return out;
}

export function phaseLabel(info) {
  if (info.cycle) return `Ciclo ${info.cycleNo} · ${info.cycle.name}`;
  return info.phase.name;
}

// ---------- scale e varianti ----------
export function availableIndex(ladderKey, level, eq) {
  const list = LADDERS[ladderKey].list;
  const l = Math.max(0, Math.min(list.length - 1, level | 0));
  for (let k = l; k >= 0; k--) if (hasEquipment(list[k], eq)) return k;
  for (let k = l + 1; k < list.length; k++) if (hasEquipment(list[k], eq)) return k;
  return -1;
}

export function nextIndex(ladderKey, from, eq, dir = 1) {
  const list = LADDERS[ladderKey].list;
  for (let k = from + dir; k >= 0 && k < list.length; k += dir) if (hasEquipment(list[k], eq)) return k;
  return -1;
}

export function resolveSlot(slotKey, state) {
  const eq = state.settings.eq;
  const spec = SLOT[slotKey] || { ladders: [slotKey] };
  for (let n = 0; n < spec.ladders.length; n++) {
    const L = spec.ladders[n];
    if (n === 0 && spec.unlock) {
      const ok = Object.entries(spec.unlock).every(([k, min]) => (state.levels[k] ?? 0) >= min);
      if (!ok) continue;
    }
    const idx = availableIndex(L, state.levels[L] ?? 0, eq);
    if (idx >= 0) return { ladder: L, idx, ex: LADDERS[L].list[idx] };
  }
  return null;
}

function defaultTarget(ex) {
  const [lo, hi] = ex.range;
  return ex.type === 'time' ? Math.round((lo + (hi - lo) * 0.3) / 5) * 5 : lo + Math.round((hi - lo) * 0.3);
}

export function targetFor(state, exId) {
  const ex = EX[exId];
  const p = state.perf[exId];
  const t = p && p.target != null ? p.target : defaultTarget(ex);
  return Math.max(ex.range[0], Math.min(ex.range[1], t));
}

// ---------- costruzione della sessione ----------
export function nextKey(state) {
  const mode = state.settings.mode;
  const rot = ROTATION[mode === 'mant' ? 2 : state.settings.days] || ROTATION[3];
  return rot[state.progress.rot % rot.length];
}

export function isTestDue(state) {
  if (state.settings.mode === 'mant') return false;
  if (!state.tests.length) return !state.progress.testSkipped;
  const info = phaseForWeek(state.progress.week);
  return info.light && state.progress.inWeek === 0 && state.progress.testWeek !== state.progress.week;
}

export function daysSince(state, now = Date.now()) {
  if (state.progress.lastAt == null) return null;
  return Math.floor((now - state.progress.lastAt) / DAY);
}

export function buildSession(state, opts = {}) {
  const s = state.settings;
  const mant = s.mode === 'mant';
  const info = phaseForWeek(state.progress.week);
  const quick = opts.quick ?? s.quick;
  const gap = daysSince(state, opts.now);
  const comeback = gap != null && gap > 10;
  const light = !mant && (info.light || comeback);
  const key = opts.key || nextKey(state);

  if (opts.test || (opts.test == null && isTestDue(state))) return buildTestSession(state, info);

  const tplPhase = mant || info.phase.sessions == null ? PHASES.find((p) => p.id === 'f3') : info.phase;
  const sessions = tplPhase.sessions;
  const tpl = sessions[key] || sessions.A;
  const cycle = mant ? null : info.cycle;
  let rir = mant ? 1 : info.phase.rir;
  if (light) rir = Math.min(4, rir + 2);
  const allowPush = !light && !mant && (info.phase.id === 'f3' || info.phase.id === 'f4');

  const blocks = [];
  tpl.forEach((blk, bi) => {
    const items = [];
    for (const it of blk.items) {
      if (it.opt && !it.opt.some((k) => s.eq[k])) continue;
      const r = resolveSlot(it.s, state);
      if (!r) continue;
      const ex = EX[r.ex];
      let sets = it.e && !mant && info.weekInPhase <= 2 ? it.e : it.n;
      if (cycle && cycle.extra[r.ladder]) sets += cycle.extra[r.ladder];
      if (!mant && s.days === 2 && it.main && sets < 4) sets += 1;
      if (mant) sets = 2;
      if (light || quick) sets = Math.max(2, sets - 1);
      sets = Math.min(5, sets);
      items.push({
        slot: it.s, ladder: r.ladder, ex: r.ex, sets,
        type: ex.type, uni: !!ex.uni, range: ex.range.slice(),
        target: targetFor(state, r.ex),
        main: !!it.main, push: allowPush && !!it.push,
        load: loadFor(state, r.ex),
      });
    }
    if (!items.length) return;
    let rest = blk.rest + (cycle ? cycle.rest : 0);
    if (quick) rest = Math.max(30, rest - 15);
    blocks.push({ name: `Blocco ${blocks.length + 1}`, rest: Math.max(30, rest), items, rounds: Math.max(...items.map((x) => x.sets)) });
  });

  let finisher = null;
  const finOn = info.phase.finisher && (info.phase.finisher.includes(key) || (cycle && cycle.finisherAll));
  if (s.finisher && finOn && !light && !quick && !mant) {
    const f3 = info.phase.id === 'f3' || info.phase.id === 'f4';
    const id = f3 && s.eq.kb ? 'kb' : !f3 ? 'soft' : s.noJumps ? 'mid' : 'jump';
    finisher = { id, ...FINISHERS[id] };
  }

  const session = {
    kind: 'workout', key,
    title: `Sessione ${key}`,
    phaseId: mant ? 'mant' : info.phase.id,
    phaseName: mant ? 'Mantenimento' : phaseLabel(info),
    week: state.progress.week, weekInPhase: info.weekInPhase,
    light, comeback, quick, rir,
    note: light ? 'Settimana leggera: una serie in meno, ferma ogni serie con 3 ripetizioni in canna.' : mant ? 'Mantenimento: 2 serie per esercizio, vicino al cedimento.' : info.phase.note,
    warmup: (quick ? WARMUP.short : WARMUP.full).map(([ex, secs]) => ({ ex, secs })),
    blocks, finisher,
    cooldown: s.cooldown && !quick ? COOLDOWN.map(([ex, secs]) => ({ ex, secs })) : [],
  };
  return fitBudget(session, quick ? MAX_QUICK_MIN : MAX_MIN);
}

// ---------- tetto di durata ----------
// Le sessioni non devono superare il tempo disponibile. Se la stima sfora, si toglie prima
// il finisher, poi si accorciano i recuperi (non sotto i 45 s: oltre i 60–90 s il guadagno è
// piccolo, sotto i 45 s cala il lavoro utile), poi si toglie una serie agli accessori e, solo
// come ultima risorsa, agli esercizi principali (mai sotto le 2 serie).
export const MAX_MIN = 45;
export const MAX_QUICK_MIN = 25;

export function fitBudget(session, max) {
  session.est = estimate(session);
  if (session.est > max && session.finisher) {
    session.finisher = null;
    session.trimmed = `Oggi niente finisher, per restare nei ${max} minuti.`;
    session.est = estimate(session);
  }
  for (let k = 0; k < 6 && session.est > max; k++) {
    let changed = false;
    for (const b of session.blocks) if (b.rest > 45) { b.rest = Math.max(45, b.rest - 5); changed = true; }
    if (!changed) break;
    session.est = estimate(session);
  }
  for (const mainPass of [false, true]) {
    for (let bi = session.blocks.length - 1; bi >= 0 && session.est > max; bi--) {
      const b = session.blocks[bi];
      for (const it of b.items) {
        if (session.est <= max) break;
        if (it.main === mainPass && it.sets > 2) {
          it.sets -= 1;
          b.rounds = Math.max(...b.items.map((x) => x.sets));
          session.est = estimate(session);
        }
      }
    }
  }
  return session;
}

export function buildTestSession(state, info = phaseForWeek(state.progress.week)) {
  const first = !state.tests.length;
  const session = {
    kind: 'test', key: 'T', initial: first,
    title: first ? 'Test iniziale' : 'Test di controllo',
    phaseId: info.phase.id, phaseName: phaseLabel(info),
    week: state.progress.week, weekInPhase: info.weekInPhase,
    light: true, quick: false, rir: 0,
    note: first ? 'Quattro prove per scegliere da quale livello partire.' : 'Le stesse quattro prove dell’inizio: confrontale con i risultati precedenti.',
    warmup: WARMUP.short.map(([ex, secs]) => ({ ex, secs })),
    tests: TESTS.map((t) => ({ ...t })),
    blocks: [], finisher: null,
    cooldown: COOLDOWN.slice(1).map(([ex, secs]) => ({ ex, secs })),
  };
  session.est = estimate(session);
  return session;
}

// ---------- passaggi del player ----------
export const MOVE_SECS = 12;
export const SWITCH_SECS = 8;
export const BLOCK_GAP = 30;

export function flatten(session) {
  const steps = [];
  session.warmup.forEach((m, k) => steps.push({ t: 'follow', part: 'warmup', ex: m.ex, secs: m.secs, n: k + 1, of: session.warmup.length }));
  if (session.kind === 'test') {
    session.tests.forEach((test, k) => {
      steps.push({ t: 'test', test, n: k + 1, of: session.tests.length });
    });
  }
  session.blocks.forEach((blk, bi) => {
    for (let r = 1; r <= blk.rounds; r++) {
      const inRound = blk.items.map((it, ii) => ({ it, ii })).filter(({ it }) => it.sets >= r);
      inRound.forEach(({ it, ii }, k) => {
        steps.push({
          t: 'set', bi, ii, round: r, rounds: blk.rounds, setNo: r, sets: it.sets,
          ex: it.ex, type: it.type, uni: it.uni, range: it.range, target: it.target, load: it.load || null,
          last: r === it.sets, push: it.push && r === it.sets, block: blk.name,
        });
        const isLastInRound = k === inRound.length - 1;
        if (!isLastInRound) steps.push({ t: 'gap', kind: 'move', secs: MOVE_SECS });
        else if (r < blk.rounds) steps.push({ t: 'gap', kind: 'rest', secs: blk.rest });
        else if (bi < session.blocks.length - 1 || session.finisher || session.cooldown.length) steps.push({ t: 'gap', kind: 'block', secs: BLOCK_GAP });
      });
    }
  });
  if (session.finisher) {
    const f = session.finisher;
    let n = 0;
    const total = f.rounds * f.moves.length;
    for (let r = 1; r <= f.rounds; r++) {
      for (const ex of f.moves) {
        n++;
        steps.push({ t: 'interval', ex, secs: f.work, n, of: total });
        if (n < total) steps.push({ t: 'gap', kind: 'interval', secs: f.rest });
      }
    }
    if (session.cooldown.length) steps.push({ t: 'gap', kind: 'block', secs: 20 });
  }
  session.cooldown.forEach((m, k) => steps.push({ t: 'follow', part: 'cooldown', ex: m.ex, secs: m.secs, n: k + 1, of: session.cooldown.length }));
  // collega ogni pausa all'esercizio successivo (anteprima)
  for (let k = 0; k < steps.length; k++) {
    if (steps[k].t === 'gap') {
      const nx = steps.slice(k + 1).find((x) => x.t !== 'gap');
      steps[k].next = nx || null;
    }
  }
  return steps;
}

export function setSeconds(step) {
  const ex = EX[step.ex];
  const per = step.type === 'time' ? step.target : step.target * (ex.pace ?? (ex.tempo ? 5 : 3));
  return step.uni ? per * 2 + SWITCH_SECS : per;
}

export function estimate(session) {
  let sec = 0;
  for (const st of flatten(session)) {
    if (st.t === 'follow') sec += (EX[st.ex].uni ? st.secs * 2 : st.secs) + 4;
    else if (st.t === 'set') sec += setSeconds(st) + 6;
    else if (st.t === 'gap') sec += st.secs;
    else if (st.t === 'interval') sec += st.secs;
    else if (st.t === 'test') sec += st.test.sides ? 200 : 120;
  }
  return Math.round(sec / 60);
}

// ---------- progressione ----------
// itemLog: { ladder, ex, sets: [{ v, vL }], rir, pain }
export function evaluate(state, itemLog, phaseRir) {
  const ex = EX[itemLog.ex];
  const [lo, hi] = ex.range;
  const eq = state.settings.eq;
  const vals = itemLog.sets
    .filter((x) => x && x.v != null)
    .map((x) => (x.vL != null ? Math.min(x.v, x.vL) : x.v));
  const perf = { ...(state.perf[itemLog.ex] || {}) };
  if (!vals.length) return { decision: 'skip', ex: itemLog.ex };
  const allTop = vals.every((v) => v >= hi);
  const anyBelow = vals.some((v) => v < lo);
  const cur = availableIndex(itemLog.ladder, state.levels[itemLog.ladder] ?? 0, eq);
  const inc = ex.type === 'time' ? 5 : 1;
  const rirOk = itemLog.rir == null || itemLog.rir >= Math.max(0, phaseRir - 1);
  let decision = 'hold';
  let newLevel = null;
  let newKg = null;
  const load = itemLog.load || loadFor(state, itemLog.ex);
  if (load) { perf.impl = load.impl; perf.kg = load.kg; }

  if (!itemLog.pain) perf.pains = 0;
  if (itemLog.pain) {
    // dolore (non fatica): livello fermo la prima volta, variante più facile se si ripete
    decision = 'pain';
    perf.fails = 0;
    perf.pains = (perf.pains || 0) + 1;
    if (perf.pains >= 2) {
      const pv = nextIndex(itemLog.ladder, cur, eq, -1);
      if (pv >= 0) { decision = 'painDown'; newLevel = pv; }
      perf.pains = 0;
    }
  } else if (allTop) {
    const heavier = load ? load.list.find((x) => x > load.kg) : null;
    if (heavier != null) { decision = 'heavier'; newKg = heavier; }
    else {
      const nx = nextIndex(itemLog.ladder, cur, eq, 1);
      if (nx >= 0) { decision = 'up'; newLevel = nx; } else decision = 'max';
    }
    perf.fails = 0;
  } else if (anyBelow) {
    perf.fails = (perf.fails || 0) + 1;
    if (perf.fails >= 2) {
      const lighter = load ? [...load.list].reverse().find((x) => x < load.kg) : null;
      if (lighter != null) { decision = 'lighter'; newKg = lighter; }
      else {
        const pv = nextIndex(itemLog.ladder, cur, eq, -1);
        if (pv >= 0) { decision = 'down'; newLevel = pv; }
      }
      perf.fails = 0;
    }
  } else {
    perf.fails = 0;
  }
  const best = Math.max(...vals);
  perf.last = vals;
  perf.rir = itemLog.rir ?? null;
  perf.target = Math.max(lo, Math.min(hi, best + (rirOk ? inc : 0)));
  if (newKg != null) {
    perf.kg = newKg;
    perf.target = decision === 'heavier' ? lo + Math.round((hi - lo) * 0.25) : hi - 2;
  }
  perf.at = Date.now();
  return { decision, ex: itemLog.ex, ladder: itemLog.ladder, newLevel, newKg, load, perf, best, allTop };
}

export function applyEvaluation(state, ev) {
  if (ev.decision === 'skip') return;
  state.perf[ev.ex] = ev.perf;
  if (ev.newLevel != null) {
    state.levels[ev.ladder] = ev.newLevel;
    const nEx = LADDERS[ev.ladder].list[ev.newLevel];
    const down = ev.decision === 'down' || ev.decision === 'painDown';
    if (!state.perf[nEx] || down) {
      const ex = EX[nEx];
      state.perf[nEx] = { ...(state.perf[nEx] || {}), target: down ? ex.range[1] - 2 : ex.range[0] + (ex.type === 'time' ? 5 : 1) };
    }
  }
}

export function decisionText(ev) {
  const name = EX[ev.ex]?.name || ev.ex;
  const nx = ev.newLevel != null ? EX[LADDERS[ev.ladder].list[ev.newLevel]].name : '';
  const unit = EX[ev.ex]?.type === 'time' ? 's' : 'rip';
  switch (ev.decision) {
    case 'up': return { tone: 'up', text: `${name}: fascia completata. Prossima volta passi a ${nx}.` };
    case 'down': return { tone: 'down', text: `${name}: due sessioni sotto la fascia. Torni a ${nx} per costruire base.` };
    case 'heavier': return { tone: 'up', text: `${name}: fascia completata. Prossima volta ${loadLabel({ ...ev.load, kg: ev.newKg }, EX[ev.ex])}.` };
    case 'lighter': return { tone: 'down', text: `${name}: due sessioni sotto la fascia. Prossima volta ${loadLabel({ ...ev.load, kg: ev.newKg }, EX[ev.ex])}.` };
    case 'max': return { tone: 'up', text: `${name}: sei all’ultimo livello disponibile. ${ev.load ? 'Per crescere ancora serve un peso più alto: aggiungilo in Attrezzatura.' : 'Rallenta la discesa o aggiungi una pausa in basso.'}` };
    case 'pain': return { tone: 'warn', text: `${name}: hai segnalato dolore. Livello invariato; se si ripete la prossima volta, torni alla variante più facile.` };
    case 'painDown': return { tone: 'warn', text: `${name}: dolore segnalato due volte di fila. Torni a ${nx}. Se il dolore continua anche così, sospendi l’esercizio e fallo valutare da un medico.` };
    case 'hold': return { tone: 'hold', text: `${name}: prossimo obiettivo ${ev.perf.target} ${unit}.` };
    default: return null;
  }
}

// ---------- chiusura della sessione ----------
export function completeSession(state, session, log, now = Date.now()) {
  const decisions = [];
  if (session.kind === 'workout') {
    for (const key in log.items) {
      const it = log.items[key];
      const ev = evaluate(state, it, session.rir);
      applyEvaluation(state, ev);
      const d = decisionText(ev);
      if (d) decisions.push({ ...d, ex: ev.ex, decision: ev.decision });
    }
  }
  const p = state.progress;
  if (session.kind === 'test') p.testWeek = p.week;
  if (session.kind === 'test' && log.tests) recordTests(state, log.tests, now);
  p.total += 1;
  p.lastAt = now;
  if (session.kind === 'workout') {
    const list = ROTATION[state.settings.mode === 'mant' ? 2 : state.settings.days] || ROTATION[3];
    const idx = list.indexOf(session.key);
    p.rot = idx >= 0 ? idx + 1 : p.rot + 1;
  }
  if (state.settings.mode !== 'mant' && !session.initial) {
    p.inWeek += 1;
    if (p.inWeek >= state.settings.days) {
      p.week += 1;
      p.inWeek = 0;
    }
  }
  const entry = {
    id: `${now.toString(36)}`,
    at: now,
    kind: session.kind,
    initial: !!session.initial,
    key: session.key,
    title: session.title,
    phaseId: session.phaseId,
    phaseName: session.phaseName,
    week: session.week,
    light: session.light,
    dur: log.dur || 0,
    rpe: log.rpe ?? null,
    note: log.note || '',
    sets: Object.values(log.items || {}).reduce((a, it) => a + it.sets.filter((x) => x && x.v != null).length, 0),
    items: Object.values(log.items || {}).map((it) => ({ ex: it.ex, v: it.sets.map((x) => (x ? x.v : null)), vL: it.sets.map((x) => (x ? x.vL ?? null : null)), rir: it.rir ?? null, pain: !!it.pain })),
    decisions,
  };
  state.history.unshift(entry);
  if (state.history.length > 400) state.history.length = 400;
  return { entry, decisions };
}

export function recordTests(state, result, now = Date.now(), { calibrate } = {}) {
  const first = !state.tests.length;
  state.tests.push({ at: now, ...result });
  // Solo la prima volta (o su richiesta) i test fissano i livelli di partenza
  if (first || calibrate) {
    state.levels = { ...state.levels, ...levelsFromTests(result, state.settings.eq) };
    return true;
  }
  return false;
}

// ---------- vista del programma ----------
export function weekSummary(state, now = Date.now()) {
  const start = new Date(now);
  const dow = (start.getDay() + 6) % 7; // lunedì = 0
  start.setHours(0, 0, 0, 0);
  const monday = start.getTime() - dow * DAY;
  const done = state.history.filter((h) => h.at >= monday && !h.initial).length;
  const days = [];
  for (let k = 0; k < 7; k++) {
    const d0 = monday + k * DAY;
    days.push({ d: d0, n: state.history.filter((h) => h.at >= d0 && h.at < d0 + DAY).length, today: k === dow });
  }
  return { done, target: state.settings.mode === 'mant' ? 2 : state.settings.days, days };
}

export function previewSessions(state) {
  const out = {};
  const keys = ROTATION[state.settings.mode === 'mant' ? 2 : state.settings.days];
  for (const k of keys) out[k] = buildSession(state, { key: k, test: false });
  return out;
}

export function weeklySetsByRole(state) {
  const sessions = previewSessions(state);
  const tot = { glutei: 0, gambe: 0, spinta: 0, tirata: 0, core: 0 };
  for (const k in sessions) {
    for (const blk of sessions[k].blocks) {
      for (const it of blk.items) {
        const c = EX[it.ex].cat;
        const key = c === 'femorali' ? 'glutei' : c === 'mobilita' || c === 'cardio' ? null : c;
        if (key && tot[key] != null) tot[key] += it.sets;
      }
    }
  }
  return tot;
}

export { LADDERS, PHASES, CYCLES, TESTS };
