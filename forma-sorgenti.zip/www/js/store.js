// Forma — salvataggio locale dei dati (restano sul telefono) e backup.
import { defaultState } from './engine.js';
import { EQUIP } from './data/exercises.js';
import { DEFAULT_LEVELS } from './data/program.js';

const KEY = 'forma.v1';
const LIVE = 'forma.live';
let state = null;
const listeners = new Set();

function safeGet(k) {
  try { return localStorage.getItem(k); } catch { return null; }
}
function safeSet(k, v) {
  try { localStorage.setItem(k, v); return true; } catch { return false; }
}
function safeDel(k) {
  try { localStorage.removeItem(k); } catch { /* niente */ }
}

export function migrate(s) {
  const base = defaultState(s.created || Date.now());
  const out = { ...base, ...s };
  out.settings = { ...base.settings, ...(s.settings || {}) };
  out.settings.eq = { ...base.settings.eq, ...((s.settings && s.settings.eq) || {}) };
  for (const k in out.settings.eq) if (!(k in EQUIP)) delete out.settings.eq[k];
  out.settings.weights = { ...base.settings.weights, ...((s.settings && s.settings.weights) || {}) };
  if (s.settings && s.settings.kbKg && !(s.settings.weights && s.settings.weights.kb)) out.settings.weights.kb = [s.settings.kbKg];
  delete out.settings.kbKg;
  out.levels = { ...DEFAULT_LEVELS, ...(s.levels || {}) };
  out.progress = { ...base.progress, ...(s.progress || {}) };
  out.perf = s.perf || {};
  out.history = Array.isArray(s.history) ? s.history : [];
  out.tests = Array.isArray(s.tests) ? s.tests : [];
  out.measures = Array.isArray(s.measures) ? s.measures : [];
  out.v = 1;
  return out;
}

export function load() {
  const raw = safeGet(KEY);
  if (raw) {
    try { state = migrate(JSON.parse(raw)); } catch { state = defaultState(); }
  } else state = defaultState();
  return state;
}

export function get() { return state || load(); }

export function save() {
  const ok = safeSet(KEY, JSON.stringify(state));
  listeners.forEach((fn) => fn(state));
  return ok;
}

export function update(fn) {
  fn(get());
  return save();
}

export function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function reset() {
  state = defaultState();
  safeDel(LIVE);
  save();
}

// ---------- allenamento in corso (ripresa dopo chiusura dell'app) ----------
export function saveLive(live) { safeSet(LIVE, JSON.stringify(live)); }
export function loadLive() {
  const raw = safeGet(LIVE);
  if (!raw) return null;
  try { return JSON.parse(raw); } catch { return null; }
}
export function clearLive() { safeDel(LIVE); }

// ---------- backup ----------
export function exportJSON() {
  return JSON.stringify({ app: 'forma', exportedAt: new Date().toISOString(), data: get() }, null, 1);
}

export function importJSON(text) {
  const obj = JSON.parse(text);
  const data = obj && obj.app === 'forma' ? obj.data : obj;
  if (!data || typeof data !== 'object' || !data.settings || !data.progress) {
    throw new Error('Il file non contiene un backup di Forma.');
  }
  state = migrate(data);
  save();
  return state;
}
