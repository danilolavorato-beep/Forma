// Forma — schermata Attrezzatura: scegli cosa hai e il piano si rigenera con esercizi dedicati.
import * as store from '../store.js';
import { EX, EQUIP, EQUIP_GROUPS, hasEquipment } from '../data/exercises.js';
import { previewSessions, defaultWeights, loadLabel } from '../engine.js';
import { h, icon, toggle } from '../ui.js';

const kgText = (v) => `${String(v).replace('.', ',')} kg`;

// Editor riutilizzabile (anche nel primo avvio). onChange viene chiamato dopo ogni modifica.
export function equipmentEditor(onChange = () => {}) {
  const wrap = h('div', { class: 'eq-editor' });
  const draw = () => {
    while (wrap.firstChild) wrap.removeChild(wrap.firstChild);
    const s = store.get();
    for (const [g, title] of EQUIP_GROUPS) {
      const sec = h('div', { class: 'eq-group' }, h('h3', { class: 'h3' }, title));
      for (const k in EQUIP) {
        const e = EQUIP[k];
        if (e.group !== g) continue;
        const on = !!s.settings.eq[k];
        const card = h('div', { class: `eq-card${on ? ' on' : ''}` },
          toggle(e.name, on, (v) => {
            store.update((st) => {
              st.settings.eq[k] = v;
              st.settings.weights = st.settings.weights || defaultWeights();
              if (v && e.weights === 'list' && !(st.settings.weights[k] || []).length) st.settings.weights[k] = e.defWeights.slice();
            });
            draw(); onChange();
          }, `${e.desc} ${e.price ? `Prezzo indicativo: ${e.price}.` : ''}`));
        if (on && e.weights) card.appendChild(weightPicker(k, () => { draw(); onChange(); }));
        sec.appendChild(card);
      }
      wrap.appendChild(sec);
    }
  };
  draw();
  return wrap;
}

function weightPicker(k, after) {
  const e = EQUIP[k];
  const s = store.get();
  const cur = (s.settings.weights || {})[k];
  if (e.weights === 'max') {
    return h('div', { class: 'eq-weights' },
      h('span', { class: 'tiny' }, 'Carico massimo che riesci a metterci'),
      h('div', { class: 'chips wrap', role: 'radiogroup', 'aria-label': `Carico massimo ${e.name}` }, e.choices.map((v) => h('button', {
        type: 'button', role: 'radio', 'aria-checked': String(v === cur), class: `chip${v === cur ? ' on' : ''}`,
        onClick: () => { store.update((st) => { st.settings.weights[k] = v; }); after(); },
      }, kgText(v)))));
  }
  const list = Array.isArray(cur) ? cur : [];
  return h('div', { class: 'eq-weights' },
    h('span', { class: 'tiny' }, k === 'manubri' ? 'Pesi delle coppie che hai (kg per manubrio)' : k === 'cavigliere' ? 'Peso di ogni cavigliera' : 'Pesi che hai'),
    h('div', { class: 'chips wrap', role: 'group', 'aria-label': `Pesi ${e.name}` }, e.choices.map((v) => {
      const on = list.includes(v);
      return h('button', {
        type: 'button', 'aria-pressed': String(on), class: `chip${on ? ' on' : ''}`,
        onClick: () => {
          store.update((st) => {
            const l = new Set(st.settings.weights[k] || []);
            if (l.has(v)) { if (l.size > 1) l.delete(v); } else l.add(v);
            st.settings.weights[k] = [...l].sort((a, b) => a - b);
          });
          after();
        },
      }, kgText(v));
    })));
}

// Confronta il piano con quello a corpo libero: cosa cambia grazie agli attrezzi
export function planChanges(state) {
  const bare = JSON.parse(JSON.stringify(state));
  for (const k in bare.settings.eq) bare.settings.eq[k] = false;
  const mine = previewSessions(state);
  const base = previewSessions(bare);
  const out = [];
  const seen = new Set();
  for (const key in mine) {
    const bItems = (base[key] ? base[key].blocks.flatMap((b) => b.items) : []);
    for (const it of mine[key].blocks.flatMap((b) => b.items)) {
      const ref = bItems.find((x) => x.slot === it.slot);
      if (seen.has(it.ex)) continue;
      if (!ref) { seen.add(it.ex); out.push({ ex: it.ex, load: it.load, added: true }); continue; }
      if (ref.ex !== it.ex || it.load) { seen.add(it.ex); out.push({ ex: it.ex, load: it.load, instead: ref.ex !== it.ex ? ref.ex : null }); }
    }
  }
  return out;
}

export function renderEquipment(ctx) {
  const { top, main, go } = ctx;
  top.append(
    h('a', { class: 'icon-btn', href: '#/programma', 'aria-label': 'Torna al Programma' }, icon('back')),
    h('h1', {}, 'Attrezzatura'));
  main.appendChild(h('p', { class: 'muted' }, 'Seleziona quello che hai in casa. Esercizi, sessioni e progressione si adattano subito: con i pesi l’app ti dice anche quale usare e quando passare al successivo.'));
  const summary = h('section', { class: 'eq-summary' });
  const fillSummary = () => {
    while (summary.firstChild) summary.removeChild(summary.firstChild);
    const s = store.get();
    const all = Object.keys(EX).filter((id) => !['mobilita', 'cardio'].includes(EX[id].cat));
    const ok = all.filter((id) => hasEquipment(id, s.settings.eq));
    const ch = planChanges(s).slice(0, 8);
    summary.append(
      h('div', { class: 'kv' }, h('h2', { class: 'h2' }, 'Il tuo piano'), h('span', { class: 'muted' }, `${ok.length} esercizi su ${all.length}`)),
      ch.length
        ? h('ul', { class: 'eq-changes' }, ch.map((c) => h('li', {},
          h('b', {}, EX[c.ex].name), c.load ? ` con ${loadLabel(c.load, EX[c.ex]).toLowerCase()}` : '',
          c.added ? h('span', { class: 'tiny' }, ' in più nella settimana') : c.instead ? h('span', { class: 'tiny' }, ` al posto di ${EX[c.instead].name.toLowerCase()}`) : null)))
        : h('p', { class: 'small muted' }, 'Per ora il piano usa il corpo libero e gli oggetti di casa. Aggiungi un attrezzo per vedere cosa cambia.'),
      h('button', { class: 'btn ghost block', style: { marginTop: '10px' }, onClick: () => go('programma') }, 'Vedi le sessioni'));
  };
  fillSummary();
  main.append(summary, equipmentEditor(fillSummary),
    h('p', { class: 'tiny', style: { marginTop: '14px' } }, 'Prezzi indicativi rilevati online a ottobre 2026; possono variare. Nella Guida trovi l’ordine consigliato per gli acquisti.'));
}

export function equipmentSummary(state) {
  const names = [];
  for (const k in EQUIP) {
    if (!state.settings.eq[k] || EQUIP[k].group === 'casa') continue;
    const w = (state.settings.weights || {})[k];
    names.push(Array.isArray(w) && w.length ? `${EQUIP[k].name} ${w.map((x) => String(x).replace('.', ',')).join('/')} kg` : EQUIP[k].name);
  }
  return names.length ? names.join(', ') : 'Corpo libero e oggetti di casa';
}
