// Forma — impostazioni: attrezzatura, preferenze, audio, tema, backup.
import * as store from '../store.js';
import { equipmentSummary } from './equipment.js';
import { initFigures } from '../figures.js';
import { h, icon, segmented, toggle, sheet, toast, confirmDialog, fmtDate } from '../ui.js';
import { shareBackup, copyText, isNative, speak } from '../native.js';

export function renderSettings(ctx) {
  const { top, main, render } = ctx;
  const s = store.get();
  const set = (fn, rerender = false) => { store.update((st) => fn(st.settings)); if (rerender) render(); };
  top.append(
    h('a', { class: 'icon-btn', href: '#/oggi', 'aria-label': 'Torna a Oggi' }, icon('back')),
    h('h1', {}, 'Impostazioni'));

  // ---------- attrezzatura e figura ----------
  main.appendChild(h('section', {}, h('h2', { class: 'h2' }, 'Attrezzatura'),
    h('a', { class: 'row-link', href: '#/attrezzatura' }, h('span', {}, h('b', {}, 'Cosa hai in casa'), h('span', { class: 'small muted', style: { display: 'block' } }, equipmentSummary(s))), icon('chevron'))));
  main.appendChild(h('section', { class: 'section' }, h('h2', { class: 'h2' }, 'Dimostrazioni'),
    toggle('Modello 3D realistico', s.settings.figure3d !== false, async (v) => {
      set((x) => { x.figure3d = v; });
      const mode = await initFigures(v);
      if (v && mode !== '3d') toast('Questo dispositivo non supporta il modello 3D: uso le figure essenziali.');
      render();
    }, 'Atleta in 3D con i muscoli che lavorano evidenziati. Spegnilo per le figure essenziali, più leggere per la batteria.')));

  // ---------- sessioni ----------
  main.appendChild(h('section', { class: 'section' }, h('h2', { class: 'h2' }, 'Sessioni'),
    toggle('Finisher', s.settings.finisher, (v) => set((x) => { x.finisher = v; }), 'Circa 4 minuti a ritmo alto in alcune sessioni, dalla fase 2.'),
    toggle('Niente salti', s.settings.noJumps, (v) => set((x) => { x.noJumps = v; }), 'Finisher senza salti, per chi abita in condominio.'),
    toggle('Defaticamento', s.settings.cooldown, (v) => set((x) => { x.cooldown = v; }), 'Due minuti di allungamento e respirazione a fine sessione.')));

  // ---------- audio ----------
  main.appendChild(h('section', { class: 'section' }, h('h2', { class: 'h2' }, 'Guida vocale e segnali'),
    toggle('Voce', s.settings.voice, (v) => { set((x) => { x.voice = v; }); if (v) speak('La voce è attiva.'); }, 'Annuncia esercizi, ripetizioni e recuperi.'),
    toggle('Suoni', s.settings.sound, (v) => set((x) => { x.sound = v; }), 'Bip negli ultimi 3 secondi dei timer.'),
    toggle('Vibrazione', s.settings.vibe, (v) => set((x) => { x.vibe = v; }), 'Alla fine dei timer e al cambio di lato.'),
    isNative ? h('p', { class: 'tiny' }, 'Se la voce non parla, installa la voce italiana del motore di sintesi vocale di Android (Impostazioni del telefono, Lingue, Sintesi vocale).') : null));

  // ---------- tema ----------
  main.appendChild(h('section', { class: 'section' }, h('h2', { class: 'h2' }, 'Tema'),
    segmented([['auto', 'Automatico'], ['light', 'Chiaro'], ['dark', 'Scuro']], s.settings.theme, (v) => { set((x) => { x.theme = v; }); ctx.applyTheme(); }, { label: 'Tema' })));

  // ---------- dati ----------
  const dSec = h('section', { class: 'section' }, h('h2', { class: 'h2' }, 'I tuoi dati'),
    h('p', { class: 'small muted' }, `I dati restano solo su questo telefono. ${s.history.length} sessioni, ${s.tests.length} test, ${s.measures.length} misurazioni.`),
    h('div', { style: { display: 'grid', gap: '10px', marginTop: '12px' } },
      h('button', {
        class: 'btn ghost block',
        onClick: async () => {
          const name = `forma-backup-${new Date().toISOString().slice(0, 10)}.json`;
          try {
            const how = await shareBackup(store.exportJSON(), name);
            toast(how === 'downloaded' ? 'Backup scaricato' : 'Scegli dove salvare il backup');
          } catch {
            const ok = await copyText(store.exportJSON());
            toast(ok ? 'Backup copiato negli appunti' : 'Impossibile esportare');
          }
        },
      }, 'Esporta backup'),
      h('button', { class: 'btn ghost block', onClick: () => importSheet(render) }, 'Importa backup'),
      h('button', {
        class: 'btn ghost block', style: { color: 'var(--danger)' },
        onClick: async () => {
          if (await confirmDialog('Cancella storico, test, misure e livelli e riparte dall’inizio. Esporta prima un backup se vuoi conservarli.', { ok: 'Cancella tutto', danger: true, title: 'Ricominciare da zero?' })) {
            store.reset();
            ctx.go('oggi');
          }
        },
      }, 'Ricomincia da zero')));
  if (s.settings.parq) dSec.appendChild(h('p', { class: 'tiny', style: { marginTop: '12px' } }, `Questionario di sicurezza compilato il ${fmtDate(s.settings.parq.at)}.`));
  main.appendChild(dSec);
  main.appendChild(h('p', { class: 'tiny', style: { marginTop: '30px' } }, 'Forma 1.0. Font Big Shoulders Display e Atkinson Hyperlegible Next, licenza SIL Open Font.'));
}

function importSheet(render) {
  const file = h('input', { type: 'file', accept: 'application/json,.json,text/plain', id: 'imp-file' });
  const ta = h('textarea', { id: 'imp-text', placeholder: 'Oppure incolla qui il testo del backup' });
  const body = h('div', {},
    h('p', { class: 'muted' }, 'Il backup sostituisce i dati attuali su questo telefono.'),
    h('div', { class: 'field' }, h('label', { for: 'imp-file' }, 'File di backup'), file),
    h('div', { class: 'field' }, h('label', { for: 'imp-text' }, 'Testo del backup'), ta),
    h('div', { class: 'row-actions' }, h('button', { class: 'btn primary block', onClick: () => doImport() }, 'Importa')));
  const sh = sheet(body, { title: 'Importa backup' });
  async function doImport() {
    let text = ta.value.trim();
    if (!text && file.files && file.files[0]) text = await file.files[0].text();
    if (!text) { toast('Scegli un file o incolla il testo.'); return; }
    try {
      store.importJSON(text);
      sh.close();
      toast('Backup importato');
      render();
    } catch (e) {
      toast(e.message && e.message.includes('Forma') ? e.message : 'Il testo non è un backup valido.');
    }
  }
}
