// Forma — scheda "Programma": fasi, sessioni della settimana, livelli.
import * as store from '../store.js';
import { EX, hasEquipment } from '../data/exercises.js';
import { LADDERS, PHASES, CYCLES, MAINTENANCE } from '../data/program.js';
import { phaseForWeek, previewSessions, weeklySetsByRole, availableIndex, loadLabel } from '../engine.js';
import { h, icon, tier, segmented, sheet, toast } from '../ui.js';
import { equipmentSummary } from './equipment.js';

export function renderProgram(ctx) {
  const { top, main, render } = ctx;
  const s = store.get();
  top.append(h('h1', {}, 'Programma'));
  const info = phaseForWeek(s.progress.week);
  const mant = s.settings.mode === 'mant';

  // ---------- modalità e frequenza ----------
  main.append(
    h('div', { style: { display: 'grid', gap: '10px' } },
      segmented([['prog', 'Progressione'], ['mant', 'Mantenimento']], s.settings.mode, (v) => { store.update((st) => { st.settings.mode = v; }); render(); }, { label: 'Modalità' }),
      mant ? null : segmented([[2, '2 giorni'], [3, '3 giorni'], [4, '4 giorni']], s.settings.days, (v) => { store.update((st) => { st.settings.days = v; st.progress.inWeek = Math.min(st.progress.inWeek, v - 1); }); render(); }, { label: 'Giorni a settimana' })),
    h('p', { class: 'small muted', style: { marginTop: '8px' } }, mant ? MAINTENANCE.desc : s.settings.days === 2
      ? 'Con 2 giorni le sessioni A e B ricevono una serie in più sugli esercizi principali.'
      : s.settings.days === 4 ? 'Il quarto giorno è una sessione breve dedicata a glutei e femorali.' : 'Tre sessioni complete a settimana, a giorni alterni.'));

  // ---------- attrezzatura ----------
  main.appendChild(h('a', { class: 'row-link', href: '#/attrezzatura', style: { marginTop: '14px' } },
    h('span', {}, h('b', {}, 'Attrezzatura'), h('span', { class: 'small muted', style: { display: 'block' } }, equipmentSummary(s))),
    h('span', { class: 'linkish' }, 'Cambia')));

  // ---------- fasi ----------
  if (!mant) {
    const tl = h('ol', { class: 'timeline' });
    PHASES.forEach((ph, k) => {
      const done = ph.to != null && s.progress.week > ph.to;
      const now = ph.id === info.phase.id;
      const weeks = ph.to ? `settimane ${ph.from}–${ph.to}` : `dalla settimana ${ph.from}, cicli di 6 settimane`;
      const extra = now && info.cycle ? h('div', { class: 'tl-goal' }, h('b', {}, `Ciclo ${info.cycleNo}, ${info.cycle.name}: `), info.cycle.desc) : null;
      tl.appendChild(h('li', { class: done ? 'done' : now ? 'now' : '' },
        h('span', { class: 'dot' }, done ? icon('check') : String(k + 1)),
        h('div', {},
          h('div', { class: 'tl-name' }, ph.name),
          h('div', { class: 'tl-weeks' }, now ? `${weeks}, ora sei alla settimana ${s.progress.week}` : weeks),
          h('div', { class: 'tl-goal' }, ph.goal),
          now ? h('div', { class: 'tl-goal' }, h('b', {}, 'Come: '), ph.how) : null,
          extra)));
    });
    main.appendChild(h('section', { class: 'section' }, h('h2', { class: 'h2' }, 'Le fasi'), tl,
      h('button', { class: 'linkish', onClick: () => changeWeek(s, render) }, 'Cambia settimana del programma')));
  }

  // ---------- volume settimanale ----------
  const vol = weeklySetsByRole(s);
  main.appendChild(h('section', { class: 'section' },
    h('h2', { class: 'h2' }, 'Serie a settimana'),
    h('div', { class: 'vol' }, [['glutei', 'Glutei e femorali'], ['gambe', 'Gambe'], ['spinta', 'Spinta'], ['tirata', 'Tirata'], ['core', 'Core']].map(([k, l]) =>
      h('div', {}, h('span', { class: 'num' }, String(vol[k])), h('span', {}, l)))),
    h('p', { class: 'small muted', style: { marginTop: '8px' } }, 'Per la crescita muscolare la letteratura indica circa 10 o più serie settimanali per gruppo muscolare: qui la priorità va a glutei e gambe.')));

  // ---------- sessioni ----------
  const sessions = previewSessions(s);
  const sec = h('section', { class: 'section' }, h('h2', { class: 'h2' }, 'Le sessioni di questa fase'));
  for (const k in sessions) {
    const ss = sessions[k];
    const box = h('div', { class: 'sess' },
      h('div', { class: 'sess-head' }, h('span', { class: 'display' }, `Sessione ${k}`), h('span', { class: 'muted' }, `circa ${ss.est} min`)));
    const ul = h('ul', { class: 'today-list', style: { marginTop: '6px' } });
    ss.blocks.forEach((b) => {
      ul.appendChild(h('li', { class: 'blk' }, `${b.name}, recupero ${b.rest} s`));
      b.items.forEach((it) => {
        const ex = EX[it.ex];
        ul.appendChild(h('li', {},
          tier(LADDERS[it.ladder].list.indexOf(it.ex), LADDERS[it.ladder].list.length),
          h('a', { class: 'nm', href: `#/esercizio/${it.ex}`, style: { color: 'inherit', textDecoration: 'none' } }, ex.name, it.load ? h('small', { class: 'ld' }, loadLabel(it.load, ex)) : null),
          h('span', { class: 'sx' }, `${it.sets} × ${it.range[0]}–${it.range[1]}${ex.type === 'time' ? ' s' : ''}${ex.uni ? '/lato' : ''}`)));
      });
    });
    if (ss.finisher) ul.appendChild(h('li', {}, h('span', { class: 'nm' }, ss.finisher.name), h('span', { class: 'sx' }, 'facoltativo')));
    box.appendChild(ul);
    sec.appendChild(box);
  }
  main.appendChild(sec);

  // ---------- livelli ----------
  const lv = h('section', { class: 'section' },
    h('h2', { class: 'h2' }, 'Livelli'),
    h('p', { class: 'small muted', style: { marginBottom: '8px' } }, 'Salgono da soli quando completi la fascia. Se una variante è troppo facile o crea fastidio, cambiala qui.'));
  for (const key in LADDERS) {
    const L = LADDERS[key];
    const idx = availableIndex(key, s.levels[key] ?? 0, s.settings.eq);
    if (idx < 0) continue;
    const ex = EX[L.list[idx]];
    const row = h('div', { class: 'lv-row' },
      tier(idx, L.list.length),
      h('div', { class: 'nm' }, h('b', {}, L.name), ex.name),
      h('button', { class: 'icon-btn', 'aria-label': `Livello precedente per ${L.name}`, onClick: () => shift(key, -1) }, icon('minus')),
      h('button', { class: 'icon-btn', 'aria-label': `Livello successivo per ${L.name}`, onClick: () => shift(key, 1) }, icon('plus')));
    lv.appendChild(row);
  }
  main.appendChild(lv);

  function shift(key, dir) {
    const L = LADDERS[key];
    const eq = s.settings.eq;
    let k = availableIndex(key, s.levels[key] ?? 0, eq) + dir;
    while (k >= 0 && k < L.list.length && !hasEquipment(L.list[k], eq)) k += dir;
    if (k < 0 || k >= L.list.length) { toast(dir > 0 ? 'È già il livello più alto disponibile con la tua attrezzatura.' : 'È già il primo livello.'); return; }
    store.update((st) => { st.levels[key] = k; });
    toast(`${L.name}: ${EX[L.list[k]].name}`);
    render();
  }
}

function changeWeek(s, render) {
  const opts = [
    [1, 'Settimana 1, Fondamenta'],
    [5, 'Settimana 5, Costruzione'],
    [11, 'Settimana 11, Intensificazione'],
    [17, 'Settimana 17, Cicli'],
  ];
  const sh = sheet(h('div', {},
    h('p', { class: 'muted' }, 'Se arrivi da un periodo di allenamento costante puoi partire più avanti. I livelli degli esercizi non cambiano.'),
    h('div', { class: 'variant' }, opts.map(([w, label]) => h('button', {
      type: 'button',
      class: s.progress.week >= w && (opts.find((o) => o[0] > w) || [999])[0] > s.progress.week ? 'on' : '',
      onClick: () => {
        store.update((st) => { st.progress.week = w; st.progress.inWeek = 0; st.progress.testWeek = null; });
        sh.close();
        toast(label);
        render();
      },
    }, label)))), { title: 'Da dove riparti?' });
}

export { CYCLES };
