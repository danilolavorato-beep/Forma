// Forma — scheda "Guida": come funziona, cosa dice la ricerca, attrezzatura, sicurezza, bibliografia.
import { CREDITS, REFS, REF_LINKS, HOW, EVIDENCE, TONE, EQUIPMENT_STAGES, PRICE_NOTE, PRICE_REFS, SAFETY } from '../data/guide.js';
import { PHASES, CYCLES } from '../data/program.js';
import { h, icon } from '../ui.js';

const ORDER = Object.keys(REFS);
const num = (key) => ORDER.indexOf(key) + 1;
const cite = (keys) => h('div', { class: 'src' }, `Fonti: ${keys.map((k) => `[${num(k)}]`).join(' ')}`);

function section(title, open, ...body) {
  return h('details', { class: 'g', open: open || null },
    h('summary', {}, title, icon('chevron')),
    h('div', { class: 'g-body' }, ...body));
}

export function renderGuide(ctx) {
  const { top, main } = ctx;
  top.append(h('h1', {}, 'Guida'));
  main.appendChild(h('p', { class: 'lead', style: { marginBottom: '16px' } }, 'Un programma per rassodare tutto il corpo con priorità a gambe e glutei, in 30–45 minuti, a casa. Ogni scelta qui sotto ha un riferimento nella letteratura scientifica.'));

  main.appendChild(section('Come funziona', true,
    h('div', { class: 'prose' }, HOW.map((p) => h('p', {}, p)))));

  main.appendChild(section('Le fasi del programma', false,
    h('ol', { class: 'timeline', style: { marginTop: '6px' } }, PHASES.map((ph, k) => h('li', {},
      h('span', { class: 'dot' }, String(k + 1)),
      h('div', {},
        h('div', { class: 'tl-name' }, ph.name),
        h('div', { class: 'tl-weeks' }, ph.to ? `Settimane ${ph.from}–${ph.to}` : `Dalla settimana ${ph.from}`),
        h('div', { class: 'tl-goal' }, ph.goal),
        h('div', { class: 'tl-goal' }, ph.how),
        ph.id === 'f4' ? h('ul', { class: 'cues', style: { marginTop: '6px' } }, CYCLES.map((c) => h('li', {}, h('b', {}, `${c.name}: `), c.desc))) : null))))));

  main.appendChild(section('Cosa dice la ricerca', false,
    EVIDENCE.map((e) => h('div', { class: 'ev' },
      h('h4', {}, e.t),
      h('p', {}, e.p),
      h('p', { class: 'small', style: { marginTop: '6px' } }, h('b', {}, 'Nell’app: '), e.app),
      cite(e.refs)))));

  main.appendChild(section('Rassodare: muscolo, grasso e abitudini', false,
    h('div', { class: 'prose' }, TONE.map((p) => h('p', {}, p))),
    cite(['wewege22', 'ramirez13', 'who20', 'morton18'])));

  main.appendChild(section('Attrezzatura consigliata', false,
    EQUIPMENT_STAGES.map((st) => h('div', { style: { marginBottom: '14px' } },
      h('h3', { class: 'h3', style: { margin: '6px 0 4px' } }, st.t),
      st.items.map(([name, price, desc]) => h('div', { class: 'eq-row' }, h('b', {}, name), h('span', { class: 'price' }, price), h('p', {}, desc))))),
    h('p', { class: 'tiny' }, PRICE_NOTE), cite(PRICE_REFS)));

  main.appendChild(section('Sicurezza', false,
    h('ul', { class: 'cues' }, SAFETY.map((p) => h('li', {}, p)))));

  main.appendChild(section('Bibliografia', false,
    h('p', { class: 'tiny' }, CREDITS),
    h('ol', { class: 'refs' }, ORDER.map((k) => h('li', { id: `ref-${k}` }, REFS[k],
      REF_LINKS[k] ? [' ', h('a', { href: REF_LINKS[k], target: '_blank', rel: 'noopener', 'aria-label': `Apri la fonte ${num(k)}` }, 'Apri la fonte')] : null)))));
}
