// Forma — libreria degli esercizi con animazioni e indicazioni tecniche.
import * as store from '../store.js';
import { EX, EQUIP, hasEquipment } from '../data/exercises.js';
import { ANIMS } from '../data/anims.js';
import { LADDERS } from '../data/program.js';
import { availableIndex, implFor, loadLabel, loadFor } from '../engine.js';
import { createFigure } from '../figures.js';
import { h, icon, tier, toast } from '../ui.js';

const FILTERS = [
  ['tutti', 'Tutti'],
  ['glutei', 'Glutei'],
  ['gambe', 'Gambe'],
  ['femorali', 'Femorali'],
  ['spinta', 'Spinta'],
  ['tirata', 'Tirata'],
  ['core', 'Core'],
  ['mobilita', 'Mobilità e cardio'],
];

let currentFilter = 'tutti';
let observer = null;

function ladderOf(exId) {
  for (const k in LADDERS) {
    const i = LADDERS[k].list.indexOf(exId);
    if (i >= 0) return { key: k, idx: i, L: LADDERS[k] };
  }
  return null;
}

export function renderLibrary(ctx) {
  const { top, main } = ctx;
  const s = store.get();
  top.append(h('h1', {}, 'Esercizi'));
  const chips = h('div', { class: 'chips', role: 'tablist', 'aria-label': 'Filtra per gruppo' });
  const grid = h('div', { class: 'ex-grid' });
  FILTERS.forEach(([id, label]) => {
    const c = h('button', { class: `chip ${currentFilter === id ? 'on' : ''}`, role: 'tab', 'aria-selected': String(currentFilter === id) }, label);
    c.addEventListener('click', () => { currentFilter = id; chips.querySelectorAll('.chip').forEach((x) => { x.classList.remove('on'); x.setAttribute('aria-selected', 'false'); }); c.classList.add('on'); c.setAttribute('aria-selected', 'true'); fill(); });
    chips.appendChild(c);
  });
  main.append(chips, grid);

  if (observer) observer.disconnect();
  observer = 'IntersectionObserver' in window ? new IntersectionObserver((entries) => {
    entries.forEach((e) => { const f = e.target._fig; if (!f) return; if (e.isIntersecting) f.play(); else f.stop(); });
  }, { rootMargin: '40px' }) : null;

  function fill() {
    while (grid.firstChild) grid.removeChild(grid.firstChild);
    const ids = Object.keys(EX).filter((id) => {
      const c = EX[id].cat;
      if (currentFilter === 'tutti') return true;
      if (currentFilter === 'mobilita') return c === 'mobilita' || c === 'cardio';
      return c === currentFilter;
    });
    ids.forEach((id) => {
      const ex = EX[id];
      const lad = ladderOf(id);
      const ok = hasEquipment(id, s.settings.eq);
      const wrap = h('div', { class: 'fig-wrap' });
      const fig = createFigure(ANIMS[ex.anim], { aspect: 1.3, autoplay: !observer, label: ex.name, ex, impl: implFor(s, id) });
      wrap.appendChild(fig.svg);
      wrap._fig = fig;
      const meta = lad ? `${lad.L.name}, livello ${lad.idx + 1}` : ex.cat === 'cardio' ? 'Finisher' : 'Riscaldamento e defaticamento';
      const card = h('a', { class: `ex-card ${ok ? '' : 'locked'}`, href: `#/esercizio/${id}` }, wrap,
        h('span', { class: 'nm' }, ex.name),
        h('span', { class: 'meta' }, ok ? meta : `Serve: ${missing(id, s.settings.eq)}`));
      grid.appendChild(card);
      if (observer) observer.observe(wrap);
    });
  }
  fill();
}

function missing(id, eq) {
  const ex = EX[id];
  return (ex.eq || []).filter((g) => !g.some((k) => eq[k])).map((g) => g.map((k) => EQUIP[k].name.toLowerCase()).join(' o ')).join(', ');
}

export function renderExercise(ctx, id) {
  const { top, main, render } = ctx;
  const ex = EX[id];
  const s = store.get();
  top.append(
    h('a', { class: 'icon-btn', href: '#/esercizi', 'aria-label': 'Torna agli esercizi' }, icon('back')),
    h('h1', { style: { fontSize: '28px' } }, ex ? ex.name : 'Esercizio'));
  if (!ex) { main.appendChild(h('p', {}, 'Esercizio non trovato.')); return; }
  const hero = h('div', { class: 'ex-hero' });
  const fig = createFigure(ANIMS[ex.anim], { aspect: 1.35, label: `Dimostrazione: ${ex.name}`, ex, impl: implFor(store.get(), id) });
  hero.appendChild(fig.svg);
  main.appendChild(hero);
  const unit = ex.type === 'time' ? 'secondi' : 'ripetizioni';
  main.appendChild(h('div', { style: { marginTop: '14px' } },
    h('span', { class: 'pill' }, ex.muscles),
    h('span', { class: 'pill' }, `${ex.range[0]}–${ex.range[1]} ${unit}${ex.uni ? ' per lato' : ''}`),
    ex.tempo ? h('span', { class: 'pill' }, `tempo ${ex.tempo}`) : null,
    (ex.eq || []).map((g) => h('span', { class: 'pill' }, g.map((k) => EQUIP[k].name).join(' o ')))));
  main.appendChild(h('section', { class: 'section' }, h('h2', { class: 'h2' }, 'Come si fa'), h('ol', { class: 'cues' }, ex.cues.map((c) => h('li', {}, c)))));
  if (ex.errors.length) main.appendChild(h('section', { class: 'section' }, h('h2', { class: 'h2' }, 'Errori da evitare'), h('ul', { class: 'cues' }, ex.errors.map((c) => h('li', {}, c)))));

  const lad = ladderOf(id);
  if (lad) {
    const cur = availableIndex(lad.key, s.levels[lad.key] ?? 0, s.settings.eq);
    const list = h('ol', { class: 'ladder' }, lad.L.list.map((xid, k) => {
      const ok = hasEquipment(xid, s.settings.eq);
      return h('li', { class: `${k === cur ? 'cur' : ''} ${ok ? '' : 'na'}` },
        tier(k, lad.L.list.length),
        h('a', { class: 'nm', href: `#/esercizio/${xid}`, style: { color: 'inherit', textDecoration: k === lad.idx ? 'underline' : 'none' } }, EX[xid].name),
        k === cur ? h('span', { class: 'tiny' }, 'attuale') : ok ? null : h('span', { class: 'tiny' }, 'attrezzo'));
    }));
    const sec = h('section', { class: 'section' }, h('h2', { class: 'h2' }, `Progressione: ${lad.L.name}`), list);
    if (cur !== lad.idx && hasEquipment(id, s.settings.eq)) {
      sec.appendChild(h('button', {
        class: 'btn ghost block', style: { marginTop: '12px' },
        onClick: () => { store.update((st) => { st.levels[lad.key] = lad.idx; }); toast(`${lad.L.name}: ora usi ${ex.name}`); render(); },
      }, 'Usa questa variante nelle sessioni'));
    }
    main.appendChild(sec);
  }
}
