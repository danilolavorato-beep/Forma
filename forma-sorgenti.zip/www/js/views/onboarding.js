// Forma — primo avvio: presentazione, sicurezza, frequenza, attrezzatura.
import * as store from '../store.js';
import { equipmentEditor } from './equipment.js';
import { ANIMS } from '../data/anims.js';
import { PARQ } from '../data/guide.js';
import { createFigure } from '../figures.js';
import { h, clear, segmented, toggle } from '../ui.js';

export function renderOnboarding(app, done) {
  const s = store.get();
  const answers = s.settings.parq ? [...s.settings.parq.answers] : PARQ.map(() => null);
  let step = 0;
  const STEPS = 4;

  const view = h('div', { class: 'onb' });
  app.appendChild(view);
  let fig = null;

  function draw() {
    if (fig) fig.stop();
    fig = null;
    clear(view);
    view.appendChild(h('div', { class: 'onb-steps', 'aria-hidden': 'true' }, Array.from({ length: STEPS }, (_, k) => h('span', { class: k <= step ? 'on' : '' }))));
    const body = h('div', { class: 'grow' });
    view.appendChild(body);
    const btns = h('div', { class: 'btns' });
    view.appendChild(btns);

    if (step === 0) {
      const box = h('div', { class: 'hero-fig' });
      fig = createFigure(ANIMS.bss, { aspect: 1.5, label: 'Dimostrazione: squat bulgaro', muscles: ['glutes', 'quads'] });
      box.appendChild(fig.svg);
      body.append(box,
        h('h1', {}, 'Forma'),
        h('p', { class: 'lead' }, 'Allenamento a casa per rassodare tutto il corpo, con priorità a gambe e glutei. Sessioni da 30–45 minuti che diventano più impegnative man mano che migliori.'),
        h('p', { class: 'muted', style: { marginTop: '12px' } }, 'Bastano una sedia, il divano e uno zaino. Se hai elastici, pesi, sbarra, cinghie o fitball, il piano li usa.'));
      btns.appendChild(h('button', { class: 'btn primary big block', onClick: () => { step = 1; draw(); } }, 'Iniziamo'));
    }

    if (step === 1) {
      body.append(h('h1', {}, 'Prima, la sicurezza'),
        h('p', { class: 'muted' }, 'Sette domande ispirate al questionario PAR‑Q+. Le risposte restano sul telefono.'));
      const list = h('ul', { class: 'parq' });
      PARQ.forEach((q, k) => {
        const yn = h('div', { class: 'yn', role: 'radiogroup', 'aria-label': q });
        [['Sì', true], ['No', false]].forEach(([lbl, val]) => {
          const b = h('button', { type: 'button', role: 'radio', 'aria-checked': String(answers[k] === val), class: answers[k] === val ? 'on' : '' }, lbl);
          b.addEventListener('click', () => { answers[k] = val; draw(); });
          yn.appendChild(b);
        });
        list.appendChild(h('li', {}, h('span', {}, q), yn));
      });
      body.appendChild(list);
      const anyYes = answers.some((a) => a === true);
      const complete = answers.every((a) => a !== null);
      if (anyYes) {
        body.appendChild(h('div', { class: 'note warn' }, h('span', {}, 'Hai risposto sì ad almeno una domanda: prima di iniziare parlane con il tuo medico o con uno specialista in medicina dello sport, che può indicarti cosa evitare. Puoi proseguire per esplorare l’app.')));
      }
      btns.append(
        h('button', { class: 'btn primary big block', disabled: !complete || null, onClick: () => { store.update((st) => { st.settings.parq = { answers, at: Date.now() }; }); step = 2; draw(); } }, complete ? 'Continua' : 'Rispondi a tutte le domande'),
        h('button', { class: 'linkish', onClick: () => { step = 0; draw(); } }, 'Indietro'));
    }

    if (step === 2) {
      body.append(h('h1', {}, 'Quanto tempo hai'),
        h('p', { class: 'muted', style: { marginBottom: '14px' } }, 'Giorni a settimana. Tre è il punto di partenza consigliato; con due ottieni comunque risultati.'),
        segmented([[2, '2 giorni'], [3, '3 giorni'], [4, '4 giorni']], s.settings.days, (v) => store.update((st) => { st.settings.days = v; }), { label: 'Giorni a settimana' }),
        h('p', { class: 'muted', style: { margin: '22px 0 14px' } }, 'Durata abituale della sessione. Potrai cambiarla ogni volta.'),
        segmented([[false, 'Completa, 30–45 min'], [true, 'Rapida, 15–25 min']], s.settings.quick, (v) => store.update((st) => { st.settings.quick = v; }), { label: 'Durata' }));
      btns.append(h('button', { class: 'btn primary big block', onClick: () => { step = 3; draw(); } }, 'Continua'), h('button', { class: 'linkish', onClick: () => { step = 1; draw(); } }, 'Indietro'));
    }

    if (step === 3) {
      body.append(h('h1', {}, 'Cosa hai in casa'),
        h('p', { class: 'muted', style: { marginBottom: '6px' } }, 'Attiva quello che hai già. Puoi aggiornarlo quando compri qualcosa.'));
      body.appendChild(equipmentEditor());
      btns.append(
        h('button', { class: 'btn primary big block', onClick: () => { store.update((st) => { st.settings.onboarded = true; }); if (fig) fig.stop(); done(); } }, 'Vai al test iniziale'),
        h('button', { class: 'linkish', onClick: () => { step = 2; draw(); } }, 'Indietro'));
    }
    window.scrollTo(0, 0);
  }
  draw();
}
