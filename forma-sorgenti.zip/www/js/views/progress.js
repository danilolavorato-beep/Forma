// Forma — scheda "Progressi": test, costanza, misure, storico.
import * as store from '../store.js';
import { EX } from '../data/exercises.js';
import { MEASURES } from '../data/program.js';
import { DAY } from '../engine.js';
import { lineChart, barChart } from '../charts.js';
import { h, sheet, fmtDate, toast, confirmDialog } from '../ui.js';

const TEST_ROWS = [
  { id: 'squat', name: 'Squat', unit: 'rip', get: (t) => t.squat },
  { id: 'bridge', name: 'Ponte su una gamba', unit: 'rip', get: (t) => (t.bridgeR == null && t.bridgeL == null ? null : Math.min(t.bridgeR ?? Infinity, t.bridgeL ?? Infinity)), note: 'lato più debole' },
  { id: 'push', name: 'Piegamenti', unit: 'rip', get: (t) => t.push, variant: true },
  { id: 'plank', name: 'Plank', unit: 's', get: (t) => t.plank },
];

export function renderProgress(ctx) {
  const { top, main, render } = ctx;
  const s = store.get();
  top.append(h('h1', {}, 'Progressi'));

  // ---------- test ----------
  const tSec = h('section', {}, h('h2', { class: 'h2' }, 'Test'));
  if (!s.tests.length) {
    tSec.appendChild(h('p', { class: 'muted' }, 'Nessun test ancora. Il primo test si avvia dalla schermata Oggi; poi si ripete nelle settimane leggere.'));
  } else {
    const grid = h('div', { class: 'test-grid' });
    TEST_ROWS.forEach((row) => {
      const all = s.tests.filter((t) => row.get(t) != null && isFinite(row.get(t)));
      const lastT = all[all.length - 1];
      if (!lastT) return;
      // per i piegamenti il confronto ha senso solo a parità di variante
      const series = row.variant ? all.filter((t) => t.pushVariant === lastT.pushVariant) : all;
      const first = series[0];
      const v = row.get(lastT);
      const d = series.length > 1 ? v - row.get(first) : null;
      const card = h('div', { class: 'test-card' },
        h('div', { class: 'lbl' }, row.variant ? EX[lastT.pushVariant || 'pushup'].name : row.name),
        h('div', { class: 'big' }, String(v), h('small', {}, row.unit)),
        d != null ? h('div', { class: `delta ${d > 0 ? 'pos' : d < 0 ? 'neg' : ''}` }, `${d > 0 ? '+' : ''}${d} dal ${fmtDate(first.at, false, true)}`) : h('div', { class: 'tiny' }, `Test del ${fmtDate(lastT.at, false, true)}${row.note ? `, ${row.note}` : ''}`));
      if (series.length > 1) card.appendChild(lineChart(series.map((t) => ({ x: t.at, y: row.get(t), label: fmtDate(t.at) })), { width: 160, height: 44, spark: true, unit: row.unit }));
      grid.appendChild(card);
    });
    tSec.appendChild(grid);
  }
  main.appendChild(tSec);

  // ---------- costanza ----------
  const weeks = 10;
  const now = new Date();
  const dow = (now.getDay() + 6) % 7;
  now.setHours(0, 0, 0, 0);
  const monday = now.getTime() - dow * DAY;
  const bars = [];
  for (let k = weeks - 1; k >= 0; k--) {
    const from = monday - k * 7 * DAY;
    const n = s.history.filter((x) => x.at >= from && x.at < from + 7 * DAY).length;
    bars.push({ label: k === 0 ? 'ora' : fmtDate(from).split(' ')[0], full: k === 0 ? 'Questa settimana' : `Settimana del ${fmtDate(from)}`, value: n });
  }
  const target = s.settings.mode === 'mant' ? 2 : s.settings.days;
  let streak = 0;
  for (let k = bars.length - 2; k >= 0; k--) { if (bars[k].value >= target) streak++; else break; }
  if (bars[bars.length - 1].value >= target) streak++;
  const cap = h('p', { class: 'chart-cap' }, `La linea indica l’obiettivo di ${target} sessioni. Tocca una colonna per il dettaglio.`);
  main.appendChild(h('section', { class: 'section' },
    h('div', { class: 'kv' }, h('h2', { class: 'h2' }, 'Costanza'), h('span', { class: 'muted' }, `${s.history.length} sessioni totali`)),
    s.history.length ? h('p', { class: 'muted', style: { marginBottom: '8px' } }, streak > 1 ? `${streak} settimane di fila con l’obiettivo raggiunto.` : 'La costanza conta più di ogni altra variabile: punta a non saltare due sessioni di fila.') : null,
    barChart(bars, { target, caption: cap, unit: 'sessioni' }), cap));

  // ---------- misure ----------
  const mSec = h('section', { class: 'section' },
    h('div', { class: 'kv' }, h('h2', { class: 'h2' }, 'Misure'), h('button', { class: 'linkish', onClick: () => addMeasures(render) }, 'Aggiungi')));
  if (!s.measures.length) {
    mSec.appendChild(h('p', { class: 'muted' }, 'Il metro racconta il rassodamento meglio della bilancia: misura vita, fianchi e coscia ogni 2–4 settimane, al mattino, nelle stesse condizioni.'));
  } else {
    const grid = h('div', { class: 'test-grid' });
    MEASURES.forEach((m) => {
      const series = s.measures.filter((x) => x[m.id] != null);
      if (!series.length) return;
      const last = series[series.length - 1];
      const first = series[0];
      const d = series.length > 1 ? Math.round((last[m.id] - first[m.id]) * 10) / 10 : null;
      const card = h('div', { class: 'test-card' },
        h('div', { class: 'lbl' }, m.name),
        h('div', { class: 'big' }, String(last[m.id]).replace('.', ','), h('small', {}, m.unit)),
        d != null ? h('div', { class: 'delta' }, `${d > 0 ? '+' : ''}${String(d).replace('.', ',')} dal ${fmtDate(first.at, false, true)}`) : h('div', { class: 'tiny' }, fmtDate(last.at, false, true)));
      if (series.length > 1) card.appendChild(lineChart(series.map((x) => ({ x: x.at, y: x[m.id], label: fmtDate(x.at) })), { width: 160, height: 44, spark: true, unit: m.unit }));
      grid.appendChild(card);
    });
    mSec.appendChild(grid);
  }
  main.appendChild(mSec);

  // ---------- storico ----------
  const hSec = h('section', { class: 'section' }, h('h2', { class: 'h2' }, 'Storico'));
  if (!s.history.length) hSec.appendChild(h('p', { class: 'muted' }, 'Le sessioni completate compariranno qui.'));
  s.history.slice(0, 60).forEach((x) => {
    const rows = (x.items || []).map((it) => {
      const ex = EX[it.ex];
      if (!ex) return null;
      const vals = it.v.map((v, k) => (v == null ? '–' : it.vL && it.vL[k] != null ? `${v}/${it.vL[k]}` : String(v))).join(' · ');
      return h('tr', {}, h('td', {}, ex.name, it.pain ? ' (dolore)' : ''), h('td', { class: 'v' }, `${vals}${ex.type === 'time' ? ' s' : ''}${it.rir != null ? `, riserva ${it.rir}` : ''}`));
    });
    hSec.appendChild(h('details', { class: 'hist-item' },
      h('summary', {},
        h('span', { class: 't' }, x.title),
        h('span', { class: 'd' }, fmtDate(x.at)),
        h('span', { class: 'd' }, `${x.phaseName || ''}${x.light ? ', settimana leggera' : ''}`),
        h('span', { class: 'd' }, `${Math.round((x.dur || 0) / 60)} min${x.rpe ? `, fatica ${x.rpe}/10` : ''}`)),
      rows.length ? h('table', {}, h('tbody', {}, rows)) : null,
      x.note ? h('p', { class: 'small muted', style: { marginBottom: '10px' } }, x.note) : null,
      h('button', {
        class: 'linkish', style: { color: 'var(--danger)', marginBottom: '10px' },
        onClick: async () => {
          if (await confirmDialog('La sessione viene tolta dallo storico. I livelli raggiunti restano invariati.', { ok: 'Elimina', danger: true, title: 'Eliminare la sessione?' })) {
            store.update((st) => { st.history = st.history.filter((y) => y.id !== x.id); });
            render();
          }
        },
      }, 'Elimina questa sessione')));
  });
  main.appendChild(hSec);
}

function addMeasures(render) {
  const s = store.get();
  const last = s.measures[s.measures.length - 1] || {};
  const inputs = {};
  const body = h('div', {},
    MEASURES.map((m) => {
      const id = `m-${m.id}`;
      inputs[m.id] = h('input', { id, type: 'number', inputmode: 'decimal', step: String(m.step), min: '0', placeholder: last[m.id] != null ? String(last[m.id]) : m.unit });
      return h('div', { class: 'field' }, h('label', { for: id }, `${m.name} (${m.unit})`), inputs[m.id], m.how ? h('span', { class: 'tiny' }, m.how) : null);
    }),
    h('div', { class: 'row-actions' }, h('button', { class: 'btn primary block', onClick: () => sh.close('save') }, 'Salva le misure')));
  const sh = sheet(body, {
    title: 'Nuove misure',
    onClose: (v) => {
      if (v !== 'save') return;
      const entry = { at: Date.now() };
      let any = false;
      for (const k in inputs) {
        const raw = inputs[k].value.replace(',', '.').trim();
        if (raw === '') continue;
        const n = parseFloat(raw);
        if (isFinite(n) && n > 0) { entry[k] = Math.round(n * 10) / 10; any = true; }
      }
      if (!any) { toast('Nessuna misura inserita.'); return; }
      store.update((st) => { st.measures.push(entry); });
      toast('Misure salvate');
      render();
    },
  });
}
