// Forma — schermata "Oggi": la prossima sessione e la settimana.
import * as store from '../store.js';
import { EX } from '../data/exercises.js';
import { ANIMS } from '../data/anims.js';
import { LADDERS } from '../data/program.js';
import { buildSession, phaseForWeek, phaseLabel, weekSummary, isTestDue, daysSince, implFor, loadLabel } from '../engine.js';
import { createFigure } from '../figures.js';
import { h, icon, tier, fmtRelDay, GIORNI_BREVI, sheet, segmented } from '../ui.js';
import { startWorkout, decisionRow } from './player.js';

export function renderHome(ctx) {
  const { top, main } = ctx;
  const s = store.get();
  top.append(
    h('span', { class: 'wordmark' }, 'Forma'),
    h('a', { class: 'icon-btn', href: '#/impostazioni', 'aria-label': 'Impostazioni' }, icon('impostazioni')));

  let forced = null; // sessione scelta a mano
  const live = store.loadLive();
  if (live && live.session) {
    main.appendChild(h('div', { class: 'note warn', style: { marginTop: '0', marginBottom: '14px' } }, icon('info'),
      h('div', {}, h('b', {}, 'Allenamento in sospeso. '), 'Riaprilo per continuare da dove eri rimasto.',
        h('div', {}, h('button', { class: 'linkish', onClick: () => startWorkout(live.session, { resume: live }) }, 'Riprendi')))));
  }

  // ---------- fase e settimana ----------
  const mant = s.settings.mode === 'mant';
  const info = phaseForWeek(s.progress.week);
  const phaseBox = h('div', {});
  if (mant) {
    phaseBox.append(h('div', { class: 'phase-line' }, h('span', { class: 'phase-name' }, 'Mantenimento'), h('span', { class: 'muted small' }, '2 sessioni a settimana')));
  } else {
    const ph = info.phase;
    let total; let cur;
    if (info.cycle) { total = 6; cur = info.cycleWeek; } else { total = ph.to - ph.from + 1; cur = info.weekInPhase; }
    phaseBox.append(
      h('div', { class: 'phase-line' },
        h('span', { class: 'phase-name' }, phaseLabel(info)),
        h('span', { class: 'muted small' }, `settimana ${cur} di ${total}`)),
      h('div', { class: 'weeks', 'aria-hidden': 'true' }, Array.from({ length: total }, (_, k) => {
        const w = k + 1;
        const isLight = info.cycle ? w === 6 : ph.light.includes(ph.from + k);
        return h('span', { class: `${w < cur ? 'done' : w === cur ? 'now' : ''} ${isLight ? 'light' : ''}` });
      })));
  }
  main.appendChild(phaseBox);

  // ---------- prossima sessione ----------
  const card = h('section', { class: 'today', 'aria-label': 'Prossima sessione' });
  main.appendChild(card);

  const draw = () => {
    while (card.firstChild) card.removeChild(card.firstChild);
    const session = forced ? buildSession(s, { key: forced, test: false }) : buildSession(s);
    const quick = buildSession(s, { key: session.key, test: session.kind === 'test', quick: true });
    const figBox = h('div', { class: 'today-fig' });
    const firstEx = session.kind === 'test' ? session.tests[0].ex : (session.blocks[0].items.find((x) => x.main) || session.blocks[0].items[0]).ex;
    const fig = createFigure(ANIMS[EX[firstEx].anim], { aspect: 1.9, label: `Dimostrazione: ${EX[firstEx].name}`, ex: EX[firstEx], impl: implFor(s, firstEx) });
    figBox.appendChild(fig.svg);
    card.appendChild(figBox);

    const body = h('div', { class: 'today-body' });
    body.appendChild(h('div', { class: 'today-title' },
      h('h2', { class: 'display' }, session.kind === 'test' ? (session.initial ? 'Test iniziale' : 'Test') : session.title),
      h('span', { class: 'today-meta' }, `circa ${session.est} min`)));
    if (session.kind === 'test') {
      body.appendChild(h('p', { class: 'muted', style: { marginTop: '6px' } }, session.note));
      body.appendChild(h('ul', { class: 'today-list' }, session.tests.map((t) => h('li', {}, h('span', { class: 'nm' }, t.name), h('span', { class: 'sx' }, t.unit)))));
    } else {
      const list = h('ul', { class: 'today-list' });
      session.blocks.forEach((b) => {
        list.appendChild(h('li', { class: 'blk' }, `${b.name}, ${b.rounds} giri, recupero ${b.rest} s`));
        b.items.forEach((it) => {
          const ex = EX[it.ex];
          const lv = LADDERS[it.ladder];
          list.appendChild(h('li', {},
            tier(lv.list.indexOf(it.ex), lv.list.length),
            h('span', { class: 'nm' }, ex.name, it.load ? h('small', { class: 'ld' }, loadLabel(it.load, ex)) : null),
            h('span', { class: 'sx' }, `${it.sets} × ${it.range[0]}–${it.range[1]}${ex.type === 'time' ? ' s' : ''}${ex.uni ? '/lato' : ''}`)));
        });
      });
      if (session.finisher) list.appendChild(h('li', {}, h('span', { class: 'nm' }, session.finisher.name), h('span', { class: 'sx' }, `${Math.round((session.finisher.rounds * session.finisher.moves.length * (session.finisher.work + session.finisher.rest)) / 60)} min`)));
      body.appendChild(list);
    }
    if (session.kind === 'workout') {
      body.appendChild(h('div', { style: { margin: '14px 0 12px' } }, segmented(
        [[false, `Completa, ${session.est} min`], [true, `Rapida, ${quick.est} min`]],
        !!s.settings.quick,
        (v) => { store.update((st) => { st.settings.quick = v; }); draw(); },
        { label: 'Durata della sessione' })));
    }
    const notes = [];
    if (session.comeback) notes.push(['warn', `Sono passati ${daysSince(s)} giorni dall’ultima sessione: oggi si riparte con una sessione più leggera.`]);
    else if (session.light && session.kind === 'workout') notes.push(['', session.note]);
    else if (session.kind === 'workout' && info.weekInPhase === 1 && !mant) notes.push(['', `${info.phase.name}: ${info.phase.how}`]);
    if (session.trimmed) notes.push(['', session.trimmed]);
    notes.forEach(([tone, txt]) => body.appendChild(h('div', { class: `note ${tone}` }, icon('info'), h('span', {}, txt))));
    body.appendChild(h('button', {
      class: 'btn primary big block', style: { marginTop: '16px' },
      onClick: () => { fig.stop(); startWorkout(s.settings.quick && session.kind === 'workout' ? quick : session); },
    }, icon('play'), session.kind === 'test' ? 'Inizia il test' : 'Inizia l’allenamento'));
    const alt = h('div', { style: { display: 'flex', justifyContent: 'space-between', marginTop: '6px' } });
    if (session.kind === 'test') {
      alt.appendChild(h('button', {
        class: 'linkish',
        onClick: () => {
          store.update((st) => {
            if (!st.tests.length) st.progress.testSkipped = true;
            st.progress.testWeek = st.progress.week;
          });
          draw();
        },
      }, 'Salta il test per ora'));
    } else {
      alt.appendChild(h('button', { class: 'linkish', onClick: () => chooseSession(s, (k) => { forced = k; draw(); }) }, 'Scegli un’altra sessione'));
    }
    body.appendChild(alt);
    card.appendChild(body);
  };
  draw();

  // ---------- settimana ----------
  const wk = weekSummary(s);
  const dots = h('div', { class: 'week-dots' }, wk.days.map((d, k) => h('div', { class: d.today ? 'today-mark' : '' },
    h('span', {}, GIORNI_BREVI[k]),
    h('i', { class: d.n ? 'on' : '', 'aria-label': d.n ? 'allenamento fatto' : 'nessun allenamento' }, d.n ? icon('check') : ''))));
  main.appendChild(h('section', { class: 'section', 'aria-label': 'Questa settimana' },
    h('div', { class: 'kv', style: { marginBottom: '10px' } }, h('h2', { class: 'h2' }, 'Questa settimana'), h('span', { class: 'muted' }, `${wk.done} di ${wk.target}`)),
    dots));

  // ---------- ultima sessione ----------
  const last = s.history[0];
  if (last) {
    const sec = h('section', { class: 'section', 'aria-label': 'Ultima sessione' },
      h('h2', { class: 'h2' }, 'Ultima sessione'),
      h('p', { class: 'muted' }, `${last.title}, ${fmtRelDay(last.at)}, ${Math.round(last.dur / 60)} min${last.rpe ? `, fatica ${last.rpe}/10` : ''}`));
    const dec = (last.decisions || []).filter((d) => d.tone !== 'hold').slice(0, 4);
    dec.forEach((d) => sec.appendChild(decisionRow(d)));
    main.appendChild(sec);
  } else {
    main.appendChild(h('section', { class: 'section' },
      h('h2', { class: 'h2' }, 'Come funziona'),
      h('p', { class: 'muted' }, 'Ogni esercizio ha una fascia di ripetizioni. Quando completi il massimo della fascia in tutte le serie, la sessione successiva propone una variante più difficile. Dopo l’ultima serie ti chiedo quante ripetizioni ti restavano: serve a regolare l’obiettivo della volta dopo.'),
      h('a', { class: 'linkish', href: '#/guida' }, 'Leggi la guida')));
  }
}

function chooseSession(s, onPick) {
  const keys = s.settings.mode === 'mant' ? ['A', 'B'] : ['A', 'B', 'C', 'D'].slice(0, s.settings.days);
  const body = h('div', {},
    h('p', { class: 'muted' }, 'Puoi fare un’altra sessione della settimana: la rotazione riprenderà dalla successiva.'),
    h('div', { class: 'variant' }, keys.map((k) => {
      const sess = buildSession(s, { key: k, test: false });
      const names = sess.blocks.flatMap((b) => b.items.filter((x) => x.main).map((x) => EX[x.ex].name)).join(', ');
      return h('button', { type: 'button', onClick: () => { sh.close(); onPick(k); } }, `Sessione ${k}, ${sess.est} min`, h('div', { class: 'tiny' }, names));
    })));
  const sh = sheet(body, { title: 'Scegli la sessione' });
}
