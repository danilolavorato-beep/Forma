// Forma — player dell'allenamento: guida passo per passo con timer, voce e registrazione delle serie.
import * as store from '../store.js';
import { EX } from '../data/exercises.js';
import { ANIMS } from '../data/anims.js';
import { TESTS } from '../data/program.js';
import { flatten, completeSession, buildSession, SWITCH_SECS } from '../engine.js';
import { createFigure } from '../figures.js';
import { h, clear, icon, sheet, stepper, fmtClock, minuti, tier } from '../ui.js';
import { LADDERS } from '../data/program.js';
import { availableIndex, implFor, loadLabel } from '../engine.js';
import { keepAwake, vibrate, beep, speak, stopSpeaking, unlockAudio } from '../native.js';

let P = null;
let root = null;
let tickTimer = 0;
let figApi = null;
let miniApi = null;

export function isPlaying() { return !!P; }

const repsWord = (n) => (n === 1 ? 'ripetizione' : 'ripetizioni');

function exName(id) { return EX[id] ? EX[id].name : id; }

function targetText(st) {
  const ex = EX[st.ex];
  const side = ex.uni ? ' per lato' : '';
  if (st.type === 'time' || ex.type === 'time') return `${st.target ?? st.secs} secondi${side}`;
  return `${st.target} ${repsWord(st.target)}${side}`;
}

function setsDone() { return P.steps.filter((s, k) => s.t === 'set' && k < P.i).length; }

// ---------------- avvio, ripresa, chiusura ----------------
export function startWorkout(session, { resume = null } = {}) {
  if (P) return;
  unlockAudio();
  const steps = flatten(session);
  P = {
    session, steps,
    i: resume ? resume.i : 0,
    log: resume ? resume.log : { items: {}, tests: {} },
    started: resume ? resume.started : Date.now(),
    pausedTotal: resume ? resume.pausedTotal || 0 : 0,
    pausedAt: null,
    stepStart: Date.now(),
    phase: 'idle',
    side: 'R',
    sideVals: {},
    extra: 0,
    spoke10: false,
    lastTick: -1,
  };
  document.body.classList.add('in-workout');
  root = h('div', { class: 'player', role: 'dialog', 'aria-label': session.title });
  document.body.appendChild(root);
  keepAwake(true);
  history.pushState({ forma: 'player' }, '');
  window.addEventListener('popstate', onPop);
  tickTimer = setInterval(tick, 200);
  enterStep();
}

function persist() {
  if (!P) return;
  store.saveLive({ session: P.session, i: P.i, log: P.log, started: P.started, pausedTotal: P.pausedTotal, at: Date.now() });
}

function teardown() {
  clearInterval(tickTimer);
  window.removeEventListener('popstate', onPop);
  if (figApi) figApi.stop();
  if (miniApi) miniApi.stop();
  figApi = miniApi = null;
  stopSpeaking();
  keepAwake(false);
  document.body.classList.remove('in-workout');
  if (root) root.remove();
  root = null;
  P = null;
}

function onPop() {
  if (!P) return;
  history.pushState({ forma: 'player' }, '');
  askExit();
}

export function handleBack() {
  if (!P) return false;
  askExit();
  return true;
}

async function askExit() {
  if (!P || P.asking) return;
  P.asking = true;
  pause(true);
  const done = Object.keys(P.log.items).length;
  const body = h('div', { class: 'confirm' },
    h('p', {}, done ? 'Le serie registrate finora vengono salvate e contano per la progressione.' : 'Non hai ancora registrato serie.'),
    h('div', { class: 'row-actions', style: { flexDirection: 'column' } },
      h('button', { class: 'btn primary block', onClick: () => { s.close(); } }, 'Continua l’allenamento'),
      done ? h('button', { class: 'btn ghost block', onClick: () => { s.close('save'); } }, 'Salva ed esci') : null,
      h('button', { class: 'btn ghost block', onClick: () => { s.close('discard'); } }, 'Esci senza salvare')));
  const s = sheet(body, {
    title: 'Interrompere?',
    onClose: (v) => {
      if (!P) return;
      P.asking = false;
      if (v === 'save') finish(true);
      else if (v === 'discard') { store.clearLive(); teardown(); history.back(); location.hash = '#/oggi'; }
      else pause(false);
    },
  });
}

export function resumeIfInterrupted() {
  const live = store.loadLive();
  if (!live || !live.session) return;
  if (Date.now() - (live.at || 0) > 12 * 3600 * 1000) { store.clearLive(); return; }
  const body = h('div', { class: 'confirm' },
    h('p', {}, `${live.session.title}: eri al passo ${live.i + 1}. Vuoi riprendere da lì?`),
    h('div', { class: 'row-actions' },
      h('button', { class: 'btn ghost', onClick: () => s.close('no') }, 'Scarta'),
      h('button', { class: 'btn primary', onClick: () => s.close('yes') }, 'Riprendi')));
  const s = sheet(body, {
    title: 'Allenamento in sospeso',
    onClose: (v) => {
      if (v === 'yes') startWorkout(live.session, { resume: live });
      else if (v === 'no') store.clearLive();
    },
  });
}

// ---------------- tempo ----------------
function now() { return Date.now(); }
function elapsedStep() {
  const end = P.pausedAt || now();
  return (end - P.stepStart) / 1000;
}
function pause(on) {
  if (!P) return;
  if (on && !P.pausedAt) { P.pausedAt = now(); stopSpeaking(); }
  else if (!on && P.pausedAt) {
    const d = now() - P.pausedAt;
    P.stepStart += d;
    P.pausedTotal += d;
    P.pausedAt = null;
  }
  updatePauseButton();
}
function updatePauseButton() {
  const b = root && root.querySelector('[data-pause]');
  if (!b) return;
  clear(b).append(icon(P.pausedAt ? 'play' : 'pause'));
  b.setAttribute('aria-label', P.pausedAt ? 'Riprendi' : 'Pausa');
}

// durata del passo corrente in secondi (per i passi a tempo)
function stepDuration(st) {
  if (st.t === 'gap') return st.secs + P.extra;
  if (st.t === 'follow') return EX[st.ex].uni ? st.secs * 2 : st.secs;
  if (st.t === 'interval') return st.secs;
  if (st.t === 'set' && st.type === 'time') return st.target;
  return null;
}

function tick() {
  if (!P || P.pausedAt) return;
  const st = P.steps[P.i];
  if (!st) return;
  const el = root.querySelector('[data-count]');
  const bar = root.querySelector('[data-fill]');
  if (P.phase === 'countdown') {
    const left = 3 - Math.floor(elapsedStep());
    if (left !== P.lastTick && left > 0) { P.lastTick = left; beep('tick'); }
    if (el) el.textContent = String(Math.max(1, left));
    if (left <= 0) {
      beep('go'); vibrate(120);
      P.phase = st.t === 'test' ? 'stopwatch' : 'running';
      P.stepStart = now(); P.lastTick = -1; renderStep();
    }
    return;
  }
  if (P.phase === 'stopwatch') {
    if (el) el.textContent = fmtClock(elapsedStep());
    return;
  }
  if (P.phase === 'switch') {
    const left = Math.ceil(SWITCH_SECS - elapsedStep());
    if (el) el.textContent = String(Math.max(0, left));
    if (left <= 3 && left > 0 && left !== P.lastTick) { P.lastTick = left; beep('tick'); }
    if (left <= 0) { P.lastTick = -1; beep('go'); vibrate(120); afterSwitch(); }
    return;
  }
  const dur = stepDuration(st);
  if (dur == null || P.phase !== 'running') return;
  const left = dur - elapsedStep();
  const shown = Math.max(0, Math.ceil(left));
  if (el) el.textContent = st.t === 'follow' ? fmtClock(shown) : String(shown);
  if (st.t === 'follow' && EX[st.ex].uni && !P.switched && elapsedStep() >= dur / 2) {
    P.switched = true; beep('go'); vibrate(150); speak('Cambia lato');
  }
  if (bar) bar.style.width = `${Math.min(100, (1 - left / dur) * 100)}%`;
  if (st.t === 'gap' && st.kind === 'rest' && !P.spoke10 && left <= 10 && left > 9 && dur > 20) {
    P.spoke10 = true;
    if (st.next) speak(`Preparati: ${exName(st.next.ex || (st.next.test && st.next.test.ex))}`);
  }
  if (shown <= 3 && shown > 0 && shown !== P.lastTick) { P.lastTick = shown; beep('tick'); }
  if (left <= 0) {
    P.lastTick = -1;
    if (st.t === 'set') { beep('end'); vibrate(300); timedSideDone(); }
    else { beep(st.t === 'gap' ? 'go' : 'end'); vibrate(st.t === 'gap' ? 150 : 250); next(); }
  }
}

// ---------------- navigazione tra i passi ----------------
function enterStep() {
  const st = P.steps[P.i];
  if (!st) { finish(false); return; }
  P.stepStart = now();
  P.pausedAt = null;
  P.extra = 0;
  P.spoke10 = false;
  P.lastTick = -1;
  P.side = 'R';
  P.sideVals = {};
  P.switched = false;
  if (st.t === 'gap' || st.t === 'follow' || st.t === 'interval') P.phase = 'running';
  else P.phase = 'idle';
  persist();
  renderStep();
  announce(st);
}

function next() {
  P.i += 1;
  enterStep();
}

function announce(st) {
  if (st.t === 'set') {
    const ex = EX[st.ex];
    let txt = `${ex.name}. ${targetText(st)}`;
    if (st.load && st.setNo === 1) txt += `, ${loadLabel(st.load, ex).replace(',', ' virgola ')}`;
    if (st.push) txt += '. Ultima serie: fino al cedimento tecnico.';
    if (ex.uni) txt += '. Inizia con il lato destro.';
    speak(txt);
  } else if (st.t === 'follow' || st.t === 'interval') {
    speak(exName(st.ex));
  } else if (st.t === 'gap') {
    if (st.kind === 'rest') speak(`Recupero, ${st.secs} secondi.`);
    else if (st.kind === 'block') speak(`Cambio blocco. Prossimo: ${st.next ? exName(st.next.ex || (st.next.test && st.next.test.ex)) : ''}`);
    else if (st.kind === 'move' && st.next) speak(`Ora: ${exName(st.next.ex)}`);
    else if (st.kind === 'interval') speak('Recupero');
  } else if (st.t === 'test') {
    speak(`Test: ${st.test.name}`);
  }
}

// ---------------- disegno ----------------
function progressBar() {
  const sets = P.steps.filter((s) => s.t === 'set' || s.t === 'test');
  const current = P.steps[P.i];
  const doneCount = P.steps.slice(0, P.i).filter((s) => s.t === 'set' || s.t === 'test').length;
  const bar = h('div', { class: 'p-bar', 'aria-hidden': 'true' });
  sets.forEach((s, k) => {
    const cls = k < doneCount ? 'done' : k === doneCount && (current && (current.t === 'set' || current.t === 'test')) ? 'now' : '';
    bar.appendChild(h('i', { class: cls }));
  });
  return bar;
}

function whereText(st) {
  if (st.t === 'set') return `${st.block}, giro ${st.round} di ${st.rounds}`;
  if (st.t === 'follow') return st.part === 'warmup' ? `Riscaldamento ${st.n} di ${st.of}` : `Defaticamento ${st.n} di ${st.of}`;
  if (st.t === 'interval') return `Finisher ${st.n} di ${st.of}`;
  if (st.t === 'test') return `Test ${st.n} di ${st.of}`;
  if (st.t === 'gap') {
    const nx = st.next;
    if (nx && nx.t === 'set') return `${nx.block}, giro ${nx.round} di ${nx.rounds}`;
    return 'Pausa';
  }
  return '';
}

function topBar(st) {
  const sound = store.get().settings;
  const muted = !sound.voice && !sound.sound;
  return h('div', { class: 'p-top' },
    h('button', { class: 'icon-btn', 'aria-label': 'Interrompi', onClick: askExit }, icon('close')),
    h('div', { class: 'p-where' }, whereText(st)),
    h('button', {
      class: 'icon-btn', 'aria-label': muted ? 'Attiva audio' : 'Silenzia',
      onClick: () => {
        store.update((s) => {
          const on = !(s.settings.voice || s.settings.sound);
          s.settings.voice = on; s.settings.sound = on;
        });
        if (!store.get().settings.voice) stopSpeaking();
        renderStep();
      },
    }, icon(muted ? 'mute' : 'sound')));
}

function mountFigure(container, exId, opts = {}) {
  const ex = EX[exId];
  const impl = implFor(store.get(), exId);
  const anim = ANIMS[ex.anim];
  const f = createFigure(anim, { aspect: opts.aspect || 1.3, label: `Dimostrazione: ${ex.name}`, ex, dark: !!opts.dark, impl });
  container.appendChild(f.svg);
  return f;
}

function renderStep() {
  if (!P || !root) return;
  const st = P.steps[P.i];
  if (figApi) figApi.stop();
  if (miniApi) miniApi.stop();
  figApi = miniApi = null;
  clear(root);
  root.classList.toggle('p-rest', st.t === 'gap' && st.kind !== 'move');
  root.append(topBar(st), progressBar());
  if (st.t === 'gap') renderGap(st);
  else if (st.t === 'set') renderSet(st);
  else if (st.t === 'follow') renderFollow(st);
  else if (st.t === 'interval') renderInterval(st);
  else if (st.t === 'test') renderTest(st);
  updatePauseButton();
}

function controls(...btns) { return h('div', { class: 'p-actions' }, ...btns); }
function pauseBtn() {
  return h('button', { class: 'icon-btn', 'data-pause': '', 'aria-label': 'Pausa', onClick: () => pause(!P.pausedAt) }, icon('pause'));
}
function skipBtn(label = 'Salta') {
  return h('button', { class: 'icon-btn', 'aria-label': label, onClick: () => { stopSpeaking(); next(); } }, icon('next'));
}

// ---------- pausa / recupero ----------
function renderGap(st) {
  const main = h('div', { class: 'p-main', style: { justifyContent: 'center' } });
  const info = h('div', { class: 'p-info' });
  const label = st.kind === 'rest' ? 'Recupero' : st.kind === 'block' ? 'Cambio blocco' : st.kind === 'interval' ? 'Recupero' : 'Prossimo esercizio';
  info.append(
    h('div', { class: 'p-kind' }, label),
    h('div', { class: 'p-big', 'data-count': '' }, String(st.secs)),
    h('div', { class: 'p-progress-ring' }, h('i', { 'data-fill': '' })));
  const nx = st.next;
  if (nx && (nx.ex || nx.test)) {
    const exId = nx.ex || nx.test.ex;
    const mini = h('div', { class: 'fig-mini' });
    const card = h('div', { class: 'p-next' }, mini,
      h('div', {},
        h('div', { class: 'tg' }, 'Ora tocca a'),
        h('div', { class: 'nm' }, exName(exId)),
        nx.t === 'set' ? h('div', { class: 'tg' }, `${targetText(nx)}${nx.push ? ', ultima serie al cedimento' : ''}`) : null));
    info.appendChild(card);
    miniApi = mountFigure(mini, exId, { aspect: 1.4, dark: true });
  }
  main.appendChild(info);
  root.appendChild(main);
  root.appendChild(controls(
    pauseBtn(),
    h('button', { class: 'btn ghost', onClick: () => { P.extra += 15; } }, '+15 s'),
    h('button', { class: 'btn primary', onClick: () => { stopSpeaking(); next(); } }, 'Vai')));
}

// ---------- riscaldamento / defaticamento ----------
function renderFollow(st) {
  const ex = EX[st.ex];
  const main = h('div', { class: 'p-main' });
  const figBox = h('div', { class: 'p-fig' });
  main.appendChild(figBox);
  main.appendChild(h('div', { class: 'p-info' },
    h('div', { class: 'p-kind' }, st.part === 'warmup' ? 'Riscaldamento' : 'Defaticamento'),
    h('div', { class: 'p-name' }, ex.name),
    h('div', { class: 'p-big small', 'data-count': '' }, fmtClock(stepDuration(st))),
    h('div', { class: 'p-progress-ring' }, h('i', { 'data-fill': '' })),
    h('p', { class: 'p-cue' }, ex.uni ? `${ex.cues[0]}. Cambia lato a metà tempo.` : ex.cues[0])));
  root.appendChild(main);
  figApi = mountFigure(figBox, st.ex);
  root.appendChild(controls(pauseBtn(), h('button', { class: 'btn primary big', onClick: () => { stopSpeaking(); next(); } }, 'Avanti')));
}

// ---------- serie ----------
function renderSet(st) {
  const ex = EX[st.ex];
  const main = h('div', { class: 'p-main' });
  const figBox = h('div', { class: 'p-fig' });
  main.appendChild(figBox);
  const info = h('div', { class: 'p-info' });
  info.appendChild(h('div', { class: 'p-kind' }, `Serie ${st.setNo} di ${st.sets}`));
  info.appendChild(h('div', { class: 'p-name' }, ex.name));
  if (ex.uni) info.appendChild(h('span', { class: 'p-side' }, P.phase === 'switch' ? 'Ora il lato sinistro' : P.side === 'R' ? 'Lato destro' : 'Lato sinistro'));
  if (st.load) info.appendChild(h('span', { class: 'p-load' }, loadLabel(st.load, ex)));

  if (P.phase === 'switch') {
    info.appendChild(h('div', { class: 'p-big small', 'data-count': '' }, String(SWITCH_SECS)));
    info.appendChild(h('p', { class: 'p-cue strong' }, 'Cambia lato'));
  } else if (st.type === 'time') {
    const big = P.phase === 'countdown' ? '3' : String(P.phase === 'running' ? Math.max(0, Math.ceil(st.target - elapsedStep())) : st.target);
    info.appendChild(h('div', { class: 'p-big', 'data-count': '' }, big));
    info.appendChild(h('div', { class: 'p-unit' }, P.phase === 'countdown' ? 'pronti' : `secondi, fascia ${st.range[0]}–${st.range[1]}`));
    if (P.phase === 'running') info.appendChild(h('div', { class: 'p-progress-ring' }, h('i', { 'data-fill': '' })));
  } else {
    info.appendChild(h('div', { class: 'p-big' }, String(st.target)));
    info.appendChild(h('div', { class: 'p-unit' }, `${repsWord(st.target)}${ex.uni ? ' per lato' : ''}, fascia ${st.range[0]}–${st.range[1]}`));
  }
  const cue = h('p', { class: `p-cue${st.push ? ' strong' : ''}` });
  info.appendChild(cue);
  rotateCues(cue, st);
  main.appendChild(info);
  root.appendChild(main);
  figApi = mountFigure(figBox, st.ex);

  let primary;
  if (P.phase === 'switch') {
    primary = h('button', { class: 'btn primary big', onClick: afterSwitch }, 'Pronto');
  } else if (st.type === 'time') {
    if (P.phase === 'idle') primary = h('button', { class: 'btn primary big', onClick: () => { P.phase = 'countdown'; P.stepStart = now(); renderStep(); } }, icon('play'), 'Inizia');
    else if (P.phase === 'countdown') primary = h('button', { class: 'btn ghost big', disabled: true }, 'Preparati');
    else primary = h('button', { class: 'btn primary big', onClick: () => timedSideDone(true) }, 'Stop');
  } else {
    primary = h('button', { class: 'btn primary big', onClick: repsSideDone }, icon('check'), 'Fatto');
  }
  root.appendChild(controls(
    st.type === 'time' && P.phase === 'running' ? pauseBtn() : h('button', { class: 'icon-btn', 'aria-label': 'Indicazioni', onClick: () => showCues(st.ex) }, icon('info')),
    primary,
    h('button', { class: 'icon-btn', 'aria-label': 'Salta la serie', onClick: skipSet }, icon('next'))));
}

function rotateCues(el, st) {
  const ex = EX[st.ex];
  const phaseNote = P.session.note && st.setNo === 1 && P.session.kind === 'workout' ? [P.session.note] : [];
  const list = st.push ? ['Ultima serie: arriva al cedimento tecnico, poi aggiungi fino a 5 ripetizioni parziali nella metà bassa.'] : [...phaseNote, ...ex.cues];
  let k = 0;
  el.textContent = list[0] || '';
  if (list.length < 2) return;
  const iv = setInterval(() => {
    if (!el.isConnected) { clearInterval(iv); return; }
    k = (k + 1) % list.length;
    el.textContent = list[k];
  }, 6000);
}

function showCues(exId) {
  const ex = EX[exId];
  sheet(h('div', {},
    h('p', { class: 'muted' }, ex.muscles),
    h('h3', { class: 'h3', style: { marginTop: '14px' } }, 'Come si fa'),
    h('ul', { class: 'cues' }, ex.cues.map((c) => h('li', {}, c))),
    ex.errors.length ? h('h3', { class: 'h3', style: { marginTop: '14px' } }, 'Errori da evitare') : null,
    ex.errors.length ? h('ul', { class: 'cues' }, ex.errors.map((c) => h('li', {}, c))) : null), { title: ex.name });
}

function repsSideDone() {
  const st = P.steps[P.i];
  const ex = EX[st.ex];
  if (ex.uni && P.side === 'R') { startSwitch(); return; }
  openLog(st);
}

function timedSideDone(manual = false) {
  const st = P.steps[P.i];
  const ex = EX[st.ex];
  const secs = manual ? Math.round(elapsedStep()) : st.target;
  P.sideVals[P.side] = secs;
  if (ex.uni && P.side === 'R') { startSwitch(); return; }
  P.phase = 'idle';
  openLog(st);
}

function startSwitch() {
  P.phase = 'switch';
  P.stepStart = now();
  P.lastTick = -1;
  speak('Cambia lato');
  vibrate(150);
  renderStep();
}

function afterSwitch() {
  const st = P.steps[P.i];
  P.side = 'L';
  P.phase = st.type === 'time' ? 'countdown' : 'idle';
  P.stepStart = now();
  renderStep();
}

function itemKey(st) { return `${st.bi}-${st.ii}`; }

function recordSet(st, val) {
  const key = itemKey(st);
  const blk = P.session.blocks[st.bi];
  const it = blk.items[st.ii];
  if (!P.log.items[key]) P.log.items[key] = { ladder: it.ladder, ex: it.ex, sets: [], rir: null, pain: false, planned: it.sets, load: it.load || null };
  P.log.items[key].sets[st.setNo - 1] = val;
}

function skipSet() {
  const st = P.steps[P.i];
  recordSet(st, null);
  stopSpeaking();
  next();
}

function openLog(st) {
  const ex = EX[st.ex];
  const isTime = st.type === 'time';
  const unit = isTime ? 's' : 'rip';
  const step = isTime ? 5 : 1;
  const max = isTime ? 600 : 200;
  const valR = isTime ? (P.sideVals.R ?? st.target) : st.target;
  const valL = isTime ? (P.sideVals.L ?? st.target) : st.target;
  const sR = stepper({ value: valR, min: 0, max, step, unit, label: ex.uni ? 'Lato destro' : (isTime ? 'Secondi' : 'Ripetizioni') });
  const sL = ex.uni ? stepper({ value: valL, min: 0, max, step, unit, label: 'Lato sinistro' }) : null;
  let rir = null;
  const rirBox = h('div', {});
  if (st.last) {
    const btns = [0, 1, 2, 3, 4].map((n) => {
      const b = h('button', { type: 'button', 'aria-pressed': 'false' }, n === 4 ? '4+' : String(n));
      b.addEventListener('click', () => {
        rir = n;
        btns.forEach((x) => { x.classList.remove('on'); x.setAttribute('aria-pressed', 'false'); });
        b.classList.add('on');
        b.setAttribute('aria-pressed', 'true');
      });
      return b;
    });
    rirBox.append(
      h('h3', { class: 'h3', style: { marginTop: '18px' } }, 'Quante ripetizioni ti restavano?'),
      h('div', { class: 'rir', role: 'group', 'aria-label': 'Ripetizioni in riserva' }, btns),
      h('div', { class: 'rir-legend' }, h('span', {}, 'al limite'), h('span', {}, 'facile')));
  }
  const painId = 'pain';
  const pain = st.last ? h('label', { class: 'pain', for: painId }, h('input', { type: 'checkbox', id: painId }), 'Ho sentito dolore, non solo fatica') : null;
  const body = h('div', {},
    h('div', { class: 'log-sides' }, sR.el, sL ? sL.el : null),
    rirBox, pain,
    h('div', { class: 'row-actions' },
      h('button', { class: 'btn primary big block', onClick: () => s.close('save') }, 'Salva e continua')));
  const s = sheet(body, {
    title: `Serie ${st.setNo} di ${st.sets}`,
    dismissable: false,
    onClose: (v) => {
      if (v !== 'save') return;
      const val = { v: sR.value };
      if (sL) val.vL = sL.value;
      recordSet(st, val);
      const key = itemKey(st);
      if (st.last) {
        P.log.items[key].rir = rir;
        P.log.items[key].pain = !!(pain && pain.querySelector('input').checked);
      }
      vibrate(60);
      next();
    },
  });
}

// ---------- finisher ----------
function renderInterval(st) {
  const ex = EX[st.ex];
  const main = h('div', { class: 'p-main' });
  const figBox = h('div', { class: 'p-fig' });
  main.appendChild(figBox);
  main.appendChild(h('div', { class: 'p-info' },
    h('div', { class: 'p-kind' }, 'Finisher: ritmo sostenuto'),
    h('div', { class: 'p-name' }, ex.name),
    h('div', { class: 'p-big', 'data-count': '' }, String(st.secs)),
    h('div', { class: 'p-progress-ring' }, h('i', { 'data-fill': '' })),
    h('p', { class: 'p-cue' }, ex.cues[0])));
  root.appendChild(main);
  figApi = mountFigure(figBox, st.ex);
  root.appendChild(controls(pauseBtn(), h('button', { class: 'btn ghost big', onClick: () => { stopSpeaking(); next(); } }, 'Salta')));
}

// ---------- test ----------
function renderTest(st) {
  const t = st.test;
  const tests = P.log.tests;
  const exId = t.variant ? (tests.pushVariant || 'pushup') : t.ex;
  const ex = EX[exId];
  const main = h('div', { class: 'p-main' });
  const figBox = h('div', { class: 'p-fig' });
  main.appendChild(figBox);
  const info = h('div', { class: 'p-info' });
  info.append(h('div', { class: 'p-kind' }, 'Test'), h('div', { class: 'p-name' }, t.variant ? 'Piegamenti' : t.name));
  if (t.sides) info.appendChild(h('span', { class: 'p-side' }, P.side === 'R' ? 'Lato destro' : 'Lato sinistro'));
  if (P.phase === 'countdown') {
    info.append(h('div', { class: 'p-big', 'data-count': '' }, '3'), h('div', { class: 'p-unit' }, 'pronti'));
  } else if (P.phase === 'stopwatch') {
    info.append(h('div', { class: 'p-big small', 'data-count': '' }, '0:00'), h('div', { class: 'p-unit' }, t.kind === 'time' ? 'tieni la posizione' : 'conta le ripetizioni'));
  } else {
    info.appendChild(h('p', { class: 'p-cue', style: { minHeight: '0', marginTop: '10px' } }, t.how));
    if (t.variant) {
      const box = h('div', { class: 'variant', role: 'radiogroup', 'aria-label': 'Variante' });
      t.variant.forEach((v) => {
        const b = h('button', { type: 'button', role: 'radio', 'aria-checked': String(exId === v), class: exId === v ? 'on' : '' }, EX[v].name);
        b.addEventListener('click', () => { tests.pushVariant = v; renderStep(); });
        box.appendChild(b);
      });
      info.appendChild(box);
    }
  }
  main.appendChild(info);
  root.appendChild(main);
  figApi = mountFigure(figBox, exId);

  let primary;
  if (P.phase === 'idle') {
    primary = h('button', { class: 'btn primary big', onClick: () => { if (t.variant && !tests.pushVariant) tests.pushVariant = 'pushup'; P.phase = 'countdown'; P.stepStart = now(); renderStep(); } }, icon('play'), 'Inizia');
  } else if (P.phase === 'countdown') {
    primary = h('button', { class: 'btn ghost big', disabled: true }, 'Preparati');
  } else {
    primary = h('button', { class: 'btn primary big', onClick: () => testDone(st) }, t.kind === 'time' ? 'Stop' : 'Ho finito');
  }
  root.appendChild(controls(
    h('button', { class: 'icon-btn', 'aria-label': 'Indicazioni', onClick: () => showCues(exId) }, icon('info')),
    primary,
    h('button', { class: 'icon-btn', 'aria-label': 'Salta il test', onClick: () => { stopSpeaking(); next(); } }, icon('next'))));
}

function testDone(st) {
  const t = st.test;
  const secs = Math.round(elapsedStep());
  P.phase = 'idle';
  const isTime = t.kind === 'time';
  const sp = stepper({ value: isTime ? secs : 10, min: 0, max: t.max, step: 1, unit: isTime ? 's' : 'rip', label: isTime ? 'Secondi' : 'Ripetizioni' });
  const s = sheet(h('div', {},
    h('p', { class: 'muted' }, isTime ? 'Correggi se hai fermato il cronometro in ritardo.' : 'Conta solo le ripetizioni complete e con buona tecnica.'),
    sp.el,
    h('div', { class: 'row-actions' }, h('button', { class: 'btn primary big block', onClick: () => s.close('ok') }, 'Salva'))), {
    title: t.sides ? (P.side === 'R' ? 'Lato destro' : 'Lato sinistro') : t.name,
    dismissable: false,
    onClose: () => {
      const v = sp.value;
      if (t.id === 'bridge') {
        if (P.side === 'R') {
          P.log.tests.bridgeR = v;
          P.side = 'L';
          speak('Riposa un minuto, poi lato sinistro.');
          P.phase = 'idle';
          renderStep();
          return;
        }
        P.log.tests.bridgeL = v;
      } else P.log.tests[t.id] = v;
      if (t.id === 'push' && !P.log.tests.pushVariant) P.log.tests.pushVariant = 'pushup';
      next();
    },
  });
}

// ---------------- fine ----------------
function finish(partial) {
  const dur = Math.round((now() - P.started - P.pausedTotal) / 1000);
  const session = P.session;
  const log = { items: {}, tests: P.log.tests, dur };
  for (const k in P.log.items) {
    const it = P.log.items[k];
    const doneSets = it.sets.filter((x) => x && x.v != null).length;
    // in caso di uscita anticipata valutiamo solo gli esercizi completati
    if (!partial || doneSets >= it.planned) log.items[k] = it;
  }
  if (figApi) figApi.stop();
  clearInterval(tickTimer);
  stopSpeaking();
  beep('done');
  speak(session.kind === 'test' ? 'Test completato.' : 'Allenamento completato.');
  vibrate(400);
  showSummary(session, log, partial);
}

function showSummary(session, log, partial) {
  clear(root);
  root.classList.remove('p-rest');
  const items = Object.values(P.log.items);
  const sets = items.reduce((a, it) => a + it.sets.filter((x) => x && x.v != null).length, 0);
  const reps = items.reduce((a, it) => a + it.sets.reduce((b, x) => b + (x && EX[it.ex].type === 'reps' ? (x.v || 0) + (x.vL || 0) : 0), 0), 0);
  let rpe = 7;
  const rpeVal = h('span', { class: 'rpe-val' }, '7');
  const rpeWord = h('span', { class: 'muted' }, rpeLabel(7));
  const range = h('input', { type: 'range', min: 1, max: 10, step: 1, value: 7, class: 'rpe', 'aria-label': 'Fatica della sessione da 1 a 10' });
  range.addEventListener('input', () => { rpe = +range.value; rpeVal.textContent = String(rpe); rpeWord.textContent = rpeLabel(rpe); });
  const note = h('textarea', { rows: 2, placeholder: 'Facoltativa: sensazioni, dolori, cosa cambiare', style: { fontFamily: 'var(--text)', fontSize: '16px', minHeight: '70px' } });
  const isTest = session.kind === 'test';
  const view = h('div', { class: 'p-main', style: { overflowY: 'auto', display: 'block', paddingTop: '20px' } },
    h('div', { class: 'display', style: { fontSize: '54px' } }, partial ? 'Sessione interrotta' : isTest ? 'Test completato' : 'Sessione completata'),
    h('p', { class: 'muted', style: { marginTop: '6px' } }, `${session.title}, ${minuti(Math.max(1, Math.round(log.dur / 60)))}${isTest ? '' : `, ${sets} serie, ${reps} ripetizioni`}`),
    isTest ? testResults(log.tests) : null,
    isTest ? null : h('div', { class: 'section' },
      h('h3', { class: 'h3' }, 'Quanto è stata dura la sessione?'),
      h('div', { style: { display: 'flex', alignItems: 'baseline', gap: '10px', margin: '6px 0' } }, rpeVal, rpeWord),
      range,
      h('div', { class: 'rir-legend' }, h('span', {}, '1 riposante'), h('span', {}, '10 massimale'))),
    h('div', { class: 'field' }, h('label', {}, 'Nota'), note),
    h('div', { class: 'row-actions' }, h('button', {
      class: 'btn primary big block',
      onClick: () => {
        log.rpe = isTest ? null : rpe;
        log.note = note.value.trim();
        let result;
        store.update((s) => { result = completeSession(s, session, log); });
        store.clearLive();
        showDecisions(result, session);
      },
    }, 'Salva')));
  root.appendChild(view);
}

function rpeLabel(n) {
  return ['', 'riposante', 'molto facile', 'facile', 'moderata', 'un po’ dura', 'dura', 'dura, ben fatta', 'molto dura', 'quasi massimale', 'massimale'][n];
}

function testResults(t) {
  const rows = [];
  const s = store.get();
  const prev = s.tests[s.tests.length - 1];
  const fmt = (v, u) => (v == null ? '—' : `${v} ${u}`);
  const delta = (a, b) => (a == null || b == null ? '' : a - b > 0 ? ` (+${a - b})` : a - b < 0 ? ` (${a - b})` : ' (=)');
  rows.push(['Squat', fmt(t.squat, 'rip') + delta(t.squat, prev && prev.squat)]);
  rows.push(['Ponte su una gamba', `${fmt(t.bridgeR, 'dx')}, ${fmt(t.bridgeL, 'sx')}`]);
  rows.push([EX[t.pushVariant || 'pushup'].name, fmt(t.push, 'rip') + (prev && prev.pushVariant === t.pushVariant ? delta(t.push, prev.push) : '')]);
  rows.push(['Plank', fmt(t.plank, 's') + delta(t.plank, prev && prev.plank)]);
  return h('ul', { class: 'list-rows section' }, rows.map(([k, v]) => h('li', { class: 'kv' }, h('span', {}, k), h('b', {}, v))));
}

function showDecisions(result, session) {
  clear(root);
  const list = (result && result.decisions) || [];
  const ups = list.filter((d) => d.tone !== 'hold');
  const holds = list.filter((d) => d.tone === 'hold');
  const view = h('div', { class: 'p-main', style: { overflowY: 'auto', display: 'block', paddingTop: '20px' } },
    h('div', { class: 'display', style: { fontSize: '46px' } }, session.kind === 'test' ? 'Risultati salvati' : 'Prossima volta'),
    session.kind === 'test' && session.initial ? h('p', { class: 'lead', style: { marginTop: '8px' } }, 'Ho scelto i livelli di partenza in base ai test. Puoi cambiarli dalla scheda Programma.') : null,
    session.kind === 'test' && session.initial ? startLevels() : null,
    ups.length ? h('div', { class: 'section' }, ups.map((d) => decisionRow(d))) : null,
    holds.length ? h('div', { class: 'section' }, h('h3', { class: 'h3' }, 'Obiettivi'), holds.map((d) => decisionRow(d))) : null,
    h('div', { class: 'row-actions' }, h('button', { class: 'btn primary big block', onClick: () => { teardown(); history.back(); setTimeout(() => { location.hash = '#/oggi'; window.dispatchEvent(new HashChangeEvent('hashchange')); }, 30); } }, 'Fatto')));
  root.appendChild(view);
}

function startLevels() {
  const s = store.get();
  const box = h('div', { class: 'section' });
  for (const key of ['SQ', 'SPLIT', 'BRIDGE', 'HINGE', 'PUSH', 'PULL', 'ANTIEXT']) {
    const L = LADDERS[key];
    const idx = availableIndex(key, s.levels[key] ?? 0, s.settings.eq);
    if (idx < 0) continue;
    box.appendChild(h('div', { class: 'lv-row' }, tier(idx, L.list.length), h('div', { class: 'nm' }, h('b', {}, L.name), EX[L.list[idx]].name)));
  }
  return box;
}

export function decisionRow(d) {
  const ic = d.tone === 'up' ? 'up' : d.tone === 'down' ? 'down' : d.tone === 'warn' ? 'info' : 'chevron';
  return h('div', { class: `decision ${d.tone}` }, icon(ic), h('span', {}, d.text));
}

export function quickStart(opts = {}) {
  const s = store.get();
  const session = buildSession(s, opts);
  startWorkout(session);
}

export { TESTS };
