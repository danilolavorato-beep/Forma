// Forma — figure 3D animate: stessa interfaccia di createFigure (figure.js), disegnate con il modello.
import { loadModel, getRenderer, uploadModel, renderScene, solidMesh, v3, mulRV, rotFromTo } from './body3d.js';
import { prepareRig, pose3d, boneMatrices, groundOffset, solveWithPose, planeOf } from './pose3d.js';
import { poseAt, cycleLength } from './figure.js';

const MODEL_URL = new URL('../model/atleta.glb', import.meta.url).href;

// ---------------------------------------------------------------- stato condiviso
let ready = null;   // promessa del caricamento
let ctx3 = null;    // { R, rig, model }
export function load3d() {
  if (!ready) {
    ready = (async () => {
      const R = getRenderer();
      const model = await loadModel(MODEL_URL);
      uploadModel(R, model);
      const rig = prepareRig(model);
      ctx3 = { R, rig, model, geo: {} };
      return ctx3;
    })();
  }
  return ready;
}
export const is3dReady = () => !!ctx3 && !ctx3.R.lost;

// ---------------------------------------------------------------- geometrie
function box(w, h, d, cx = 0, cy = 0, cz = 0) {
  const pos = [], nor = [], idx = [];
  const F = [
    [[1, 0, 0], [0, 1, 0], [0, 0, 1]], [[-1, 0, 0], [0, 1, 0], [0, 0, -1]],
    [[0, 1, 0], [0, 0, 1], [1, 0, 0]], [[0, -1, 0], [0, 0, -1], [1, 0, 0]],
    [[0, 0, 1], [1, 0, 0], [0, 1, 0]], [[0, 0, -1], [-1, 0, 0], [0, 1, 0]],
  ];
  const hs = [w / 2, h / 2, d / 2];
  for (const [n, u, v] of F) {
    const b = pos.length / 3;
    for (const [su, sv] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) {
      const p = [0, 1, 2].map((i) => n[i] * hs[i] + u[i] * su * hs[i] + v[i] * sv * hs[i]);
      pos.push(p[0] + cx, p[1] + cy, p[2] + cz); nor.push(...n);
    }
    idx.push(b, b + 1, b + 2, b, b + 2, b + 3);
  }
  return { pos, nor, idx };
}
function cylinder(r, h, seg = 14, cap = true) {
  const pos = [], nor = [], idx = [];
  for (let i = 0; i <= seg; i++) {
    const a = (i / seg) * Math.PI * 2, c = Math.cos(a), s = Math.sin(a);
    pos.push(c * r, 0, s * r, c * r, h, s * r); nor.push(c, 0, s, c, 0, s);
  }
  for (let i = 0; i < seg; i++) { const a = i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
  if (cap) for (const y of [0, h]) {
    const c0 = pos.length / 3; pos.push(0, y, 0); nor.push(0, y ? 1 : -1, 0);
    for (let i = 0; i <= seg; i++) { const a = (i / seg) * Math.PI * 2; pos.push(Math.cos(a) * r, y, Math.sin(a) * r); nor.push(0, y ? 1 : -1, 0); }
    for (let i = 0; i < seg; i++) idx.push(c0, c0 + 1 + i, c0 + 2 + i);
  }
  return { pos, nor, idx };
}
function sphere(r, seg = 16, cx = 0, cy = 0, cz = 0, sy = 1) {
  const pos = [], nor = [], idx = [];
  for (let i = 0; i <= seg; i++) {
    const th = (i / seg) * Math.PI;
    for (let j = 0; j <= seg; j++) {
      const ph = (j / seg) * Math.PI * 2;
      const n = [Math.sin(th) * Math.cos(ph), Math.cos(th), Math.sin(th) * Math.sin(ph)];
      pos.push(cx + n[0] * r, cy + n[1] * r * sy, cz + n[2] * r); nor.push(...n);
    }
  }
  for (let i = 0; i < seg; i++) for (let j = 0; j < seg; j++) {
    const a = i * (seg + 1) + j, b = a + seg + 1;
    idx.push(a, b, a + 1, a + 1, b, b + 1);
  }
  return { pos, nor, idx };
}
function torus(R0, r, seg = 18, tseg = 8, arc = Math.PI * 2, cx = 0, cy = 0, cz = 0) {
  const pos = [], nor = [], idx = [];
  for (let i = 0; i <= seg; i++) {
    const a = (i / seg) * arc;
    for (let j = 0; j <= tseg; j++) {
      const b = (j / tseg) * Math.PI * 2;
      const n = [Math.cos(a) * Math.cos(b), Math.sin(b), Math.sin(a) * Math.cos(b)];
      // anello nel piano XY (manico verticale)
      pos.push(cx + Math.cos(a) * (R0 + r * Math.cos(b)), cy + Math.sin(a) * (R0 + r * Math.cos(b)), cz + r * Math.sin(b));
      nor.push(Math.cos(a) * Math.cos(b), Math.sin(a) * Math.cos(b), Math.sin(b));
    }
  }
  for (let i = 0; i < seg; i++) for (let j = 0; j < tseg; j++) {
    const a = i * (tseg + 1) + j, b = a + tseg + 1;
    idx.push(a, b, a + 1, a + 1, b, b + 1);
  }
  return { pos, nor, idx };
}
function shift(g, x, y, z) {
  const pos = g.pos.slice();
  for (let i = 0; i < pos.length; i += 3) { pos[i] += x; pos[i + 1] += y; pos[i + 2] += z; }
  return { pos, nor: g.nor, idx: g.idx };
}
function merge(list) {
  const out = { pos: [], nor: [], idx: [] };
  for (const g of list) {
    const b = out.pos.length / 3;
    out.pos.push(...g.pos); out.nor.push(...g.nor); out.idx.push(...g.idx.map((i) => i + b));
  }
  return out;
}
function plane(w, d, y) {
  return { pos: [-w, y, -d, w, y, -d, w, y, d, -w, y, d], nor: [0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0], idx: [0, 1, 2, 0, 2, 3] };
}

// matrice modello: base (colonne a,b,c) + traslazione
function mat(a, b, c, t) {
  return new Float32Array([a[0], a[1], a[2], 0, b[0], b[1], b[2], 0, c[0], c[1], c[2], 0, t[0], t[1], t[2], 1]);
}
const ID = mat([1, 0, 0], [0, 1, 0], [0, 0, 1], [0, 0, 0]);
// cilindro unitario (asse Y, altezza 1) tra due punti
function segMatrix(p, q, r = 1) {
  const d = v3.sub(q, p); const L = v3.len(d) || 1e-4; const y = v3.mul(d, 1 / L);
  let x = Math.abs(y[1]) < 0.9 ? v3.norm(v3.cross(y, [0, 1, 0])) : v3.norm(v3.cross(y, [1, 0, 0]));
  const z = v3.cross(x, y);
  return mat(v3.mul(x, r), v3.mul(y, L), v3.mul(z, r), p);
}

function cached(name, make) {
  const c = ctx3.geo;
  if (!c[name]) c[name] = solidMesh(ctx3.R, make());
  return c[name];
}

// ---------------------------------------------------------------- oggetti di scena
function staticProps(anim, rig, g0) {
  const k = rig.k, out = [];
  const sag = planeOf(anim) === 'sagittal';
  const zx = (x) => (sag ? x * k : 0);
  for (const pr of anim.props || []) {
    const key = JSON.stringify(pr) + (sag ? 's' : 'f');
    if (pr.t === 'box' || pr.t === 'table') {
      const top = g0 - pr.y * k, z0 = zx(pr.x), z1 = zx(pr.x + pr.w);
      const wide = pr.t === 'table' ? 9 : (pr.w > 52 ? 9 : 5.2);
      if (pr.t === 'table') {
        out.push({ mesh: cached(key, () => merge([
          box(wide, 0.35, z1 - z0, 0, top - 0.17, (z0 + z1) / 2),
          box(0.35, top - g0, 0.35, -wide / 2 + 0.4, (top + g0) / 2, z0 + 0.4), box(0.35, top - g0, 0.35, wide / 2 - 0.4, (top + g0) / 2, z0 + 0.4),
          box(0.35, top - g0, 0.35, -wide / 2 + 0.4, (top + g0) / 2, z1 - 0.4), box(0.35, top - g0, 0.35, wide / 2 - 0.4, (top + g0) / 2, z1 - 0.4),
        ])), role: 'prop' });
      } else {
        out.push({ mesh: cached(key, () => box(wide, top - g0, z1 - z0, 0, (top + g0) / 2, (z0 + z1) / 2)), role: pr.w > 52 ? 'sofa' : 'prop' });
      }
    } else if (pr.t === 'chair') {
      const seat = g0 - pr.y * k, z0 = zx(pr.x), z1 = zx(pr.x + pr.w), topY = g0 - pr.top * k;
      const bz = pr.back === 'left' ? z0 + 0.2 : z1 - 0.2;
      const w = 4.2;
      out.push({ mesh: cached(key, () => merge([
        box(w, 0.4, z1 - z0, 0, seat - 0.2, (z0 + z1) / 2),
        box(w, topY - seat, 0.35, 0, (topY + seat) / 2, bz),
        ...[[-1, z0 + 0.3], [1, z0 + 0.3], [-1, z1 - 0.3], [1, z1 - 0.3]].map(([s, z]) => box(0.3, seat - g0, 0.3, s * (w / 2 - 0.3), (seat + g0) / 2, z)),
      ])), role: 'prop' });
    } else if (pr.t === 'wall') {
      const z = zx(pr.x);
      out.push({ mesh: cached(key, () => box(14, 22, 0.3, 0, g0 + 11, z + (pr.x > 0 ? 0.15 : -0.15))), role: 'wall', shadow: false });
    } else if (pr.t === 'mat') {
      const z0 = zx(pr.x), z1 = zx(pr.x + pr.w);
      const wide = sag ? 6.2 : (pr.w * k);
      out.push({ mesh: cached(key, () => (sag ? box(6.2, 0.06, z1 - z0, 0, g0 + 0.03, (z0 + z1) / 2) : box(pr.w * k, 0.06, 6.2, -(pr.x + pr.w / 2) * k, g0 + 0.03, 0))), role: 'mat', shadow: false });
    }
  }
  return out;
}

function dynamicProps(anim, P, g0, impl, rig) {
  const out = [];
  const k = rig.k;
  const sag = planeOf(anim) === 'sagittal';
  const W2 = (p, lat = 0) => (sag ? [lat, g0 - p[1] * k, p[0] * k] : [-p[0] * k, g0 - p[1] * k, 0]);
  const pick = (n) => ({
    wristR: P.palmR, wristL: P.palmL, wrists: v3.lerp(P.palmL, P.palmR, 0.5), toeR: P.toeR, toeL: P.toeL, ankleR: P.ankleR, ankleL: P.ankleL,
    heelR: P.heelR, heelL: P.heelL, heels: v3.lerp(P.heelL, P.heelR, 0.5), kneeR: P.kneeR, kneeL: P.kneeL, knees: v3.lerp(P.kneeL, P.kneeR, 0.5),
    elbows: v3.lerp(P.elbowL, P.elbowR, 0.5),
  })[n] || P.hip;
  const rod = () => cached('rod', () => cylinder(1, 1, 8, false));
  for (const pr0 of anim.props || []) {
    let pr = pr0;
    if (pr.t === 'kb' && impl === 'manubri') pr = { ...pr, t: 'db' };
    else if (pr.t === 'kb' && impl === 'zaino') pr = { ...pr, t: 'pack' };
    if (pr.t === 'db') {
      const two = (pr.at === 'wrists') && v3.len(v3.sub(P.palmL, P.palmR)) > 1.4;
      const spots = pr.at === 'hip' ? [[v3.add(P.hip, v3.mul(P.fwd, 1.6)), P.Lb]]
        : two ? [[P.palmL, P.Lb], [P.palmR, P.Lb]]
        : pr.at === 'wrists' ? [[v3.add(v3.lerp(P.palmL, P.palmR, 0.5), [0, -0.4, 0]), [0, 1, 0]]]
        : [[pick(pr.at), P.Lb]];
      for (const [c, ax] of spots) {
        const y = v3.norm(ax), x = v3.norm(v3.cross(y, Math.abs(y[2]) < 0.9 ? [0, 0, 1] : [1, 0, 0])), z = v3.cross(x, y);
        out.push({ mesh: cached('db', () => merge([cylinder(0.16, 1.5, 10, false), cylinder(0.48, 0.45, 12), cylinder(0.48, 0.45, 12)].map((g, i) => i === 0 ? shift(g, 0, -0.75, 0) : shift(g, 0, i === 1 ? -1.15 : 0.7, 0)))), model: mat(x, y, z, c), role: 'iron', spec: 0.3 });
      }
      continue;
    }
    if (pr.t === 'bar') {
      const c = W2([pr.x, pr.y]);
      out.push({ mesh: cached('bar', () => merge([shift(cylinder(0.14, 9, 10), 0, -4.5, 0), shift(cylinder(0.32, 0.6, 10), 0, -4.8, 0), shift(cylinder(0.32, 0.6, 10), 0, 4.2, 0)])), model: mat([0, 1, 0], [1, 0, 0], [0, 0, 1], c), role: 'iron', shadow: false });
      continue;
    }
    if (pr.t === 'trx') {
      const A = W2(pr.at);
      const ends = pr.to === 'wrists' ? [P.palmL, P.palmR] : pr.to === 'heels' ? [P.heelL, P.heelR] : pr.to === 'knees' ? [P.kneeL, P.kneeR] : [pick(pr.to)];
      for (const e of ends) out.push({ mesh: rod(), model: segMatrix(A, e, pr.band ? 0.08 : 0.11), role: pr.band ? 'band' : 'strap', shadow: false });
      if (!pr.band) for (const e of ends) out.push({ mesh: cached('handle', () => shift(cylinder(0.16, 1.1, 8), 0, -0.55, 0)), model: segMatrix(v3.add(e, v3.mul(P.Lb, -0.5)), v3.add(e, v3.mul(P.Lb, 0.5)), 1), role: 'iron', shadow: false });
      continue;
    }
    if (pr.t === 'ball') {
      const r = (pr.r || 30) * k;
      const at = pick(pr.at);
      const c = pr.at === 'elbows' ? [at[0], g0 + r, at[2]] : [at[0], g0 + r, at[2] - r * 0.35];
      out.push({ mesh: cached('ball', () => sphere(1, 22)), model: mat([r, 0, 0], [0, r, 0], [0, 0, r], c), role: 'ball', spec: 0.4 });
      continue;
    }
    if (pr.t === 'ankle') {
      for (const S of ['L', 'R']) {
        const a = P['ankle' + S], kn = P['knee' + S];
        const d = v3.norm(v3.sub(kn, a));
        out.push({ mesh: cached('cuff', () => cylinder(1, 1, 14)), model: segMatrix(v3.add(a, v3.mul(d, 0.25)), v3.add(a, v3.mul(d, 1.15)), 0.55), role: 'cuff' });
      }
      continue;
    }
    if (pr.t === 'backband') {
      const back = v3.add(P.chest, v3.mul(P.fwd, -0.9));
      out.push({ mesh: rod(), model: segMatrix(P.palmL, v3.add(back, v3.mul(P.Lb, 1.2)), 0.08), role: 'band', shadow: false });
      out.push({ mesh: rod(), model: segMatrix(v3.add(back, v3.mul(P.Lb, 1.2)), v3.add(back, v3.mul(P.Lb, -1.2)), 0.08), role: 'band', shadow: false });
      out.push({ mesh: rod(), model: segMatrix(v3.add(back, v3.mul(P.Lb, -1.2)), P.palmR, 0.08), role: 'band', shadow: false });
      continue;
    }
    if (pr.t === 'band' && pr.side) {
      const A = sag ? [pr.side[0], g0 - pr.side[1] * k, pr.side[2] * k] : [0, g0 - pr.side[1] * k, pr.side[0]];
      out.push({ mesh: rod(), model: segMatrix(pick(pr.from), A, 0.08), role: 'band', shadow: false });
      continue;
    }
    if (pr.t === 'kb') {
      let at;
      if (pr.at === 'wrists') at = v3.lerp(P.palmL, P.palmR, 0.5);
      else if (pr.at === 'wristR') at = P.palmR;
      else if (pr.at === 'wristL') at = P.palmL;
      else if (pr.at === 'hip') at = v3.add(P.hip, mulRV(P.R.torso, [0, 0, 1.1]));
      else at = P.hip;
      let down = [0, -1, 0];
      const fa = v3.norm(v3.sub(P.palmR, P.elbowR));
      if (pr.at !== 'hip' && fa[1] < -0.2) down = fa;
      if (pr.at === 'hip') down = v3.mul(P.fwd, -1);
      const c = pr.at === 'hip' ? v3.add(P.hip, v3.mul(P.fwd, 2.25)) : v3.add(at, v3.mul(down, 1.05));
      const y = v3.mul(down, -1);
      const x = v3.norm(v3.cross(y, Math.abs(y[2]) < 0.9 ? [0, 0, 1] : [1, 0, 0]));
      const z = v3.cross(x, y);
      out.push({ mesh: cached('kb', () => merge([sphere(0.82, 16, 0, 0, 0, 0.94), torus(0.52, 0.11, 16, 8, Math.PI * 1.25, 0, 0.62, 0)])), model: mat(z, y, x, c), role: 'iron', spec: 0.35 });
    } else if (pr.t === 'pack') {
      const at = pr.at === 'wrists' ? v3.lerp(P.palmL, P.palmR, 0.5) : P.palmR;
      out.push({ mesh: cached('pack', () => merge([box(2.6, 3.0, 1.3, 0, -1.55, 0), box(1.9, 1.2, 0.4, 0, -2.2, 0.8)])), model: mat([1, 0, 0], [0, 1, 0], [0, 0, 1], at), role: 'pack' });
    } else if (pr.t === 'band') {
      out.push({ mesh: cached('rod', () => cylinder(1, 1, 8, false)), model: segMatrix(pick(pr.from), pick(pr.to), 0.07), role: 'band', shadow: false });
    } else if (pr.t === 'miniband') {
      const f = pr.at === 'ankles' ? 0.78 : 0.22;
      const a = v3.lerp(P.kneeL, P.ankleL, f), b = v3.lerp(P.kneeR, P.ankleR, f);
      for (const off of [0.45, -0.45]) {
        const o = v3.mul(P.fwd, off);
        out.push({ mesh: cached('rod', () => cylinder(1, 1, 8, false)), model: segMatrix(v3.add(a, o), v3.add(b, o), 0.12), role: 'band', shadow: false });
      }
    } else if (pr.t === 'towel') {
      const at = pick(pr.at);
      out.push({ mesh: cached('towel', () => box(2.6, 0.08, 2.2, 0, 0.04, 0)), model: mat([1, 0, 0], [0, 1, 0], [0, 0, 1], [at[0], g0, at[2]]), role: 'band2', shadow: false });
    }
  }
  return out;
}

// ---------------------------------------------------------------- inquadratura
function cameraFor(anim, rig, yoff, aspect) {
  const sag = planeOf(anim) === 'sagittal';
  const plane = planeOf(anim);
  const yaw = ((anim.cam && anim.cam.yaw) ?? (sag ? 58 : plane === 'lie' ? 12 : 18)) * Math.PI / 180;
  const pitch = ((anim.cam && anim.cam.pitch) ?? (plane === 'lie' ? 16 : 9)) * Math.PI / 180;
  const back = [-Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch)];
  const right = v3.norm(v3.cross([0, 1, 0], back));
  const up = v3.cross(back, right);
  const pts = [];
  const L = cycleLength(anim), N = 16;
  for (let i = 0; i < N; i++) {
    const P = pose3d(rig, anim, solveWithPose(poseAt(anim, (L * i) / N)), yoff);
    for (const k of ['head', 'hip', 'chest', 'kneeL', 'kneeR', 'ankleL', 'ankleR', 'toeL', 'toeR', 'heelL', 'heelR', 'palmL', 'palmR', 'elbowL', 'elbowR']) pts.push(P[k]);
    pts.push(v3.add(P.head, [0, 0.6, 0]));
  }
  // un po' di pavimento sotto i piedi
  const g = rig.ground + yoff;
  for (const p of pts.slice()) pts.push([p[0], g, p[2]]);
  for (const pr of anim.props || []) {
    if (pr.t === 'bar') pts.push(sag ? [0, g - pr.y * rig.k + 0.5, pr.x * rig.k] : [-pr.x * rig.k, g - pr.y * rig.k + 0.5, 0]);
    if (pr.t === 'box' || pr.t === 'chair' || pr.t === 'table') {
      const z0 = sag ? pr.x * rig.k : 0, z1 = sag ? (pr.x + pr.w) * rig.k : 0;
      const top = g - (pr.t === 'chair' ? pr.top : pr.y) * rig.k;
      pts.push([0, top, z0], [0, top, z1], [0, g, z0], [0, g, z1]);
    }
  }
  const fov = 0.5;
  const tn = Math.tan(fov / 2);
  let xs = pts.map((p) => v3.dot(p, right)), ys = pts.map((p) => v3.dot(p, up));
  const cx = (Math.min(...xs) + Math.max(...xs)) / 2, cy = (Math.min(...ys) + Math.max(...ys)) / 2;
  const cz = pts.reduce((s, p) => s + v3.dot(p, back), 0) / pts.length;
  const center = v3.add(v3.add(v3.mul(right, cx), v3.mul(up, cy)), v3.mul(back, cz));
  const pad = 1.08;
  let D = 10;
  for (let it = 0; it < 40; it++) {
    let need = 0;
    for (const p of pts) {
      const d = v3.sub(p, center);
      const zz = D - v3.dot(d, back);
      need = Math.max(need, Math.abs(v3.dot(d, right)) * pad / (tn * aspect * zz), Math.abs(v3.dot(d, up)) * pad / (tn * zz));
    }
    D *= need;
    if (Math.abs(need - 1) < 0.002) break;
  }
  const eye = v3.add(center, v3.mul(back, D));
  return { eye, at: center, fov, right, back };
}

// ---------------------------------------------------------------- tema
function readTheme(darkSurface) {
  const dark = darkSurface || getComputedStyle(document.documentElement).colorScheme === 'dark';
  return dark
    ? { floor: [0.24, 0.28, 0.3], floorA: 0.8, shadowA: 0.34, hi: [0.95, 0.36, 0.28], sky: [0.82, 0.86, 0.95], gnd: [0.32, 0.3, 0.3], prop: [0.4, 0.45, 0.47], sofa: [0.36, 0.41, 0.44], mat: [0.28, 0.4, 0.36], wall: [0.45, 0.5, 0.52] }
    : { floor: [0.84, 0.87, 0.83], floorA: 1, shadowA: 0.16, hi: [0.86, 0.22, 0.15], sky: [0.96, 0.97, 1.0], gnd: [0.62, 0.58, 0.54], prop: [0.78, 0.81, 0.77], sofa: [0.66, 0.72, 0.76], mat: [0.56, 0.7, 0.62], wall: [0.86, 0.88, 0.85] };
}
const ROLE_COLOR = (th) => ({ prop: th.prop, sofa: th.sofa, mat: th.mat, wall: th.wall, iron: [0.2, 0.22, 0.24], pack: [0.3, 0.42, 0.56], band: [0.24, 0.62, 0.38], band2: [0.42, 0.66, 0.5], strap: [0.12, 0.13, 0.14], ball: [0.55, 0.72, 0.86], cuff: [0.26, 0.3, 0.36] });

// ---------------------------------------------------------------- muscoli evidenziati
export const MUSCLE_IDS = { glutes: 1, glutemed: 2, quads: 3, hamstrings: 4, adductors: 5, calves: 6, core: 7, lowback: 8, chest: 9, upperback: 10, delts: 11, biceps: 12, triceps: 13 };

// ---------------------------------------------------------------- figura
const live = new Set();
const YOFF = new WeakMap();
const CAMS = new WeakMap();
let raf = 0;
function tick(ts) {
  raf = 0;
  if (!ctx3 || ctx3.R.lost) return;
  for (const f of live) f._frame(ts);
  if (live.size) raf = requestAnimationFrame(tick);
}
function schedule() { if (!raf) raf = requestAnimationFrame(tick); }

export function createFigure3D(anim, { aspect = 1.25, autoplay = true, still = 0.5, label = '', muscles = null, dark = false, impl = null } = {}) {
  const { R, rig } = ctx3;
  const canvas = document.createElement('canvas');
  canvas.className = 'fig fig3d';
  canvas.style.aspectRatio = String(aspect);
  canvas.setAttribute('role', 'img');
  if (label) canvas.setAttribute('aria-label', label);
  if (!YOFF.has(anim)) YOFF.set(anim, groundOffset(rig, anim));
  const yoff = YOFF.get(anim);
  const g0 = rig.ground + yoff;
  let cam = null;
  const statics = staticProps(anim, rig, g0);
  const floorMesh = cached('floor' + g0.toFixed(2), () => plane(60, 60, g0));
  const hi = new Float32Array(14);
  for (const m of muscles || []) if (MUSCLE_IDS[m]) hi[MUSCLE_IDS[m]] = 1;
  const mats = new Float32Array(rig.n * 16);
  let running = false, t0 = 0, speed = 1, lastDraw = 0, theme = readTheme(dark), camAspect = 0;
  const reduce = typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;

  function size() {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const cw = canvas.clientWidth || 300, ch = canvas.clientHeight || cw / aspect;
    const w = Math.max(60, Math.round(cw * dpr));
    const h = Math.max(40, Math.round(ch * dpr));
    if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
    return [w, h];
  }
  function draw(time) {
    if (!ctx3 || R.lost) return;
    const [w, h] = size();
    if (!cam || Math.abs(camAspect - w / h) > 0.02) {
      camAspect = w / h;
      const ck = Math.round(camAspect * 20);
      let per = CAMS.get(anim); if (!per) CAMS.set(anim, per = new Map());
      if (!per.has(ck)) per.set(ck, cameraFor(anim, rig, yoff, ck / 20));
      cam = per.get(ck);
    }
    const P = pose3d(rig, anim, solveWithPose(poseAt(anim, time)), yoff);
    boneMatrices(rig, P, mats);
    const col = ROLE_COLOR(theme);
    const props = [...statics, ...dynamicProps(anim, P, g0, impl, rig)].map((p) => ({ ...p, color: col[p.role] || theme.prop, alpha: p.role === 'wall' ? 0.55 : 1 }));
    const key = v3.norm(v3.add(v3.add(v3.mul(cam.right, -0.55), [0, 1.2, 0]), v3.mul(cam.back, 0.55)));
    const pulse = Math.sin(time * Math.PI * 2 / Math.max(1, cycleLength(anim))) * 0.5 + 0.5;
    renderScene(R, {
      bones: mats, cam, props, hi, theme, light: key, ground: g0, pulse,
      floor: { mesh: floorMesh, c: [cam.at[0], g0, cam.at[2]], r: 14 },
    }, w, h);
    const c2 = canvas.getContext('2d');
    c2.clearRect(0, 0, w, h);
    c2.drawImage(R.canvas, 0, 0, w, h, 0, 0, w, h);
  }
  const api = {
    svg: canvas, el: canvas,
    _frame(ts) {
      if (!canvas.isConnected) { api.stop(); return; }
      if (ts - lastDraw < 30) return;
      lastDraw = ts;
      if (!t0) t0 = ts;
      draw(((ts - t0) / 1000) * speed);
    },
    play() { if (running || reduce) return; running = true; t0 = 0; live.add(api); schedule(); },
    stop() { running = false; live.delete(api); },
    setSpeed(s) { speed = s; },
    redraw() { theme = readTheme(dark); draw(cycleLength(anim) * still); },
    drawAt(t) { draw(t); },
    get running() { return running; },
  };
  // primo fotogramma appena il canvas ha dimensioni
  requestAnimationFrame(() => draw(cycleLength(anim) * still));
  if (autoplay) api.play();
  return api;
}
