// Forma — piccoli strumenti per costruire l'interfaccia.

export function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const k in attrs) {
    const v = attrs[k];
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'html') el.innerHTML = v;
    else if (v === true) el.setAttribute(k, '');
    else el.setAttribute(k, v);
  }
  append(el, kids);
  return el;
}

function append(el, kids) {
  for (const c of kids.flat(Infinity)) {
    if (c == null || c === false) continue;
    el.appendChild(c instanceof Node ? c : document.createTextNode(String(c)));
  }
}

export function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); return el; }

const ICONS = {
  oggi: '<rect x="4" y="5" width="16" height="15" rx="2.5"/><path d="M4 10h16M9 3v4M15 3v4"/><circle cx="12" cy="15" r="1.8" class="f"/>',
  programma: '<path d="M5 7h7M5 12h11M5 17h14"/><circle cx="12" cy="7" r="1.6" class="f"/><circle cx="16" cy="12" r="1.6" class="f"/><circle cx="19" cy="17" r="1.6" class="f"/>',
  esercizi: '<circle cx="12" cy="4.8" r="2.2" class="f"/><path d="M12 8v6M12 14l-4 6M12 14l4 6M7 10.5l5-1.5 5 1.5"/>',
  progressi: '<path d="M4 19h16"/><path d="M5 15l4-4 4 3 6-7"/><path d="M15 7h4v4"/>',
  guida: '<path d="M5 5.5A2.5 2.5 0 0 1 7.5 3H19v15H7.5A2.5 2.5 0 0 0 5 20.5z"/><path d="M5 20.5A2.5 2.5 0 0 1 7.5 18H19v3H7.5"/>',
  impostazioni: '<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>',
  play: '<path d="M8 5.5v13l11-6.5z" class="f"/>',
  pause: '<path d="M8 5v14M16 5v14" stroke-width="3"/>',
  close: '<path d="M6 6l12 12M18 6L6 18"/>',
  next: '<path d="M6 5.5v13l9-6.5z" class="f"/><path d="M18 5v14" stroke-width="2.6"/>',
  back: '<path d="M15 5l-7 7 7 7"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  sound: '<path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4z" class="f"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"/>',
  mute: '<path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4z" class="f"/><path d="M16 9.5l5 5M21 9.5l-5 5"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6"/><circle cx="12" cy="7.6" r="1.2" class="f"/>',
  up: '<path d="M12 19V6M6 11l6-6 6 6"/>',
  down: '<path d="M12 5v13M6 13l6 6 6-6"/>',
  chevron: '<path d="M9 5l7 7-7 7"/>',
  repeat: '<path d="M4 12a7 7 0 0 1 12-5l2 2M20 12a7 7 0 0 1-12 5l-2-2"/><path d="M18 4v5h-5M6 20v-5h5"/>',
};

export function icon(name, cls = '') {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24');
  s.setAttribute('class', `ico ${cls}`.trim());
  s.setAttribute('aria-hidden', 'true');
  s.innerHTML = ICONS[name] || '';
  return s;
}

// ---------- livelli: colori come gli elastici (dal più leggero al più duro) ----------
export function tier(level, total) {
  const t = h('span', { class: `tier t${Math.min(level, 7)}`, title: `Livello ${level + 1} di ${total}` }, String(level + 1));
  return t;
}

// ---------- formati ----------
const MESI = ['gen', 'feb', 'mar', 'apr', 'mag', 'giu', 'lug', 'ago', 'sett', 'ott', 'nov', 'dic'];
const MESI_LUNGHI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
const GIORNI = ['domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato'];
export const GIORNI_BREVI = ['L', 'M', 'M', 'G', 'V', 'S', 'D'];
export function fmtDate(ts, withDay = false, long = false) {
  const d = new Date(ts);
  const base = `${d.getDate()} ${(long ? MESI_LUNGHI : MESI)[d.getMonth()]}`;
  return withDay ? `${GIORNI[d.getDay()]} ${base}` : base;
}
export function fmtRelDay(ts, now = Date.now()) {
  const d0 = new Date(now); d0.setHours(0, 0, 0, 0);
  const d1 = new Date(ts); d1.setHours(0, 0, 0, 0);
  const diff = Math.round((d0 - d1) / 86400000);
  if (diff === 0) return 'oggi';
  if (diff === 1) return 'ieri';
  if (diff < 7) return GIORNI[new Date(ts).getDay()];
  return fmtDate(ts);
}
export function fmtClock(sec) {
  sec = Math.max(0, Math.round(sec));
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}
export function fmtMin(sec) { return `${Math.round(sec / 60)} min`; }
export function minuti(n) { return `${n} ${n === 1 ? 'minuto' : 'minuti'}`; }

// ---------- notifiche ----------
let toastTimer = 0;
export function toast(msg) {
  let el = document.getElementById('toast');
  if (!el) {
    el = h('div', { id: 'toast', role: 'status', 'aria-live': 'polite' });
    document.body.appendChild(el);
  }
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2600);
}

// ---------- foglio dal basso ----------
export function sheet(content, { title = '', onClose, dismissable = true } = {}) {
  const panel = h('div', { class: 'sheet', role: 'dialog', 'aria-modal': 'true', 'aria-label': title || 'Finestra' },
    h('div', { class: 'sheet-grip' }),
    title ? h('h2', { class: 'sheet-title' }, title) : null,
    content);
  const scrim = h('div', { class: 'scrim' }, panel);
  const close = (val) => {
    scrim.classList.remove('open');
    setTimeout(() => scrim.remove(), 220);
    document.removeEventListener('keydown', onKey);
    if (onClose) onClose(val);
  };
  const onKey = (e) => { if (e.key === 'Escape' && dismissable) close(); };
  if (dismissable) scrim.addEventListener('click', (e) => { if (e.target === scrim) close(); });
  document.addEventListener('keydown', onKey);
  document.body.appendChild(scrim);
  requestAnimationFrame(() => scrim.classList.add('open'));
  panel.setAttribute('tabindex', '-1');
  setTimeout(() => panel.focus({ preventScroll: true }), 60);
  return { close, panel };
}

export function confirmDialog(text, { ok = 'Conferma', cancel = 'Annulla', danger = false, title = '' } = {}) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (v) => { if (!done) { done = true; s.close(); resolve(v); } };
    const body = h('div', { class: 'confirm' },
      h('p', {}, text),
      h('div', { class: 'row-actions' },
        h('button', { class: 'btn ghost', onClick: () => finish(false) }, cancel),
        h('button', { class: `btn ${danger ? 'danger' : 'primary'}`, onClick: () => finish(true) }, ok)));
    const s = sheet(body, { title, onClose: () => { if (!done) { done = true; resolve(false); } } });
  });
}

// ---------- stepper numerico grande ----------
export function stepper({ value, min = 0, max = 999, step = 1, unit = '', label = '', onChange }) {
  let v = value;
  const out = h('output', { class: 'stepper-val', 'aria-live': 'polite' }, String(v));
  const set = (nv) => {
    v = Math.max(min, Math.min(max, Math.round(nv / step) * step));
    out.textContent = String(v);
    if (onChange) onChange(v);
  };
  const hold = (dir) => {
    let t = 0, iv = 0;
    const startFn = (e) => {
      e.preventDefault();
      set(v + dir * step);
      t = setTimeout(() => { iv = setInterval(() => set(v + dir * step), 80); }, 420);
    };
    const stopFn = () => { clearTimeout(t); clearInterval(iv); };
    return { onPointerdown: startFn, onPointerup: stopFn, onPointerleave: stopFn, onPointercancel: stopFn };
  };
  const minus = h('button', { class: 'stepper-btn', type: 'button', 'aria-label': `Meno ${label}`, ...hold(-1) }, icon('minus'));
  const plus = h('button', { class: 'stepper-btn', type: 'button', 'aria-label': `Più ${label}`, ...hold(1) }, icon('plus'));
  // supporto tastiera
  minus.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); set(v - step); } });
  plus.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); set(v + step); } });
  const el = h('div', { class: 'stepper' },
    label ? h('span', { class: 'stepper-label' }, label) : null,
    h('div', { class: 'stepper-row' }, minus, h('div', { class: 'stepper-mid' }, out, unit ? h('span', { class: 'stepper-unit' }, unit) : null), plus));
  return { el, get value() { return v; }, set };
}

// ---------- controllo segmentato ----------
export function segmented(options, value, onChange, { label = '' } = {}) {
  const wrap = h('div', { class: 'seg', role: 'radiogroup', 'aria-label': label });
  const btns = options.map(([val, text]) => {
    const b = h('button', { type: 'button', role: 'radio', 'aria-checked': String(val === value), class: val === value ? 'on' : '' }, text);
    b.addEventListener('click', () => {
      btns.forEach((x) => { x.classList.remove('on'); x.setAttribute('aria-checked', 'false'); });
      b.classList.add('on');
      b.setAttribute('aria-checked', 'true');
      onChange(val);
    });
    return b;
  });
  btns.forEach((b) => wrap.appendChild(b));
  return wrap;
}

export function toggle(label, checked, onChange, desc = '') {
  const id = `t${Math.random().toString(36).slice(2, 8)}`;
  const input = h('input', { type: 'checkbox', id, role: 'switch', checked: checked || null });
  input.addEventListener('change', () => onChange(input.checked));
  return h('label', { class: 'toggle', for: id },
    h('span', { class: 'toggle-text' }, h('span', { class: 'toggle-label' }, label), desc ? h('span', { class: 'toggle-desc' }, desc) : null),
    input, h('span', { class: 'toggle-ui', 'aria-hidden': 'true' }));
}
