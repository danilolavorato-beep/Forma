// Forma — dalle pose 2D degli esercizi alla posa 3D del modello.
// Le animazioni restano descritte in 2D (figure.js): qui si ricava una posa 3D coerente
// (stesse direzioni di tronco e testa, stessi punti di appoggio di mani e piedi) con le
// proporzioni del modello, risolvendo braccia e gambe con una cinematica inversa a due segmenti.
import { solve, poseAt, cycleLength } from './figure.js';
import { v3, rotFromTo, mulRV, mulRR, rotAxis } from './body3d.js';

const X = [1, 0, 0];
const Z = [0, 0, 1];
const PALM = 0.5; // dal polso al centro del palmo (dm)

const dist = (a, b) => v3.len(v3.sub(a, b));
const dirOf = (a, b) => v3.norm(v3.sub(b, a));

export function prepareRig(model) {
  const B = {};
  model.bones.forEach((b, i) => { B[b.name] = { ...b, i }; });
  const rig = { B, n: model.bones.length, ground: model.ground };
  const len = (n) => dist(B[n].head, B[n].tail);
  rig.len = {
    thigh: dist(B['thigh.L'].head, B['shin.L'].head),
    shin: dist(B['shin.L'].head, B['foot.L'].head),
    uarm: dist(B['uarm.L'].head, B['farm.L'].head),
    farm: dist(B['farm.L'].head, B['hand.L'].head),
  };
  rig.k = (rig.len.thigh + rig.len.shin) / 88; // dm per unità 2D (cm)
  rig.rest = {};
  for (const b of model.bones) rig.rest[b.name] = dirOf(b.head, b.tail);
  rig.hArm = {};
  for (const s of 'LR') rig.hArm[s] = v3.norm(v3.cross(rig.rest[`uarm.${s}`], rig.rest[`farm.${s}`]));
  rig.hipC = B.torso.head;
  rig.shC = B.torso.tail;
  // campione di vertici per l'appoggio a terra (skinning su CPU)
  const p = model.prims[0];
  const idx = [];
  for (let i = 0; i < p.POSITION.length / 3; i += 9) idx.push(i);
  rig.sample = idx.map((i) => ({ p: [p.POSITION[i * 3], p.POSITION[i * 3 + 1], p.POSITION[i * 3 + 2]], j: [p.JOINTS_0[i * 4], p.JOINTS_0[i * 4 + 1], p.JOINTS_0[i * 4 + 2], p.JOINTS_0[i * 4 + 3]], w: [p.WEIGHTS_0[i * 4], p.WEIGHTS_0[i * 4 + 1], p.WEIGHTS_0[i * 4 + 2], p.WEIGHTS_0[i * 4 + 3]] }));
  return rig;
}

// due segmenti: radice A, bersaglio T, lunghezze a,b, polo P → [giunto, estremo raggiunto]
function ik2(A, T, a, b, P) {
  const v = v3.sub(T, A);
  let d = v3.len(v);
  const u = d > 1e-6 ? v3.mul(v, 1 / d) : [0, -1, 0];
  d = Math.min(Math.max(d, Math.abs(a - b) + 1e-3), a + b - 1e-3);
  let w = v3.sub(P, A);
  w = v3.sub(w, v3.mul(u, v3.dot(w, u)));
  if (v3.len(w) < 1e-6) w = Math.abs(u[1]) < 0.9 ? [0, 1, 0] : [0, 0, 1];
  w = v3.norm(v3.sub(w, v3.mul(u, v3.dot(w, u))));
  const ca = (a * a + d * d - b * b) / (2 * a * d);
  const sa = Math.sqrt(Math.max(0, 1 - ca * ca));
  const J = v3.add(A, v3.add(v3.mul(u, a * ca), v3.mul(w, a * sa)));
  return [J, v3.add(A, v3.mul(u, d))];
}

// piano dell'animazione: 'sagittal' (vista di lato), 'front' (vista frontale in 2D),
// 'lie' (corpo su un fianco: il piano del disegno è il piano frontale del corpo)
export function planeOf(anim) {
  if (anim.plane) return anim.plane;
  return anim.view === 'front' ? 'front' : 'sagittal';
}

// ---------------------------------------------------------------- posa di un istante
export function pose3d(rig, anim, J, yoff = 0) {
  const { B, k, len } = rig;
  const plane = planeOf(anim);
  const sag = plane === 'sagittal';
  const g0 = rig.ground + yoff;
  const hint = anim.w3 || {};
  const W = sag
    ? (p, lat = 0) => [lat, g0 - p[1] * k, p[0] * k]
    : (p) => [-p[0] * k, g0 - p[1] * k, 0];
  const Wv = sag ? (v) => [0, -v[1] * k, v[0] * k] : (v) => [-v[0] * k, -v[1] * k, 0];
  const R = {}; const H = {}; // rotazioni e teste in mondo
  const T = (b, v) => v3.add(H[b], mulRV(R[b], v3.sub(v, B[b].head))); // punto di riposo → mondo

  // tronco
  const dT = v3.norm(Wv(v3.sub(J.neck, J.hip)));
  const Fb = sag ? null : Z;
  const Lb = sag ? X : v3.norm(v3.cross(dT, Fb));
  R.torso = rotFromTo(rig.rest.torso, X, dT, Lb);
  if ((anim.root || 'hip') === 'neck') H.torso = v3.sub(W(J.neck), mulRV(R.torso, v3.sub(rig.shC, rig.hipC)));
  else H.torso = W(J.hip);
  const fwd = mulRV(R.torso, Z); // avanti del corpo

  // testa e collo
  const dH = v3.norm(Wv(v3.sub(J.head, J.neck)));
  const LbH = sag ? X : v3.norm(v3.cross(dH, Z));
  R.head = rotFromTo(rig.rest.head, X, dH, LbH);
  const dN = v3.norm(v3.add(mulRV(R.torso, rig.rest.neck), mulRV(R.head, rig.rest.neck)));
  R.neck = rotFromTo(rig.rest.neck, X, dN, Lb);
  H.neck = T('torso', B.neck.head);
  H.head = T('neck', B.head.head);

  const legW = (S) => {
    const spec = ((J.__pose && J.__pose.legs) || {})[S] || {};
    return (spec.w ?? hint.feet ?? 1.12);
  };
  const armW = (S) => {
    const spec = ((J.__pose && J.__pose.arms) || {})[S] || {};
    return (spec.w ?? hint.hands ?? 1.06);
  };
  const out = { plane, fwd, Lb };

  for (const S of ['L', 'R']) {
    const s2 = S === 'L' ? 'L' : 'R';
    // ----- gamba
    const th = `thigh.${S}`, sh = `shin.${S}`, ft = `foot.${S}`, to = `toes.${S}`;
    R[th] = R.torso; H[th] = T('torso', B[th].head);
    const Hj = H[th];
    let A, P;
    const lspec = ((J.__pose && J.__pose.legs) || {})[S] || {};
    if (sag) {
      const lat = B[th].head[0] * legW(S);
      A = W(J['ankle' + s2], lat);
      P = W(J['knee' + s2], lspec.ko ? B[th].head[0] * lspec.ko : (lat + Hj[0]) / 2);
    } else if (plane === 'front') {
      A = W(J['ankle' + s2]);
      P = v3.add(v3.lerp(Hj, A, 0.5), v3.mul(fwd, 3));
    } else {
      A = v3.add(Hj, Wv(v3.sub(J['ankle' + s2], J.hip)));
      P = v3.add(v3.lerp(Hj, A, 0.5), v3.mul(fwd, 3));
      if (lspec.kz != null) {
        const upIn = v3.norm(v3.cross(fwd, dT)); // perpendicolare al tronco nel piano del disegno
        P = v3.add(v3.add(Hj, v3.mul(fwd, lspec.kz * k)), v3.add(v3.mul(dT, -1.0), v3.mul(upIn, (lspec.ky || 0) * k * (S === 'R' ? 1 : 1))));
      }
    }
    if (lspec.dz && !sag) A = v3.add(A, v3.mul(fwd, lspec.dz * k));
    const [K, A2] = ik2(Hj, A, len.thigh, len.shin, P);
    const dTh = dirOf(Hj, K), dSh = dirOf(K, A2);
    let n = v3.add(v3.cross(dTh, dSh), v3.mul(Lb, 0.12));
    n = v3.norm(n);
    R[th] = rotFromTo(rig.rest[th], X, dTh, n);
    R[sh] = rotFromTo(rig.rest[sh], X, dSh, n);
    H[sh] = K;
    // piede: direzione della pianta dal tallone alla punta
    let dS;
    if (sag) {
      dS = v3.norm(Wv(v3.sub(J['toe' + s2], J['heel' + s2])));
      const out2 = (hint.toesOut ?? 8) * (S === 'L' ? 1 : -1) * Math.PI / 180;
      dS = mulRV(rotAxis([0, 1, 0], out2), dS);
    } else {
      dS = v3.norm(v3.sub(fwd, v3.mul(dSh, v3.dot(fwd, dSh) * 0.6)));
    }
    const nf = v3.norm(v3.sub(n, v3.mul(dS, v3.dot(n, dS))));
    R[ft] = rotFromTo(Z, X, dS, nf);
    H[ft] = A2;
    // dita: se il tallone è sollevato e la punta a terra, restano piatte
    const toeW = T(ft, B[to].head);
    if (sag && dS[1] > 0.25 && toeW[1] < g0 + 0.5) R[to] = rotFromTo(Z, X, v3.norm([dS[0], 0, dS[2]]), nf);
    else R[to] = R[ft];
    H[to] = toeW;
    out['knee' + S] = K; out['ankle' + S] = A2; out['toe' + S] = T(to, B[to].tail); out['heel' + S] = v3.add(A2, v3.mul(dS, -0.6));
    out['hip' + S] = Hj;

    // ----- braccio
    const cl = `clav.${S}`, ua = `uarm.${S}`, fa = `farm.${S}`, ha = `hand.${S}`;
    const shJ = sag ? J.neck : J['sh' + s2];
    const reach = v3.norm(Wv(v3.sub(J['wrist' + s2], shJ)));
    const up = mulRV(R.torso, [0, 1, 0]);
    const elev = Math.max(0, Math.min(1, (v3.dot(reach, up) + 0.1) / 1.0));
    R[cl] = mulRR(rotAxis(fwd, (S === 'L' ? 1 : -1) * elev * 0.42), R.torso);
    H[cl] = T('torso', B[cl].head);
    const Sj = T(cl, B[ua].head);
    let Tw, Pe;
    if (sag) {
      const lat = B[ua].head[0] * armW(S);
      Tw = W(J['wrist' + s2], lat);
      const aspec = ((J.__pose && J.__pose.arms) || {})[S] || {};
      Pe = W(J['elbow' + s2], aspec.eo ? B[ua].head[0] * aspec.eo : (lat + Sj[0]) / 2);
    } else if (plane === 'front') {
      Tw = W(J['wrist' + s2]);
      Pe = v3.add(v3.lerp(Sj, Tw, 0.5), v3.mul(fwd, -2.5));
    } else {
      Tw = v3.add(Sj, Wv(v3.sub(J['wrist' + s2], shJ)));
      Pe = v3.add(v3.lerp(Sj, Tw, 0.5), v3.mul(fwd, -2.5));
    }
    const [E, Pw] = ik2(Sj, Tw, len.uarm, len.farm + PALM, Pe);
    const dUa = dirOf(Sj, E), dFa = dirOf(E, Pw);
    let na = v3.norm(v3.add(v3.cross(dUa, dFa), v3.mul(Lb, -0.12)));
    R[ua] = rotFromTo(rig.rest[ua], rig.hArm[S], dUa, na);
    R[fa] = rotFromTo(rig.rest[fa], rig.hArm[S], dFa, na);
    H[ua] = Sj; H[fa] = E;
    const wristW = v3.add(E, v3.mul(dFa, len.farm));
    // mano: piatta se spinge su un appoggio sotto la spalla, altrimenti prosegue l'avambraccio
    const spec = ((J.__pose && J.__pose.arms) || {})[S] || {};
    let dHand = dFa;
    if (spec.p && Pw[1] < Sj[1] - 1.5 && (spec.flat !== false)) {
      const hz = [dFa[0], 0, dFa[2]];
      dHand = v3.len(hz) > 0.2 ? v3.norm(v3.add(v3.norm(hz), [0, -0.15, 0])) : v3.norm(v3.add(fwd, [0, -0.15, 0]));
    }
    R[ha] = rotFromTo(rig.rest[ha], rig.hArm[S], dHand, na);
    H[ha] = wristW;
    out['elbow' + S] = E; out['wrist' + S] = wristW; out['palm' + S] = Pw; out['sh' + S] = Sj;
  }
  out.head = T('head', B.head.tail);
  out.neck = H.neck; out.hip = H.torso; out.chest = T('torso', rig.shC);
  out.R = R; out.H = H;
  return out;
}

// matrici di skinning (colonna per colonna, 4x4 per osso)
export function boneMatrices(rig, P, outArr) {
  const m = outArr || new Float32Array(rig.n * 16);
  for (const name in rig.B) {
    const b = rig.B[name], i = b.i, R = P.R[name], H = P.H[name];
    const t = v3.sub(H, mulRV(R, b.head));
    const o = i * 16;
    m[o] = R[0][0]; m[o + 1] = R[1][0]; m[o + 2] = R[2][0]; m[o + 3] = 0;
    m[o + 4] = R[0][1]; m[o + 5] = R[1][1]; m[o + 6] = R[2][1]; m[o + 7] = 0;
    m[o + 8] = R[0][2]; m[o + 9] = R[1][2]; m[o + 10] = R[2][2]; m[o + 11] = 0;
    m[o + 12] = t[0]; m[o + 13] = t[1]; m[o + 14] = t[2]; m[o + 15] = 1;
  }
  return m;
}

// punto più basso del corpo (campione di vertici) per appoggiare la figura al pavimento
export function lowestPoint(rig, mats) {
  let lo = Infinity;
  for (const s of rig.sample) {
    let y = 0;
    for (let q = 0; q < 4; q++) {
      const w = s.w[q];
      if (!w) continue;
      const o = s.j[q] * 16;
      y += w * (mats[o + 1] * s.p[0] + mats[o + 5] * s.p[1] + mats[o + 9] * s.p[2] + mats[o + 13]);
    }
    if (y < lo) lo = y;
  }
  return lo;
}

// solve 2D con la posa allegata (servono i suggerimenti 3D delle destinazioni)
export function solveWithPose(p) {
  const J = solve(p);
  J.__pose = p;
  return J;
}

// scostamento verticale costante per un'animazione: il primo fotogramma tocca terra
export function groundOffset(rig, anim) {
  if (anim.w3 && anim.w3.noSnap) return 0;
  const J = solveWithPose(poseAt(anim, 0));
  const P = pose3d(rig, anim, J, 0);
  const lo = lowestPoint(rig, boneMatrices(rig, P));
  return rig.ground - lo + (anim.w3 && anim.w3.lift ? anim.w3.lift : 0);
}

export { poseAt, cycleLength };
