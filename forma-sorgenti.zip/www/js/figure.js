// Forma — motore delle figure animate.
// Le pose sono descritte con poche coordinate (anca, tronco, bersagli di caviglie e polsi);
// ginocchia e gomiti vengono calcolati con una cinematica inversa a due segmenti.
// Convenzione angoli: 0 = su, 90 = avanti (+x), 180 = giù, -90 = indietro. Unità ~ cm, pavimento y = 0.

export const BODY = {
  thigh: 44, shank: 44, trunk: 52, neck: 8, headR: 10.5,
  upper: 30, fore: 28, foot: 16, heel: 4, sole: 6,
  pelvis: 18, shoulders: 30,
};

const SVGNS = 'http://www.w3.org/2000/svg';
const rad = (d) => (d * Math.PI) / 180;
const deg = (r) => (r * 180) / Math.PI;
export const dir = (a, l = 1) => [Math.sin(rad(a)) * l, -Math.cos(rad(a)) * l];
const angleOf = (v) => deg(Math.atan2(v[0], -v[1]));
const add = (p, v) => [p[0] + v[0], p[1] + v[1]];
const sub = (p, q) => [p[0] - q[0], p[1] - q[1]];
const mid2 = (p, q) => [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2];
const vlen = (v) => Math.hypot(v[0], v[1]);
const lerp = (a, b, t) => a + (b - a) * t;
const lerpAngle = (a, b, t) => {
  const d = ((((b - a) % 360) + 540) % 360) - 180;
  return a + d * t;
};
const ease = (t) => 0.5 - Math.cos(Math.PI * t) / 2;

function ik(root, target, a, b, sign) {
  const v = sub(target, root);
  const d = vlen(v);
  const base = angleOf(v);
  const dc = Math.min(Math.max(d, Math.abs(a - b) + 0.01), a + b - 0.01);
  const c = (a * a + dc * dc - b * b) / (2 * a * dc);
  const alpha = deg(Math.acos(Math.max(-1, Math.min(1, c))));
  const m = add(root, dir(base + sign * alpha, a));
  const end = add(m, dir(angleOf(sub(target, m)), b));
  return [m, end];
}

// ---------- risoluzione di una posa in giunture ----------
export function solve(p) {
  const B = BODY;
  const sc = p.scale || {};
  const s = (k) => (sc[k] == null ? 1 : sc[k]);
  const front = p.view === 'front';
  let hip, neck;
  if (p.root === 'neck') {
    neck = p.neck;
    hip = sub(neck, dir(p.trunk, B.trunk));
  } else {
    hip = p.hip;
    neck = add(hip, dir(p.trunk, B.trunk));
  }
  const J = { hip, neck };
  const headA = p.headA != null ? p.headA : p.trunk + (p.head || 0);
  J.head = add(neck, dir(headA, B.neck + B.headR));
  const perp = dir(p.trunk + 90, 1);
  const off = (pt, w) => [pt[0] + perp[0] * w, pt[1] + perp[1] * w];
  J.hipR = front ? off(hip, B.pelvis / 2) : hip;
  J.hipL = front ? off(hip, -B.pelvis / 2) : hip;
  J.shR = front ? off(neck, B.shoulders / 2) : neck;
  J.shL = front ? off(neck, -B.shoulders / 2) : neck;

  const bend = Object.assign(
    front ? { kR: -1, kL: 1, eR: -1, eL: 1 } : { kR: -1, kL: -1, eR: 1, eL: 1 },
    p.bend || {}
  );

  const target = (spec, root, l1, l2, trunk) => {
    if (!spec) return add(root, dir(180, (l1 + l2) * 0.97));
    if (spec.p) return spec.p;
    const a = spec.rel != null ? trunk + spec.rel : spec.a;
    return add(root, dir(a, (l1 + l2) * (spec.r == null ? 0.97 : spec.r)));
  };

  for (const S of ['R', 'L']) {
    const l1 = B.thigh * s('thigh' + S);
    const l2 = B.shank * s('shank' + S);
    const t = target(p.legs && p.legs[S], J['hip' + S], l1, l2, p.trunk);
    const [knee, ankle] = ik(J['hip' + S], t, l1, l2, bend['k' + S]);
    J['knee' + S] = knee;
    J['ankle' + S] = ankle;
    const defFoot = front ? (S === 'R' ? 90 : -90) : 90;
    const fa = p.feet && p.feet[S] != null ? p.feet[S] : defFoot;
    const soleSign = p.sole && p.sole[S] != null ? p.sole[S] : front && S === 'L' ? -1 : 1;
    const fl = (p.footScale != null ? p.footScale : front ? 0.55 : 1) * s('foot' + S);
    const n = dir(fa + 90 * soleSign, B.sole);
    J['heel' + S] = add(add(ankle, dir(fa, -B.heel * fl)), n);
    J['toe' + S] = add(add(ankle, dir(fa, B.foot * fl)), n);

    const a1 = B.upper * s('upper' + S);
    const a2 = B.fore * s('fore' + S);
    const ta = target(p.arms && p.arms[S], J['sh' + S], a1, a2, p.trunk);
    const [elbow, wrist] = ik(J['sh' + S], ta, a1, a2, bend['e' + S]);
    J['elbow' + S] = elbow;
    J['wrist' + S] = wrist;
  }
  J.wrists = mid2(J.wristR, J.wristL);
  J.knees = mid2(J.kneeR, J.kneeL);
  J.ankles = mid2(J.ankleR, J.ankleL);
  J.glute = add(hip, dir(p.trunk - 90, 6));
  return J;
}

// ---------- interpolazione tra due pose ----------
function lerpTarget(a, b, t) {
  if (!a || !b) return t < 0.5 ? a : b;
  let o;
  if (a.p && b.p) o = { p: [lerp(a.p[0], b.p[0], t), lerp(a.p[1], b.p[1], t)] };
  else if (a.rel != null && b.rel != null) o = { rel: lerpAngle(a.rel, b.rel, t), r: lerp(a.r ?? 0.97, b.r ?? 0.97, t) };
  else if (a.a != null && b.a != null) o = { a: lerpAngle(a.a, b.a, t), r: lerp(a.r ?? 0.97, b.r ?? 0.97, t) };
  else return t < 0.5 ? a : b;
  // suggerimenti per la figura 3D: distanza laterale (w) e mano piatta (flat)
  for (const key of ['w', 'eo', 'dz']) {
    if (a[key] != null || b[key] != null) o[key] = a[key] != null && b[key] != null ? lerp(a[key], b[key], t) : (a[key] ?? b[key]);
  }
  if (a.flat != null || b.flat != null) o.flat = t < 0.5 ? (a.flat ?? b.flat) : (b.flat ?? a.flat);
  return o;
}

function lerpMap(a = {}, b = {}, t, fn) {
  const out = {};
  for (const k of new Set([...Object.keys(a), ...Object.keys(b)])) out[k] = fn(a[k], b[k], t);
  return out;
}

export function lerpPose(a, b, t) {
  const num = (x, y, tt, d = 0) => lerp(x ?? d, y ?? d, tt);
  const p = {
    view: a.view,
    root: a.root,
    trunk: lerpAngle(a.trunk, b.trunk, t),
    head: num(a.head, b.head, t),
    legs: lerpMap(a.legs, b.legs, t, lerpTarget),
    arms: lerpMap(a.arms, b.arms, t, lerpTarget),
    feet: lerpMap(a.feet, b.feet, t, (x, y, tt) => (x == null || y == null ? (tt < 0.5 ? x : y) : lerpAngle(x, y, tt))),
    scale: lerpMap(a.scale, b.scale, t, (x, y, tt) => lerp(x ?? 1, y ?? 1, tt)),
    bend: t < 0.5 ? a.bend : b.bend,
    sole: a.sole,
    footScale: a.footScale,
  };
  if (a.headA != null || b.headA != null) p.headA = lerpAngle(a.headA ?? a.trunk, b.headA ?? b.trunk, t);
  if (a.root === 'neck') p.neck = [lerp(a.neck[0], b.neck[0], t), lerp(a.neck[1], b.neck[1], t)];
  else p.hip = [lerp(a.hip[0], b.hip[0], t), lerp(a.hip[1], b.hip[1], t)];
  return p;
}

// Unisce una posa base con modifiche (copia profonda di legs/arms/feet/scale/bend)
export function P(base, over = {}) {
  const out = { ...base, ...over };
  for (const k of ['legs', 'arms', 'feet', 'scale', 'bend', 'sole']) {
    if (base[k] || over[k]) out[k] = { ...(base[k] || {}), ...(over[k] || {}) };
  }
  return out;
}

// ---------- timeline ----------
// anim = { view, kf:[pose], t:[durata transizione i→i+1], h:[pausa sul fotogramma i], props, focus }
export function cycleLength(anim) {
  const n = anim.kf.length;
  if (n === 1) return 3;
  let tot = 0;
  for (let i = 0; i < n; i++) tot += (anim.t?.[i] ?? 1.2) + (anim.h?.[(i + 1) % n] ?? 0.3);
  return tot;
}

export function poseAt(anim, time) {
  const n = anim.kf.length;
  const base = (k) => ({ view: anim.view || 'side', root: anim.root || 'hip', ...k });
  if (n === 1) {
    // respiro leggero per le pose statiche
    const k = base(anim.kf[0]);
    const b = Math.sin((time / 3) * Math.PI * 2) * 0.6;
    return P(k, k.root === 'neck' ? {} : { hip: [k.hip[0], k.hip[1] - b] });
  }
  let tt = time % cycleLength(anim);
  for (let i = 0; i < n; i++) {
    const d = anim.t?.[i] ?? 1.2;
    const next = (i + 1) % n;
    if (tt < d) return lerpPose(base(anim.kf[i]), base(anim.kf[next]), ease(tt / d));
    tt -= d;
    const h = anim.h?.[next] ?? 0.3;
    if (tt < h) return base(anim.kf[next]);
    tt -= h;
  }
  return base(anim.kf[0]);
}

// ---------- disegno ----------
const SEG = [
  ['thighL', 'hipL', 'kneeL'], ['shankL', 'kneeL', 'ankleL'], ['footL', 'heelL', 'toeL'],
  ['upperL', 'shL', 'elbowL'], ['foreL', 'elbowL', 'wristL'],
  ['trunk', 'hip', 'neck'], ['neck', 'neck', 'head'],
  ['thighR', 'hipR', 'kneeR'], ['shankR', 'kneeR', 'ankleR'], ['footR', 'heelR', 'toeR'],
  ['upperR', 'shR', 'elbowR'], ['foreR', 'elbowR', 'wristR'],
];
const WIDTH = { trunk: 13, neck: 8, thighL: 11, thighR: 11, shankL: 9.5, shankR: 9.5, footL: 6, footR: 6, upperL: 8.5, upperR: 8.5, foreL: 7.5, foreR: 7.5 };

function el(tag, attrs, parent) {
  const e = document.createElementNS(SVGNS, tag);
  for (const k in attrs) e.setAttribute(k, attrs[k]);
  if (parent) parent.appendChild(e);
  return e;
}

function jointPos(J, at, dx = 0, dy = 0) {
  const p = Array.isArray(at) ? at : J[at];
  return [p[0] + dx, p[1] + dy];
}

function propBounds(pr, J) {
  switch (pr.t) {
    case 'box': case 'table': return [[pr.x, pr.y], [pr.x + pr.w, 0]];
    case 'chair': return [[pr.x, pr.top ?? pr.y], [pr.x + pr.w, 0]];
    case 'wall': return [[pr.x - 3, pr.top ?? -170], [pr.x + 3, 0]];
    case 'kb': case 'pack': { const c = jointPos(J, pr.at, pr.dx, pr.dy); return [[c[0] - 12, c[1] - 14], [c[0] + 12, c[1] + 14]]; }
    default: return null;
  }
}

export function boundsOf(anim) {
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = 0;
  const L = cycleLength(anim);
  const N = 24;
  for (let i = 0; i < N; i++) {
    const J = solve(poseAt(anim, (L * i) / N));
    for (const k of ['head', 'hip', 'neck', 'kneeR', 'kneeL', 'ankleR', 'ankleL', 'toeR', 'toeL', 'heelR', 'heelL', 'elbowR', 'elbowL', 'wristR', 'wristL']) {
      const p = J[k];
      const r = k === 'head' ? BODY.headR + 2 : 7;
      x0 = Math.min(x0, p[0] - r); x1 = Math.max(x1, p[0] + r);
      y0 = Math.min(y0, p[1] - r); y1 = Math.max(y1, p[1] + r);
    }
    for (const pr of anim.props || []) {
      const b = propBounds(pr, J);
      if (!b) continue;
      x0 = Math.min(x0, b[0][0]); y0 = Math.min(y0, b[0][1]);
      x1 = Math.max(x1, b[1][0]); y1 = Math.max(y1, b[1][1]);
    }
  }
  return { x0, y0, x1, y1: Math.max(y1, 0) };
}

export function viewBoxFor(anim, aspect = 1.25) {
  const b = boundsOf(anim);
  const pad = 14;
  let w = b.x1 - b.x0 + pad * 2;
  let h = b.y1 - b.y0 + pad * 2;
  if (w / h < aspect) w = h * aspect; else h = w / aspect;
  const cx = (b.x0 + b.x1) / 2;
  const top = b.y1 + pad - h; // floor anchored near the bottom
  return [cx - w / 2, top, w, h];
}

function drawProp(g, pr, J, vb) {
  const c = 'fig-prop';
  switch (pr.t) {
    case 'box':
      return el('rect', { x: pr.x, y: pr.y, width: pr.w, height: -pr.y, rx: 3, class: c + ' fill' }, g);
    case 'table': {
      el('rect', { x: pr.x, y: pr.y, width: pr.w, height: 6, rx: 2, class: c + ' fill' }, g);
      el('line', { x1: pr.x + 5, y1: pr.y + 6, x2: pr.x + 5, y2: 0, class: c + ' leg' }, g);
      return el('line', { x1: pr.x + pr.w - 5, y1: pr.y + 6, x2: pr.x + pr.w - 5, y2: 0, class: c + ' leg' }, g);
    }
    case 'chair': {
      // sedia vista di lato: seduta a y, schienale sul lato 'back' (x o x+w)
      const bx = pr.back === 'left' ? pr.x + 2 : pr.x + pr.w - 2;
      el('rect', { x: pr.x, y: pr.y, width: pr.w, height: 5, rx: 2, class: c + ' fill' }, g);
      el('line', { x1: bx, y1: pr.y, x2: bx, y2: pr.top, class: c + ' leg' }, g);
      el('line', { x1: pr.x + 3, y1: pr.y + 5, x2: pr.x + 3, y2: 0, class: c + ' leg' }, g);
      return el('line', { x1: pr.x + pr.w - 3, y1: pr.y + 5, x2: pr.x + pr.w - 3, y2: 0, class: c + ' leg' }, g);
    }
    case 'wall':
      return el('line', { x1: pr.x, y1: 0, x2: pr.x, y2: vb[1], class: c + ' wall' }, g);
    case 'mat':
      return el('rect', { x: pr.x, y: -2.5, width: pr.w, height: 2.5, rx: 1.2, class: 'fig-mat' }, g);
    default:
      return null;
  }
}

function drawDynamic(g, pr, J) {
  switch (pr.t) {
    case 'kb': {
      const p = jointPos(J, pr.at, pr.dx || 0, pr.dy || 0);
      const gg = el('g', { class: 'fig-kb' }, g);
      el('path', { d: `M ${p[0] - 6} ${p[1] - 3} Q ${p[0]} ${p[1] - 15} ${p[0] + 6} ${p[1] - 3}`, class: 'handle' }, gg);
      el('circle', { cx: p[0], cy: p[1] + 5, r: 9 }, gg);
      return gg;
    }
    case 'pack': {
      const p = jointPos(J, pr.at, pr.dx || 0, pr.dy || 0);
      return el('rect', { x: p[0] - 10, y: p[1] - 4, width: 20, height: 22, rx: 6, class: 'fig-pack' }, g);
    }
    case 'band': {
      if (pr.side) return null;
      const a = jointPos(J, pr.from === 'wrists' ? 'wristR' : pr.from);
      const b = jointPos(J, pr.to);
      return el('line', { x1: a[0], y1: a[1], x2: b[0], y2: b[1], class: 'fig-band' }, g);
    }
    case 'miniband': {
      const f = pr.at === 'ankles' ? 0.75 : 0.25;
      const pa = [lerp(J.kneeL[0], J.ankleL[0], f), lerp(J.kneeL[1], J.ankleL[1], f)];
      const pb = [lerp(J.kneeR[0], J.ankleR[0], f), lerp(J.kneeR[1], J.ankleR[1], f)];
      if (vlen(sub(pa, pb)) < 4) return el('circle', { cx: pa[0], cy: pa[1], r: 7, class: 'fig-ring' }, g);
      return el('line', { x1: pa[0], y1: pa[1], x2: pb[0], y2: pb[1], class: 'fig-band' }, g);
    }
    case 'bar': {
      el('line', { x1: pr.x - 14, y1: pr.y, x2: pr.x + 14, y2: pr.y, class: 'fig-prop leg' }, g);
      return null;
    }
    case 'trx': {
      const ends = pr.to === 'wrists' ? ['wristR'] : pr.to === 'heels' ? ['heelR'] : pr.to === 'knees' ? ['kneeR'] : [pr.to];
      for (const e of ends) { const b = jointPos(J, e); el('line', { x1: pr.at[0], y1: pr.at[1], x2: b[0], y2: b[1], class: pr.band ? 'fig-band' : 'fig-strap' }, g); }
      return null;
    }
    case 'ball': {
      const at = pr.at === 'heels' ? 'heelR' : pr.at === 'elbows' ? 'elbowR' : pr.at;
      const p = jointPos(J, at);
      return el('circle', { cx: p[0] - (pr.at === 'elbows' ? 0 : 8), cy: -(pr.r || 30), r: pr.r || 30, class: 'fig-ball' }, g);
    }
    case 'ankle': {
      for (const S of ['L', 'R']) { const p = jointPos(J, 'ankle' + S); el('circle', { cx: p[0], cy: p[1], r: 4.5, class: 'fig-cuff' }, g); }
      return null;
    }
    case 'backband': {
      return el('polyline', { points: [J.wristL, J.neck, J.wristR].map((p) => p.join(',')).join(' '), class: 'fig-band', fill: 'none' }, g);
    }
    case 'towel': {
      const p = jointPos(J, pr.at);
      return el('rect', { x: p[0] - 9, y: -3, width: 18, height: 3, rx: 1.5, class: 'fig-band soft' }, g);
    }
    default:
      return null;
  }
}

export function renderFigure(svg, anim, J, vb) {
  while (svg.firstChild) svg.removeChild(svg.firstChild);
  const back = el('g', {}, svg);
  el('line', { x1: vb[0] - 10, y1: 0, x2: vb[0] + vb[2] + 10, y2: 0, class: 'fig-floor' }, back);
  for (const pr of anim.props || []) drawProp(back, pr, J, vb);
  const body = el('g', { class: 'fig-body' }, svg);
  const focus = new Set(anim.focus || []);
  const front = anim.view === 'front';
  const order = SEG.slice();
  const segEls = {};
  for (const [name, a, b] of order) {
    if (name === 'trunk' && focus.has('glute')) {
      segEls.glute = el('circle', { r: 8.5, class: 'fig-focus' }, body);
    }
    const far = !front && name.endsWith('L');
    let cls = far ? 'fig-far' : 'fig-near';
    if (focus.has(name)) cls = far ? 'fig-focus far' : 'fig-focus';
    segEls[name] = el('line', { 'stroke-width': WIDTH[name], class: cls }, body);
    segEls[name]._ab = [a, b];
  }
  segEls.head = el('circle', { r: BODY.headR, class: 'fig-head' }, body);
  const dyn = el('g', {}, svg);
  return { segEls, dyn };
}

export function updateFigure(nodes, anim, J) {
  const { segEls, dyn } = nodes;
  for (const k in segEls) {
    const e = segEls[k];
    if (k === 'head') { e.setAttribute('cx', J.head[0].toFixed(1)); e.setAttribute('cy', J.head[1].toFixed(1)); continue; }
    if (k === 'glute') { e.setAttribute('cx', J.glute[0].toFixed(1)); e.setAttribute('cy', J.glute[1].toFixed(1)); continue; }
    const [a, b] = e._ab;
    e.setAttribute('x1', J[a][0].toFixed(1)); e.setAttribute('y1', J[a][1].toFixed(1));
    e.setAttribute('x2', J[b][0].toFixed(1)); e.setAttribute('y2', J[b][1].toFixed(1));
  }
  while (dyn.firstChild) dyn.removeChild(dyn.firstChild);
  for (const pr of anim.props || []) drawDynamic(dyn, pr, J);
}

// Crea un <svg> animato per un'animazione. Ritorna { svg, play, stop, setSpeed }.
export function createFigure(anim, { aspect = 1.25, autoplay = true, still = 0.5, label = '' } = {}) {
  const vb = viewBoxFor(anim, aspect);
  const svg = document.createElementNS(SVGNS, 'svg');
  svg.setAttribute('viewBox', vb.map((v) => v.toFixed(1)).join(' '));
  svg.setAttribute('class', 'fig');
  svg.setAttribute('role', 'img');
  if (label) svg.setAttribute('aria-label', label);
  const J0 = solve(poseAt(anim, cycleLength(anim) * still));
  const nodes = renderFigure(svg, anim, J0, vb);
  updateFigure(nodes, anim, J0);
  let raf = 0, t0 = 0, speed = 1, running = false;
  const reduce = typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;
  const frame = (ts) => {
    if (!running) return;
    if (!t0) t0 = ts;
    const time = ((ts - t0) / 1000) * speed;
    updateFigure(nodes, anim, solve(poseAt(anim, time)));
    raf = requestAnimationFrame(frame);
  };
  const api = {
    svg,
    play() { if (running || reduce) return; running = true; t0 = 0; raf = requestAnimationFrame(frame); },
    stop() { running = false; cancelAnimationFrame(raf); },
    setSpeed(s) { speed = s; },
    get running() { return running; },
  };
  if (autoplay) api.play();
  return api;
}

// Versione testuale (per il foglio di controllo e per i test): SVG statico di un istante
export function staticSVG(anim, time, aspect = 1.25) {
  const vb = viewBoxFor(anim, aspect);
  const J = solve(poseAt(anim, time));
  const segs = [];
  const focus = new Set(anim.focus || []);
  const front = anim.view === 'front';
  const col = (name) => {
    const far = !front && name.endsWith('L');
    if (focus.has(name)) return far ? '#e8998b' : '#d3412e';
    return far ? '#9aa6a0' : '#1d2328';
  };
  let out = `<svg xmlns="${SVGNS}" viewBox="${vb.map((v) => v.toFixed(1)).join(' ')}">`;
  out += `<line x1="${vb[0] - 10}" y1="0" x2="${vb[0] + vb[2] + 10}" y2="0" stroke="#b9c2b8" stroke-width="2.5"/>`;
  for (const pr of anim.props || []) {
    if (pr.t === 'box') out += `<rect x="${pr.x}" y="${pr.y}" width="${pr.w}" height="${-pr.y}" rx="3" fill="#cdd5cc"/>`;
    if (pr.t === 'table') out += `<rect x="${pr.x}" y="${pr.y}" width="${pr.w}" height="6" fill="#cdd5cc"/><line x1="${pr.x + 5}" y1="${pr.y}" x2="${pr.x + 5}" y2="0" stroke="#cdd5cc" stroke-width="4"/><line x1="${pr.x + pr.w - 5}" y1="${pr.y}" x2="${pr.x + pr.w - 5}" y2="0" stroke="#cdd5cc" stroke-width="4"/>`;
    if (pr.t === 'chair') { const bx = pr.back === 'left' ? pr.x + 2 : pr.x + pr.w - 2; out += `<rect x="${pr.x}" y="${pr.y}" width="${pr.w}" height="5" fill="#cdd5cc"/><line x1="${bx}" y1="${pr.y}" x2="${bx}" y2="${pr.top}" stroke="#cdd5cc" stroke-width="4"/><line x1="${pr.x + 3}" y1="${pr.y}" x2="${pr.x + 3}" y2="0" stroke="#cdd5cc" stroke-width="4"/><line x1="${pr.x + pr.w - 3}" y1="${pr.y}" x2="${pr.x + pr.w - 3}" y2="0" stroke="#cdd5cc" stroke-width="4"/>`; }
    if (pr.t === 'wall') out += `<line x1="${pr.x}" y1="0" x2="${pr.x}" y2="${vb[1]}" stroke="#cdd5cc" stroke-width="5"/>`;
  }
  for (const [name, a, b] of SEG) {
    if (name === 'trunk' && focus.has('glute')) out += `<circle cx="${J.glute[0]}" cy="${J.glute[1]}" r="8.5" fill="#d3412e"/>`;
    out += `<line x1="${J[a][0].toFixed(1)}" y1="${J[a][1].toFixed(1)}" x2="${J[b][0].toFixed(1)}" y2="${J[b][1].toFixed(1)}" stroke="${col(name)}" stroke-width="${WIDTH[name]}" stroke-linecap="round"/>`;
  }
  out += `<circle cx="${J.head[0]}" cy="${J.head[1]}" r="${BODY.headR}" fill="#1d2328"/>`;
  for (const pr of anim.props || []) {
    if (pr.t === 'kb') { const p = jointPos(J, pr.at, pr.dx || 0, pr.dy || 0); out += `<circle cx="${p[0]}" cy="${p[1] + 5}" r="9" fill="#3b4148"/>`; }
    if (pr.t === 'pack') { const p = jointPos(J, pr.at, pr.dx || 0, pr.dy || 0); out += `<rect x="${p[0] - 10}" y="${p[1] - 4}" width="20" height="22" rx="6" fill="#4d6a8a"/>`; }
    if (pr.t === 'band' && !pr.side) { const a = jointPos(J, pr.from), b = jointPos(J, pr.to); out += `<line x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}" stroke="#3c9a5f" stroke-width="3"/>`; }
    if (pr.t === 'miniband') { const f = pr.at === 'ankles' ? 0.75 : 0.25; const pa = [lerp(J.kneeL[0], J.ankleL[0], f), lerp(J.kneeL[1], J.ankleL[1], f)], pb = [lerp(J.kneeR[0], J.ankleR[0], f), lerp(J.kneeR[1], J.ankleR[1], f)]; out += `<line x1="${pa[0]}" y1="${pa[1]}" x2="${pb[0]}" y2="${pb[1]}" stroke="#3c9a5f" stroke-width="4"/>`; }
    if (pr.t === 'towel') { const p = jointPos(J, pr.at); out += `<rect x="${p[0] - 9}" y="-3" width="18" height="3" fill="#3c9a5f"/>`; }
  }
  out += '</svg>';
  return out;
}
