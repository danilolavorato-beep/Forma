// Forma — funzioni del telefono: schermo acceso, vibrazione, voce, suoni, condivisione.
// Nell'app Android usa i plugin Capacitor; nel browser ripiega sulle API web.
import { get } from './store.js';

const Cap = typeof window !== 'undefined' ? window.Capacitor : undefined;
const P = (Cap && Cap.Plugins) || {};
export const isNative = !!(Cap && typeof Cap.isNativePlatform === 'function' && Cap.isNativePlatform());

const settings = () => get().settings;

// ---------- schermo sempre acceso durante l'allenamento ----------
let wakeLock = null;
export async function keepAwake(on) {
  try {
    if (P.KeepAwake) {
      await (on ? P.KeepAwake.keepAwake() : P.KeepAwake.allowSleep());
      return;
    }
    if (on && 'wakeLock' in navigator) {
      wakeLock = await navigator.wakeLock.request('screen');
    } else if (!on && wakeLock) {
      await wakeLock.release();
      wakeLock = null;
    }
  } catch { /* non disponibile */ }
}
// il wake lock web si perde quando la pagina va in background: lo richiediamo di nuovo
if (typeof document !== 'undefined') {
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && wakeLock === null && document.body.classList.contains('in-workout')) keepAwake(true);
  });
}

// ---------- vibrazione ----------
export function vibrate(ms = 200) {
  if (!settings().vibe) return;
  try {
    if (P.Haptics) P.Haptics.vibrate({ duration: ms });
    else if (navigator.vibrate) navigator.vibrate(ms);
  } catch { /* niente */ }
}

// ---------- suoni ----------
let ctx = null;
export function unlockAudio() {
  try {
    if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
    if (ctx.state === 'suspended') ctx.resume();
  } catch { /* niente */ }
}
function tone(freq, dur, when = 0, gain = 0.18) {
  if (!ctx) return;
  const t0 = ctx.currentTime + when;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = 'sine';
  o.frequency.value = freq;
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(gain, t0 + 0.015);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.connect(g).connect(ctx.destination);
  o.start(t0);
  o.stop(t0 + dur + 0.02);
}
export function beep(kind = 'tick') {
  if (!settings().sound) return;
  unlockAudio();
  if (kind === 'tick') tone(880, 0.12);
  else if (kind === 'go') tone(1320, 0.28, 0, 0.22);
  else if (kind === 'end') { tone(660, 0.16); tone(990, 0.3, 0.18); }
  else if (kind === 'done') { tone(523, 0.14); tone(659, 0.14, 0.15); tone(784, 0.3, 0.3); }
}

// ---------- voce ----------
let ttsBroken = false;
export async function speak(text) {
  if (!settings().voice || !text) return;
  try {
    if (P.TextToSpeech && !ttsBroken) {
      await P.TextToSpeech.speak({ text, lang: 'it-IT', rate: 1.0, pitch: 1.0, volume: 1.0, queueStrategy: 0 });
      return;
    }
  } catch {
    ttsBroken = true; // lingua non installata: usiamo solo i suoni
  }
  try {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'it-IT';
      window.speechSynthesis.speak(u);
    }
  } catch { /* niente */ }
}
export function stopSpeaking() {
  try { if (P.TextToSpeech) P.TextToSpeech.stop(); } catch { /* niente */ }
  try { if ('speechSynthesis' in window) window.speechSynthesis.cancel(); } catch { /* niente */ }
}

// ---------- barre di sistema (icone chiare o scure) ----------
export function setSystemBars(dark) {
  try { if (P.SystemBars) P.SystemBars.setStyle({ style: dark ? 'DARK' : 'LIGHT' }); } catch { /* niente */ }
}

// ---------- backup: condividi o scarica ----------
export async function shareBackup(json, filename) {
  if (P.Share) {
    await P.Share.share({ title: 'Backup Forma', text: json, dialogTitle: 'Salva il backup' });
    return 'shared';
  }
  const blob = new Blob([json], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  return 'downloaded';
}

export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch { ok = false; }
    ta.remove();
    return ok;
  }
}
