// Forma — avvio, tema e navigazione.
import * as store from './store.js';
import { h, clear, icon } from './ui.js';
import { setSystemBars, isNative } from './native.js';
import { handleBack } from './views/player.js';
import { renderHome } from './views/home.js';
import { renderProgram } from './views/program.js';
import { renderLibrary, renderExercise } from './views/library.js';
import { renderProgress } from './views/progress.js';
import { renderGuide } from './views/guide.js';
import { renderSettings } from './views/settings.js';
import { renderEquipment } from './views/equipment.js';
import { renderOnboarding } from './views/onboarding.js';
import { resumeIfInterrupted, isPlaying } from './views/player.js';
import { initFigures } from './figures.js';

const TABS = [
  ['oggi', 'Oggi', 'oggi'],
  ['programma', 'Programma', 'programma'],
  ['esercizi', 'Esercizi', 'esercizi'],
  ['progressi', 'Progressi', 'progressi'],
  ['guida', 'Guida', 'guida'],
];

const app = document.getElementById('app');

export function applyTheme() {
  const t = store.get().settings.theme;
  const root = document.documentElement;
  if (t === 'light' || t === 'dark') root.setAttribute('data-theme', t);
  else root.removeAttribute('data-theme');
  const dark = t === 'dark' || (t !== 'light' && window.matchMedia('(prefers-color-scheme: dark)').matches);
  setSystemBars(dark);
  const meta = document.querySelector('meta[name="theme-color"]:not([media])') || document.head.appendChild(h('meta', { name: 'theme-color' }));
  meta.setAttribute('content', dark ? '#151a1e' : '#edf0eb');
}

function parseRoute() {
  const raw = (location.hash || '#/oggi').slice(2);
  const [name, ...rest] = raw.split('/');
  return { name: name || 'oggi', arg: rest.join('/') };
}

export function go(path) {
  if (location.hash !== `#/${path}`) location.hash = `#/${path}`;
  else render();
}

function shell(route) {
  const top = h('header', { class: 'top' });
  const main = h('main', { class: 'view', id: 'view' });
  const nav = h('nav', { class: 'tabs', 'aria-label': 'Sezioni' },
    TABS.map(([id, label, ic]) => h('a', {
      href: `#/${id}`,
      'aria-current': route.name === id || (id === 'esercizi' && route.name === 'esercizio') || (id === 'programma' && route.name === 'attrezzatura') ? 'page' : null,
    }, icon(ic), label)));
  clear(app).append(top, main, nav);
  return { top, main };
}

export function render() {
  const s = store.get();
  if (!s.settings.onboarded) {
    clear(app);
    renderOnboarding(app, () => { applyTheme(); go('oggi'); });
    return;
  }
  const route = parseRoute();
  const { top, main } = shell(route);
  const ctx = { top, main, go, render, route, applyTheme };
  switch (route.name) {
    case 'programma': renderProgram(ctx); break;
    case 'esercizi': renderLibrary(ctx); break;
    case 'esercizio': renderExercise(ctx, decodeURIComponent(route.arg)); break;
    case 'progressi': renderProgress(ctx); break;
    case 'guida': renderGuide(ctx, route.arg); break;
    case 'impostazioni': renderSettings(ctx); break;
    case 'attrezzatura': renderEquipment(ctx); break;
    default: renderHome(ctx);
  }
  window.scrollTo(0, 0);
}

window.addEventListener('hashchange', () => { if (!isPlaying()) render(); });
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);

store.load();
applyTheme();
// il modello 3D si carica prima della prima schermata (con un limite di tempo)
initFigures(store.get().settings.figure3d !== false).finally(() => {
  document.documentElement.classList.remove('booting');
  render();
  resumeIfInterrupted();
});

// Tasto indietro di Android: chiude i fogli aperti, chiede conferma durante l'allenamento,
// torna alla schermata precedente e, da Oggi, manda l'app in background.
const AppPlugin = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
if (AppPlugin && AppPlugin.addListener) {
  AppPlugin.addListener('backButton', () => {
    const open = document.querySelector('.scrim.open');
    if (open) { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' })); return; }
    if (handleBack()) return;
    const route = parseRoute();
    if (route.name === 'esercizio') { go('esercizi'); return; }
    if (route.name !== 'oggi' && store.get().settings.onboarded) { go('oggi'); return; }
    if (AppPlugin.minimizeApp) AppPlugin.minimizeApp();
  });
}

if ('serviceWorker' in navigator && !isNative && location.protocol === 'https:') {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}
