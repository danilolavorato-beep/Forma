// Forma — figura 3D: caricamento del modello (GLB generato da tools/model), skinning e disegno WebGL.
// Un solo contesto WebGL condiviso disegna tutte le figure e copia ogni fotogramma nel loro <canvas> 2D:
// i browser limitano il numero di contesti WebGL, mentre le figure in pagina possono essere molte.

// ---------------------------------------------------------------- matematica minima
export const v3 = {
  add: (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]],
  sub: (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]],
  mul: (a, s) => [a[0] * s, a[1] * s, a[2] * s],
  dot: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2],
  cross: (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]],
  len: (a) => Math.hypot(a[0], a[1], a[2]),
  norm: (a) => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; },
  lerp: (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t],
};

// matrici 3x3 come array di righe; colonne = immagini degli assi
export function frame(r, s) {
  // base ortonormale con r come primo asse e s (ortogonalizzato) come secondo
  const a = v3.norm(r);
  let b = v3.sub(s, v3.mul(a, v3.dot(s, a)));
  if (v3.len(b) < 1e-6) b = Math.abs(a[0]) < 0.9 ? v3.sub([1, 0, 0], v3.mul(a, a[0])) : v3.sub([0, 0, 1], v3.mul(a, a[2]));
  b = v3.norm(b);
  const c = v3.cross(a, b);
  return [a, b, c];
}
// rotazione che porta la base (r,s) nella base (d,t)
export function rotFromTo(r, s, d, t) {
  const A = frame(r, s), B = frame(d, t);
  const R = [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
  for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) R[i][j] = B[0][i] * A[0][j] + B[1][i] * A[1][j] + B[2][i] * A[2][j];
  return R;
}
export const mulRV = (R, v) => [R[0][0] * v[0] + R[0][1] * v[1] + R[0][2] * v[2], R[1][0] * v[0] + R[1][1] * v[1] + R[1][2] * v[2], R[2][0] * v[0] + R[2][1] * v[1] + R[2][2] * v[2]];
export const mulRR = (A, B) => A.map((row) => [0, 1, 2].map((j) => row[0] * B[0][j] + row[1] * B[1][j] + row[2] * B[2][j]));
export const rotAxis = (axis, ang) => {
  const [x, y, z] = v3.norm(axis), c = Math.cos(ang), s = Math.sin(ang), C = 1 - c;
  return [[c + x * x * C, x * y * C - z * s, x * z * C + y * s], [y * x * C + z * s, c + y * y * C, y * z * C - x * s], [z * x * C - y * s, z * y * C + x * s, c + z * z * C]];
};
export function slerpR(A, B, t) {
  // interpolazione via quaternioni
  const q1 = toQuat(A), q2 = toQuat(B);
  let d = q1[0] * q2[0] + q1[1] * q2[1] + q1[2] * q2[2] + q1[3] * q2[3];
  if (d < 0) { q2[0] = -q2[0]; q2[1] = -q2[1]; q2[2] = -q2[2]; q2[3] = -q2[3]; d = -d; }
  let q;
  if (d > 0.9995) q = q1.map((v, i) => v + (q2[i] - v) * t);
  else {
    const th = Math.acos(d), s1 = Math.sin((1 - t) * th) / Math.sin(th), s2 = Math.sin(t * th) / Math.sin(th);
    q = q1.map((v, i) => v * s1 + q2[i] * s2);
  }
  const l = Math.hypot(...q);
  return fromQuat(q.map((v) => v / l));
}
function toQuat(m) {
  const tr = m[0][0] + m[1][1] + m[2][2];
  let w, x, y, z;
  if (tr > 0) { const s = Math.sqrt(tr + 1) * 2; w = s / 4; x = (m[2][1] - m[1][2]) / s; y = (m[0][2] - m[2][0]) / s; z = (m[1][0] - m[0][1]) / s; }
  else if (m[0][0] > m[1][1] && m[0][0] > m[2][2]) { const s = Math.sqrt(1 + m[0][0] - m[1][1] - m[2][2]) * 2; w = (m[2][1] - m[1][2]) / s; x = s / 4; y = (m[0][1] + m[1][0]) / s; z = (m[0][2] + m[2][0]) / s; }
  else if (m[1][1] > m[2][2]) { const s = Math.sqrt(1 + m[1][1] - m[0][0] - m[2][2]) * 2; w = (m[0][2] - m[2][0]) / s; x = (m[0][1] + m[1][0]) / s; y = s / 4; z = (m[1][2] + m[2][1]) / s; }
  else { const s = Math.sqrt(1 + m[2][2] - m[0][0] - m[1][1]) * 2; w = (m[1][0] - m[0][1]) / s; x = (m[0][2] + m[2][0]) / s; y = (m[1][2] + m[2][1]) / s; z = s / 4; }
  return [x, y, z, w];
}
function fromQuat([x, y, z, w]) {
  return [
    [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
    [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
    [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
  ];
}

// matrici 4x4 colonna per colonna (WebGL)
const m4 = {
  persp(fovy, aspect, near, far) {
    const f = 1 / Math.tan(fovy / 2), nf = 1 / (near - far);
    return new Float32Array([f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) * nf, -1, 0, 0, 2 * far * near * nf, 0]);
  },
  lookAt(eye, at, up) {
    const z = v3.norm(v3.sub(eye, at)), x = v3.norm(v3.cross(up, z)), y = v3.cross(z, x);
    return new Float32Array([x[0], y[0], z[0], 0, x[1], y[1], z[1], 0, x[2], y[2], z[2], 0, -v3.dot(x, eye), -v3.dot(y, eye), -v3.dot(z, eye), 1]);
  },
  mul(a, b) {
    const o = new Float32Array(16);
    for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) {
      let s = 0;
      for (let k = 0; k < 4; k++) s += a[k * 4 + j] * b[i * 4 + k];
      o[i * 4 + j] = s;
    }
    return o;
  },
};

// ---------------------------------------------------------------- caricamento del GLB
export async function loadModel(url) {
  const buf = await (await fetch(url)).arrayBuffer();
  const dv = new DataView(buf);
  if (dv.getUint32(0, true) !== 0x46546c67) throw new Error('GLB non valido');
  const jsonLen = dv.getUint32(12, true);
  const json = JSON.parse(new TextDecoder().decode(new Uint8Array(buf, 20, jsonLen)));
  const binOff = 20 + jsonLen + 8;
  const view = (i) => { const v = json.bufferViews[i]; return new Uint8Array(buf, binOff + (v.byteOffset || 0), v.byteLength); };
  const CT = { 5126: Float32Array, 5123: Uint16Array, 5121: Uint8Array };
  const acc = (i) => {
    const a = json.accessors[i]; const v = json.bufferViews[a.bufferView];
    const n = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT4: 16 }[a.type];
    const T = CT[a.componentType];
    return new T(buf, binOff + (v.byteOffset || 0), a.count * n);
  };
  const prims = json.meshes[0].primitives.map((p) => {
    const out = { material: p.material, indices: acc(p.indices) };
    for (const k in p.attributes) out[k] = acc(p.attributes[k]);
    return out;
  });
  const bones = json.nodes.filter((n) => n.extras && n.extras.head).map((n) => ({ name: n.name, head: n.extras.head, tail: n.extras.tail }));
  const parentOf = {};
  json.nodes.forEach((n, i) => (n.children || []).forEach((c) => { parentOf[json.nodes[c].name] = n.name; }));
  bones.forEach((b) => { b.parent = parentOf[b.name] || null; });
  let image = null;
  if (json.images && json.images.length) {
    const blob = new Blob([view(json.images[0].bufferView)], { type: json.images[0].mimeType });
    image = await createImageBitmap(blob);
  }
  return { json, prims, bones, image, ground: json.extras.ground, muscles: json.extras.muscles };
}

// ---------------------------------------------------------------- shader
const VS = `
precision highp float;
attribute vec3 aPos; attribute vec3 aNor; attribute vec2 aUV; attribute vec3 aCol;
attribute vec4 aJ; attribute vec4 aW; attribute float aMus;
uniform mat4 uBones[19];
uniform mat4 uVP;
uniform float uHi[14];
uniform float uShadow; uniform vec3 uLight; uniform float uGround;
uniform float uSkinned; uniform mat4 uModel;
varying vec3 vN; varying vec3 vP; varying vec2 vUV; varying vec3 vCol; varying float vHi;
void main(){
  vec4 p = vec4(aPos, 1.0); vec4 n = vec4(aNor, 0.0);
  if (uSkinned > 0.5) {
    mat4 S = aW.x * uBones[int(aJ.x)] + aW.y * uBones[int(aJ.y)] + aW.z * uBones[int(aJ.z)] + aW.w * uBones[int(aJ.w)];
    p = S * p; n = S * n;
  } else { p = uModel * p; n = uModel * n; }
  if (uShadow > 0.5) {
    // proiezione sul pavimento lungo la direzione della luce
    float t = (p.y - uGround) / max(uLight.y, 0.05);
    p.xyz = p.xyz - uLight * t; p.y = uGround + 0.002;
  }
  vP = p.xyz; vN = n.xyz; vUV = aUV; vCol = aCol;
  vHi = uHi[int(aMus + 0.5)];
  gl_Position = uVP * p;
}`;

const FS = `
precision mediump float;
varying vec3 vN; varying vec3 vP; varying vec2 vUV; varying vec3 vCol; varying float vHi;
uniform sampler2D uTex; uniform float uMode; // 0 texture, 1 colore per vertice, 2 colore fisso, 3 ombra, 4 pavimento
uniform vec3 uColor; uniform float uAlpha; uniform vec3 uEye; uniform vec3 uKey; uniform vec3 uHiCol; uniform float uPulse;
uniform float uSpec; uniform vec3 uFloorC; uniform float uFloorR; uniform vec3 uSky; uniform vec3 uGnd;
void main(){
  if (uMode > 3.5) { // pavimento: disco con sfumatura
    float d = length(vP.xz - uFloorC.xz) / uFloorR;
    float a = uAlpha * smoothstep(1.0, 0.35, d);
    gl_FragColor = vec4(uColor * a, a);
    return;
  }
  if (uMode > 2.5) { gl_FragColor = vec4(0.0, 0.0, 0.0, uAlpha); return; }
  vec3 base = uMode < 0.5 ? texture2D(uTex, vUV).rgb : (uMode < 1.5 ? vCol : uColor);
  base = pow(base, vec3(2.2));
  if (vHi > 0.01) base = mix(base, pow(uHiCol, vec3(2.2)), clamp(vHi * (0.36 + 0.14 * uPulse), 0.0, 0.6));
  vec3 N = normalize(vN); vec3 V = normalize(uEye - vP);
  if (dot(N, V) < 0.0) N = -N;
  float wrap = 0.35;
  float kd = max((dot(N, uKey) + wrap) / (1.0 + wrap), 0.0);
  vec3 fillDir = normalize(vec3(-uKey.x, 0.25, -uKey.z));
  float fd = max(dot(N, fillDir), 0.0) * 0.28;
  vec3 hemi = mix(uGnd, uSky, N.y * 0.5 + 0.5);
  float rim = pow(1.0 - max(dot(N, V), 0.0), 3.0) * 0.35;
  vec3 H = normalize(uKey + V);
  float sp = pow(max(dot(N, H), 0.0), 48.0) * uSpec;
  vec3 c = base * (hemi * 0.55 + vec3(1.0, 0.97, 0.92) * kd * 0.95 + fd) + vec3(sp) + rim * vec3(0.9, 0.95, 1.0) * 0.6;
  c = pow(c, vec3(1.0 / 2.2));
  gl_FragColor = vec4(c * uAlpha, uAlpha);
}`;

const ID4 = new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);

// ---------------------------------------------------------------- renderer condiviso
let shared = null;

function compile(gl, type, src) {
  const s = gl.createShader(type);
  gl.shaderSource(s, src); gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
  return s;
}

function makeBuffer(gl, data, target = gl.ARRAY_BUFFER) {
  const b = gl.createBuffer();
  gl.bindBuffer(target, b); gl.bufferData(target, data, gl.STATIC_DRAW);
  return b;
}

export function getRenderer() {
  if (shared) return shared;
  const canvas = document.createElement('canvas');
  canvas.width = 2; canvas.height = 2;
  const gl = canvas.getContext('webgl', { alpha: true, antialias: true, premultipliedAlpha: true, preserveDrawingBuffer: true, stencil: true });
  if (!gl) throw new Error('WebGL non disponibile');
  const prog = gl.createProgram();
  gl.attachShader(prog, compile(gl, gl.VERTEX_SHADER, VS));
  gl.attachShader(prog, compile(gl, gl.FRAGMENT_SHADER, FS));
  gl.linkProgram(prog);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
  const loc = {};
  const n = gl.getProgramParameter(prog, gl.ACTIVE_UNIFORMS);
  for (let i = 0; i < n; i++) { const u = gl.getActiveUniform(prog, i); loc[u.name.replace('[0]', '')] = gl.getUniformLocation(prog, u.name); }
  const attr = {};
  for (const a of ['aPos', 'aNor', 'aUV', 'aCol', 'aJ', 'aW', 'aMus']) attr[a] = gl.getAttribLocation(prog, a);
  shared = { canvas, gl, prog, loc, attr, model: null, meshes: [], lost: false };
  canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); shared.lost = true; });
  return shared;
}

export function uploadModel(R, model) {
  const { gl } = R;
  R.model = model;
  R.meshes = model.prims.map((p) => {
    const m = { material: p.material, count: p.indices.length, buf: {} };
    m.buf.idx = makeBuffer(gl, p.indices, gl.ELEMENT_ARRAY_BUFFER);
    m.buf.aPos = makeBuffer(gl, p.POSITION);
    m.buf.aNor = makeBuffer(gl, p.NORMAL);
    if (p.TEXCOORD_0) m.buf.aUV = makeBuffer(gl, p.TEXCOORD_0);
    if (p.COLOR_0) m.buf.aCol = makeBuffer(gl, p.COLOR_0);
    m.buf.aJ = makeBuffer(gl, new Float32Array(p.JOINTS_0));
    m.buf.aW = makeBuffer(gl, p.WEIGHTS_0);
    if (p._MUSCLE) m.buf.aMus = makeBuffer(gl, p._MUSCLE);
    return m;
  });
  if (model.image) {
    const t = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, model.image);
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    R.tex = t;
  }
}

// geometrie semplici per gli oggetti (non skinnate)
export function solidMesh(R, geo) {
  const { gl } = R;
  return {
    count: geo.idx.length,
    buf: { idx: makeBuffer(gl, new Uint16Array(geo.idx), gl.ELEMENT_ARRAY_BUFFER), aPos: makeBuffer(gl, new Float32Array(geo.pos)), aNor: makeBuffer(gl, new Float32Array(geo.nor)) },
  };
}

function bindAttr(R, name, buf, size) {
  const { gl, attr } = R;
  const a = attr[name];
  if (a < 0) return;
  if (buf) { gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.enableVertexAttribArray(a); gl.vertexAttribPointer(a, size, gl.FLOAT, false, 0, 0); }
  else { gl.disableVertexAttribArray(a); if (size === 4) gl.vertexAttrib4f(a, 0, 0, 0, 0); else if (size === 1) gl.vertexAttrib1f(a, 0); else gl.vertexAttrib3f(a, 0.5, 0.5, 0.5); }
}

function drawMesh(R, m) {
  const { gl } = R;
  bindAttr(R, 'aPos', m.buf.aPos, 3);
  bindAttr(R, 'aNor', m.buf.aNor, 3);
  bindAttr(R, 'aUV', m.buf.aUV, 2);
  bindAttr(R, 'aCol', m.buf.aCol, 3);
  bindAttr(R, 'aJ', m.buf.aJ, 4);
  bindAttr(R, 'aW', m.buf.aW, 4);
  bindAttr(R, 'aMus', m.buf.aMus, 1);
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, m.buf.idx);
  gl.drawElements(gl.TRIANGLES, m.count, gl.UNSIGNED_SHORT, 0);
}

// Disegna una scena: { bones: Float32Array(19*16), cam:{eye,at,fov}, props:[{mesh,color,alpha,matrix? (già in mondo)}], hi:Float32Array(14), theme }
export function renderScene(R, scene, w, h) {
  const { gl, loc, canvas } = R;
  if (canvas.width < w || canvas.height < h) {
    canvas.width = Math.max(canvas.width, w); canvas.height = Math.max(canvas.height, h);
  }
  gl.useProgram(R.prog);
  gl.viewport(0, canvas.height - h, w, h);
  gl.enable(gl.SCISSOR_TEST); gl.scissor(0, canvas.height - h, w, h);
  gl.clearColor(0, 0, 0, 0); gl.clearStencil(0);
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT | gl.STENCIL_BUFFER_BIT);
  const th = scene.theme;
  const P = m4.persp(scene.cam.fov, w / h, 0.5, 200);
  const Vw = m4.lookAt(scene.cam.eye, scene.cam.at, [0, 1, 0]);
  gl.uniformMatrix4fv(loc.uVP, false, m4.mul(P, Vw));
  gl.uniformMatrix4fv(loc.uBones, false, scene.bones);
  gl.uniform1fv(loc.uHi, scene.hi);
  gl.uniform3fv(loc.uEye, scene.cam.eye);
  const key = v3.norm(scene.light);
  gl.uniform3fv(loc.uKey, key);
  gl.uniform3fv(loc.uLight, key);
  gl.uniform1f(loc.uGround, scene.ground);
  gl.uniform3fv(loc.uHiCol, th.hi);
  gl.uniform1f(loc.uPulse, scene.pulse || 0);
  gl.uniform3fv(loc.uSky, th.sky); gl.uniform3fv(loc.uGnd, th.gnd);
  gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL);
  gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
  gl.disable(gl.CULL_FACE);
  gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, R.tex); gl.uniform1i(loc.uTex, 0);

  // pavimento
  gl.depthMask(false);
  gl.uniform1f(loc.uShadow, 0); gl.uniform1f(loc.uSkinned, 0);
  gl.uniform1f(loc.uMode, 4); gl.uniform3fv(loc.uColor, th.floor); gl.uniform1f(loc.uAlpha, th.floorA);
  gl.uniform3fv(loc.uFloorC, scene.floor.c); gl.uniform1f(loc.uFloorR, scene.floor.r);
  gl.uniformMatrix4fv(loc.uModel, false, ID4);
  drawMesh(R, scene.floor.mesh);
  // ombre (stencil: ogni pixel una volta sola)
  gl.enable(gl.STENCIL_TEST);
  gl.stencilFunc(gl.EQUAL, 0, 0xff); gl.stencilOp(gl.KEEP, gl.KEEP, gl.INCR);
  gl.uniform1f(loc.uMode, 3); gl.uniform1f(loc.uAlpha, th.shadowA);
  gl.uniform1f(loc.uShadow, 1);
  gl.uniform1f(loc.uSkinned, 1);
  for (const m of R.meshes) if (m.material === 0 || m.material === 2) drawMesh(R, m);
  gl.uniform1f(loc.uSkinned, 0);
  for (const p of scene.props) if (p.shadow !== false && p.mesh) { gl.uniformMatrix4fv(loc.uModel, false, p.model || ID4); drawMesh(R, p.mesh); }
  gl.disable(gl.STENCIL_TEST);
  gl.uniform1f(loc.uShadow, 0);
  gl.depthMask(true);
  // oggetti
  gl.uniform1f(loc.uSkinned, 0);
  gl.uniform1fv(loc.uHi, new Float32Array(14));
  for (const p of scene.props) {
    if (!p.mesh) continue;
    gl.uniform1f(loc.uMode, 2); gl.uniform3fv(loc.uColor, p.color); gl.uniform1f(loc.uAlpha, p.alpha ?? 1); gl.uniform1f(loc.uSpec, p.spec ?? 0.12);
    if (p.alpha != null && p.alpha < 1) gl.depthMask(false);
    gl.uniformMatrix4fv(loc.uModel, false, p.model || ID4);
    drawMesh(R, p.mesh);
    gl.depthMask(true);
  }
  // corpo
  gl.uniform1fv(loc.uHi, scene.hi);
  gl.uniform1f(loc.uSkinned, 1); gl.uniform1f(loc.uAlpha, 1);
  for (const m of R.meshes) {
    gl.uniform1f(loc.uMode, m.material === 0 ? 0 : 1);
    gl.uniform1f(loc.uSpec, m.material === 1 ? 0.5 : m.material === 2 ? 0.07 : 0.05);
    drawMesh(R, m);
  }
  gl.disable(gl.SCISSOR_TEST);
}
